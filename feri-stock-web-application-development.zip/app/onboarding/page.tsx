import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { SignOutButton } from '@/components/auth/sign-out-button'
import { Logo } from '@/components/brand/logo'
import { OnboardingForms } from '@/components/org/onboarding-forms'
import { getContext, requireUser } from '@/lib/session'

export const metadata: Metadata = { title: 'Set up your business' }

export default async function OnboardingPage() {
  const user = await requireUser()
  if (await getContext()) redirect('/app')

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-xl flex-col gap-8 px-5 py-8">
      <header className="flex items-center justify-between">
        <Logo />
        <SignOutButton size="sm" />
      </header>
      <main className="flex flex-col gap-6 pb-10">
        <div className="flex flex-col gap-1.5">
          <h1 className="text-pretty text-2xl font-semibold tracking-tight">Welcome, {user.name.split(' ')[0]}</h1>
          <p className="text-sm leading-relaxed text-muted-foreground">
            One last step: register your business, or join one that is already on FeriStock.
          </p>
        </div>
        <OnboardingForms />
      </main>
    </div>
  )
}
