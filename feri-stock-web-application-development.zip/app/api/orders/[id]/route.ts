import { apiError, json } from '@/lib/api'
import { getOrderDetail } from '@/lib/domain/orders'
import { AppError } from '@/lib/errors'
import { authorize } from '@/lib/session'
import { idSchema } from '@/lib/validation'

/** Order detail, polled by the order screen so both parties see dispatch and payment updates as they happen. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const context = await authorize()
    const { id } = await params
    const parsed = idSchema.safeParse(id)
    if (!parsed.success) throw AppError.notFound('Order not found.')
    const order = await getOrderDetail(context, parsed.data)
    if (!order) throw AppError.notFound('Order not found.')
    return json({ order })
  } catch (error) {
    return apiError(error)
  }
}
