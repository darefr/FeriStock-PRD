// Temporary diagnostic route: removed once the preview origin handling is verified.
export const dynamic = 'force-dynamic'

const NAMES = ['host', 'origin', 'referer', 'x-forwarded-host', 'x-forwarded-proto', 'x-forwarded-for', 'forwarded', 'sec-fetch-site']

function report(request: Request) {
  const headers = Object.fromEntries(NAMES.map((name) => [name, request.headers.get(name)]))
  console.log('[v0] request headers seen by the server:', JSON.stringify(headers))
  return Response.json({ url: request.url, headers })
}

export const GET = report
export const POST = report
