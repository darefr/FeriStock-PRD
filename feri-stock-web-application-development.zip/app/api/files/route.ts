import { apiError, json } from '@/lib/api'
import { FILE_KINDS, LIMITS, type FileKind } from '@/lib/constants'
import { storeFile } from '@/lib/domain/files'
import { AppError } from '@/lib/errors'
import { authorize } from '@/lib/session'

/** Uploads a bilti photo, payment screenshot or payment QR. Returns the id used to attach or display it. */
export async function POST(request: Request) {
  try {
    const context = await authorize()

    // Reject oversized bodies before reading them into memory.
    const declaredLength = Number(request.headers.get('content-length') ?? 0)
    if (declaredLength > LIMITS.maxUploadBytes + 64 * 1024) throw AppError.invalid('Images must be 2 MB or smaller.')

    const form = await request.formData()
    const kind = form.get('kind')
    const file = form.get('file')
    if (typeof kind !== 'string' || !FILE_KINDS.includes(kind as FileKind)) {
      throw AppError.invalid('Unknown upload type.')
    }
    if (!(file instanceof File)) throw AppError.invalid('Choose an image to upload.')
    if (file.size > LIMITS.maxUploadBytes) throw AppError.invalid('Images must be 2 MB or smaller.')

    const id = await storeFile(context, kind as FileKind, Buffer.from(await file.arrayBuffer()))
    return json({ id }, { status: 201 })
  } catch (error) {
    return apiError(error)
  }
}
