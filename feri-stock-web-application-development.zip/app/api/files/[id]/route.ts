import { apiError } from '@/lib/api'
import { getFileForViewer } from '@/lib/domain/files'
import { AppError } from '@/lib/errors'
import { authorize } from '@/lib/session'
import { idSchema } from '@/lib/validation'

/** Serves a private image to the organizations entitled to see it; everyone else gets a 404. */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const context = await authorize()
    const { id } = await params
    const parsed = idSchema.safeParse(id)
    if (!parsed.success) throw AppError.notFound()

    const file = await getFileForViewer(context, parsed.data)
    if (!file) throw AppError.notFound()

    return new Response(new Uint8Array(file.data), {
      headers: {
        'Content-Type': file.contentType,
        'Content-Length': String(file.data.length),
        'Content-Disposition': 'inline',
        'Cache-Control': 'private, max-age=3600',
        'X-Content-Type-Options': 'nosniff',
      },
    })
  } catch (error) {
    return apiError(error)
  }
}
