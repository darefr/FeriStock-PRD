import { toNextJsHandler } from 'better-auth/next-js'
import { auth } from '@/lib/auth'
import { appReady } from '@/lib/bootstrap'

const handler = toNextJsHandler(auth)

// The schema must exist before the first auth request; in development it is created on boot.
export async function GET(request: Request) {
  await appReady()
  return handler.GET(request)
}

export async function POST(request: Request) {
  await appReady()
  return handler.POST(request)
}
