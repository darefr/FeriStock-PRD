import { apiError, json } from '@/lib/api'
import { getNavBadges } from '@/lib/domain/dashboard'
import { authorize } from '@/lib/session'

/** Counts shown on the navigation: cart lines, stock alerts and work waiting on this organization. */
export async function GET() {
  try {
    const context = await authorize()
    return json({ badges: await getNavBadges(context) })
  } catch (error) {
    return apiError(error)
  }
}
