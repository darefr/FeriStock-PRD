import { sql } from 'drizzle-orm'
import { appReady } from '@/lib/bootstrap'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

/** Liveness probe for uptime monitors: confirms the app can reach its database. */
export async function GET() {
  try {
    await appReady()
    await db.execute(sql`select 1`)
    return Response.json({ status: 'ok' })
  } catch (error) {
    console.error('[health] database check failed', error)
    return Response.json({ status: 'unavailable' }, { status: 503 })
  }
}
