import { apiError, json } from '@/lib/api'
import { listInventory } from '@/lib/domain/inventory'
import { authorize } from '@/lib/session'

/** Live stock list, polled by the inventory screen so counts stay in sync across the shop's devices. */
export async function GET() {
  try {
    const context = await authorize({ side: 'retailer' })
    return json({ items: await listInventory(context) })
  } catch (error) {
    return apiError(error)
  }
}
