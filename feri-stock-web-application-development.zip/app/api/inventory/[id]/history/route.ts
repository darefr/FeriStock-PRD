import { apiError, json } from '@/lib/api'
import { getStockHistory } from '@/lib/domain/inventory'
import { AppError } from '@/lib/errors'
import { authorize } from '@/lib/session'
import { idSchema } from '@/lib/validation'

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const context = await authorize({ side: 'retailer' })
    const { id } = await params
    const parsed = idSchema.safeParse(id)
    if (!parsed.success) throw AppError.notFound()
    return json({ movements: await getStockHistory(context, parsed.data) })
  } catch (error) {
    return apiError(error)
  }
}
