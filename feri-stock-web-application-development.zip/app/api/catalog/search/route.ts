import { apiError, json } from '@/lib/api'
import { searchCatalog } from '@/lib/domain/catalog'
import { authorize } from '@/lib/session'
import { idSchema } from '@/lib/validation'

/** Product search across suppliers, used when adding inventory items, schedules and quote lines. */
export async function GET(request: Request) {
  try {
    const context = await authorize({ side: 'retailer' })
    const { searchParams } = new URL(request.url)
    const supplierId = idSchema.safeParse(searchParams.get('supplierId'))
    const products = await searchCatalog(context, {
      query: (searchParams.get('q') ?? '').slice(0, 80),
      supplierId: supplierId.success ? supplierId.data : undefined,
      limit: supplierId.success ? 200 : 30,
    })
    return json({ products })
  } catch (error) {
    return apiError(error)
  }
}
