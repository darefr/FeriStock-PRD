import { redirectTo } from '@/lib/api'
import { appReady } from '@/lib/bootstrap'
import { verifyGatewayPayment } from '@/lib/domain/payments'
import { idSchema } from '@/lib/validation'

/**
 * Where eSewa and Khalti send the buyer back after checkout.
 *
 * Nothing in the redirect is trusted — not its status, not its amount. The handler only uses
 * the payment id from the path to ask the gateway, server to server, what really happened,
 * and an order is marked paid only when the gateway confirms the exact amount.
 */
export async function GET(_request: Request, { params }: { params: Promise<{ gateway: string; paymentId: string }> }) {
  const { gateway, paymentId } = await params
  const id = idSchema.safeParse(paymentId)
  if ((gateway !== 'esewa' && gateway !== 'khalti') || !id.success) return redirectTo('/app/purchases')

  try {
    await appReady()
    const { outcome, orderId } = await verifyGatewayPayment(id.data)
    return redirectTo(`/app/orders/${orderId}?payment=${outcome}`)
  } catch (error) {
    console.error('[payments] return handling failed', error)
    return redirectTo('/app/purchases?payment=unavailable')
  }
}
