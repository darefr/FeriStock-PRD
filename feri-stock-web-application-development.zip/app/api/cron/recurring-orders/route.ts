import { timingSafeEqual } from 'node:crypto'
import { appReady } from '@/lib/bootstrap'
import { runDueSchedules } from '@/lib/domain/schedules'

export const dynamic = 'force-dynamic'

function authorized(request: Request, secret: string): boolean {
  const provided = Buffer.from(request.headers.get('authorization') ?? '')
  const expected = Buffer.from(`Bearer ${secret}`)
  return provided.length === expected.length && timingSafeEqual(provided, expected)
}

/**
 * Daily job (see vercel.json) that generates orders for recurring restock schedules.
 * Vercel Cron sends `Authorization: Bearer $CRON_SECRET`; without that secret the job is disabled.
 * Schedules also run when a member of the shop opens the app, so this is a safety net, not a dependency.
 */
export async function GET(request: Request) {
  const secret = process.env.CRON_SECRET
  if (!secret) return Response.json({ error: 'CRON_SECRET is not configured.' }, { status: 503 })
  if (!authorized(request, secret)) return Response.json({ error: 'Unauthorized.' }, { status: 401 })

  try {
    await appReady()
    return Response.json(await runDueSchedules())
  } catch (error) {
    console.error('[cron] recurring orders failed', error)
    return Response.json({ error: 'Failed to run schedules.' }, { status: 500 })
  }
}
