import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { OrdersView } from '@/components/orders/orders-view'
import { listOrders } from '@/lib/domain/orders'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Sales orders' }

export default async function SalesPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const context = await requireContext()
  if (!context.isSupplier) redirect('/app')
  const [{ status }, orders] = await Promise.all([searchParams, listOrders(context, 'supplier')])

  return (
    <PageBody>
      <PageHeader
        title="Sales orders"
        description="Orders from shops. Accept, pack, dispatch and collect payment from here."
      />
      <OrdersView orders={orders} side="supplier" initialTab={status} />
    </PageBody>
  )
}
