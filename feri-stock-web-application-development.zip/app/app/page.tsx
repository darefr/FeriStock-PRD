import type { Metadata } from 'next'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { RetailerOverviewSection } from '@/components/dashboard/retailer-overview'
import { SupplierOverviewSection } from '@/components/dashboard/supplier-overview'
import { formatBsDate } from '@/lib/bs-date'
import { formatDate } from '@/lib/dates'
import { getRetailerOverview, getSupplierOverview } from '@/lib/domain/dashboard'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Overview' }

export default async function OverviewPage() {
  const context = await requireContext()
  const [retailer, supplier] = await Promise.all([
    context.isRetailer ? getRetailerOverview(context) : null,
    context.isSupplier ? getSupplierOverview(context) : null,
  ])
  const now = new Date()
  const firstName = context.user.name.trim().split(/\s+/)[0]
  const dualRole = retailer !== null && supplier !== null

  return (
    <PageBody>
      <PageHeader title={`Namaste, ${firstName}`} description={`${formatDate(now)} · ${formatBsDate(now)} BS`} />

      {retailer ? (
        <section className="flex flex-col gap-3" aria-label="Buying">
          {dualRole ? <h2 className="text-base font-semibold">Buying</h2> : null}
          <RetailerOverviewSection data={retailer} canOrder={can(context.role, 'orders:place')} />
        </section>
      ) : null}

      {supplier ? (
        <section className="flex flex-col gap-3" aria-label="Selling">
          {dualRole ? <h2 className="text-base font-semibold">Selling</h2> : null}
          <SupplierOverviewSection data={supplier} />
        </section>
      ) : null}
    </PageBody>
  )
}
