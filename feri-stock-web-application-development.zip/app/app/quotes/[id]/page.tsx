import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { QuoteView } from '@/components/quotes/quote-view'
import { getQuoteDetail } from '@/lib/domain/quotes'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'
import { idSchema } from '@/lib/validation'

export const metadata: Metadata = { title: 'Quote' }

export default async function QuotePage({ params }: { params: Promise<{ id: string }> }) {
  const context = await requireContext()
  const id = idSchema.safeParse((await params).id)
  if (!id.success) notFound()
  const quote = await getQuoteDetail(context, id.data)
  if (!quote) notFound()

  return (
    <PageBody className="max-w-3xl">
      <PageHeader back={{ href: '/app/quotes', label: 'Quotes' }} title="Quote request" />
      {/* Keyed by status so the form resets to the saved offer after each change. */}
      <QuoteView
        key={`${quote.id}-${quote.status}-${quote.respondedAt ?? ''}`}
        quote={quote}
        canOrder={can(context.role, 'orders:place')}
        canManage={can(context.role, 'orders:manage')}
      />
    </PageBody>
  )
}
