import { FileTextIcon, PlusIcon } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { EmptyState } from '@/components/app/empty-state'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { QuoteList } from '@/components/quotes/quote-list'
import { Button } from '@/components/ui/button'
import { listQuotes } from '@/lib/domain/quotes'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Quotes' }

export default async function QuotesPage() {
  const context = await requireContext()
  const [sent, received] = await Promise.all([
    context.isRetailer ? listQuotes(context, 'retailer') : null,
    context.isSupplier ? listQuotes(context, 'supplier') : null,
  ])
  const canRequest = context.isRetailer && can(context.role, 'orders:place')
  const dualRole = sent !== null && received !== null

  const requestButton = canRequest ? (
    <Button nativeButton={false} render={<Link href="/app/quotes/new" />}>
      <PlusIcon data-icon="inline-start" />
      Request a quote
    </Button>
  ) : null

  return (
    <PageBody>
      <PageHeader
        title="Quotes"
        description="Custom orders: special quantities, bulk deals and items that are not in a catalog."
        actions={requestButton}
      />

      {received !== null ? (
        <section className="flex flex-col gap-3" aria-label="Requests from shops">
          {dualRole ? <h2 className="text-base font-semibold">Requests from shops</h2> : null}
          {received.length > 0 ? (
            <QuoteList quotes={received} />
          ) : (
            <EmptyState
              icon={FileTextIcon}
              title="No quote requests yet"
              description="When a shop asks for a custom price or an item outside your catalog, the request lands here for you to answer."
            />
          )}
        </section>
      ) : null}

      {sent !== null ? (
        <section className="flex flex-col gap-3" aria-label="Requests you sent">
          {dualRole ? <h2 className="text-base font-semibold">Requests you sent</h2> : null}
          {sent.length > 0 ? (
            <QuoteList quotes={sent} />
          ) : (
            <EmptyState
              icon={FileTextIcon}
              title="No quote requests yet"
              description="Ask a supplier to price a bulk order, a special quantity or something they do not list. Their answer becomes an order in one tap."
            >
              {requestButton}
            </EmptyState>
          )}
        </section>
      ) : null}
    </PageBody>
  )
}
