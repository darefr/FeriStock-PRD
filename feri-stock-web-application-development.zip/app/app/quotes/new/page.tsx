import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { QuoteRequestForm } from '@/components/quotes/quote-request-form'
import { listSuppliers } from '@/lib/domain/catalog'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Request a quote' }

export default async function NewQuotePage({
  searchParams,
}: {
  searchParams: Promise<{ supplier?: string; item?: string; unit?: string }>
}) {
  const context = await requireContext()
  if (!context.isRetailer || !can(context.role, 'orders:place')) redirect('/app/quotes')
  const [query, suppliers] = await Promise.all([searchParams, listSuppliers(context)])
  const item = typeof query.item === 'string' ? query.item.slice(0, 140) : ''
  const unit = typeof query.unit === 'string' ? query.unit.slice(0, 20) : ''

  return (
    <PageBody className="max-w-3xl">
      <PageHeader
        back={{ href: '/app/quotes', label: 'Quotes' }}
        title="Request a quote"
        description="For bulk deals, special quantities or items a supplier does not list."
      />
      <QuoteRequestForm
        suppliers={suppliers.map((supplier) => ({ id: supplier.id, name: supplier.name, city: supplier.city }))}
        initialSupplierId={suppliers.some((supplier) => supplier.id === query.supplier) ? (query.supplier as string) : null}
        initialItem={item ? { name: item, unit } : null}
      />
    </PageBody>
  )
}
