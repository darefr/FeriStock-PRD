'use client'

import { RotateCwIcon, TriangleAlertIcon } from 'lucide-react'
import Link from 'next/link'
import { EmptyState } from '@/components/app/empty-state'
import { PageBody } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <PageBody>
      <EmptyState
        icon={TriangleAlertIcon}
        title="This screen could not be loaded"
        description={
          <>
            Nothing was changed. Try again, and if it keeps happening quote this reference to support:{' '}
            <span className="figures">{error.digest ?? 'not available'}</span>
          </>
        }
      >
        <div className="flex flex-wrap justify-center gap-2">
          <Button onClick={reset}>
            <RotateCwIcon data-icon="inline-start" />
            Try again
          </Button>
          <Button variant="outline" nativeButton={false} render={<Link href="/app" />}>
            Back to overview
          </Button>
        </div>
      </EmptyState>
    </PageBody>
  )
}
