import { LockIcon } from 'lucide-react'
import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { CartView } from '@/components/cart/cart-view'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { getCart } from '@/lib/domain/cart'
import { pluralize } from '@/lib/format'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Cart' }

export default async function CartPage() {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const cart = await getCart(context)
  const canOrder = can(context.role, 'orders:place')

  return (
    <PageBody className="max-w-3xl">
      <PageHeader
        title="Cart"
        description={
          cart.groups.length > 1
            ? `${pluralize(cart.lineCount, 'item')} from ${cart.groups.length} suppliers. Each supplier gets its own purchase order.`
            : 'Review quantities, then send the purchase order to your supplier.'
        }
      />
      {canOrder ? null : (
        <Alert>
          <LockIcon />
          <AlertTitle>Your role cannot place orders</AlertTitle>
          <AlertDescription>An owner or manager of {context.org.name} can send these purchase orders.</AlertDescription>
        </Alert>
      )}
      <CartView cart={cart} canOrder={canOrder} />
    </PageBody>
  )
}
