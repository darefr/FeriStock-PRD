import type { Metadata } from 'next'
import { LedgerSection } from '@/components/ledger/ledger-section'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { getLedger } from '@/lib/domain/dashboard'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Udharo & dues' }

export default async function UdharoPage() {
  const context = await requireContext()
  const [payable, receivable] = await Promise.all([
    context.isRetailer ? getLedger(context, 'retailer') : null,
    context.isSupplier ? getLedger(context, 'supplier') : null,
  ])
  const dualRole = payable !== null && receivable !== null

  return (
    <PageBody>
      <PageHeader
        title="Udharo & dues"
        description="Balances on accepted orders and the due dates of approved credit. Open an order to pay or record a payment."
      />

      {receivable ? (
        <section className="flex flex-col gap-3" aria-label="Owed to you">
          {dualRole ? <h2 className="text-base font-semibold">Shops owe you</h2> : null}
          <LedgerSection ledger={receivable} side="supplier" />
        </section>
      ) : null}

      {payable ? (
        <section className="flex flex-col gap-3" aria-label="You owe">
          {dualRole ? <h2 className="text-base font-semibold">You owe suppliers</h2> : null}
          <LedgerSection ledger={payable} side="retailer" />
        </section>
      ) : null}
    </PageBody>
  )
}
