import { SearchXIcon } from 'lucide-react'
import Link from 'next/link'
import { EmptyState } from '@/components/app/empty-state'
import { PageBody } from '@/components/app/page-header'
import { Button } from '@/components/ui/button'

export default function AppNotFound() {
  return (
    <PageBody>
      <EmptyState
        icon={SearchXIcon}
        title="Not found"
        description="This record does not exist, or it belongs to another organization."
      >
        <Button nativeButton={false} render={<Link href="/app" />}>
          Back to overview
        </Button>
      </EmptyState>
    </PageBody>
  )
}
