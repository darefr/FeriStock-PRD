import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { SuppliersView } from '@/components/suppliers/suppliers-view'
import { listSuppliers } from '@/lib/domain/catalog'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Suppliers' }

export default async function SuppliersPage() {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const suppliers = await listSuppliers(context)

  return (
    <PageBody>
      <PageHeader
        title="Suppliers"
        description="Wholesalers and distributors you can order from, with their delivery, payment and credit terms."
      />
      <SuppliersView suppliers={suppliers} />
    </PageBody>
  )
}
