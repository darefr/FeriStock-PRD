import { FileTextIcon, MapPinIcon, PhoneIcon, ShoppingCartIcon } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound, redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { SupplierCatalog } from '@/components/suppliers/supplier-catalog'
import { SupplierTerms } from '@/components/suppliers/supplier-terms'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { getSupplierProfile } from '@/lib/domain/catalog'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'
import { idSchema } from '@/lib/validation'

export const metadata: Metadata = { title: 'Supplier' }

export default async function SupplierPage({ params }: { params: Promise<{ id: string }> }) {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const id = idSchema.safeParse((await params).id)
  if (!id.success) notFound()
  const profile = await getSupplierProfile(context, id.data)
  if (!profile) notFound()

  const { supplier, products } = profile
  const canOrder = can(context.role, 'orders:place')

  return (
    <PageBody>
      <PageHeader
        back={{ href: '/app/suppliers', label: 'Suppliers' }}
        title={supplier.name}
        actions={
          canOrder ? (
            <>
              <Button variant="outline" nativeButton={false} render={<Link href={`/app/quotes/new?supplier=${supplier.id}`} />}>
                <FileTextIcon data-icon="inline-start" />
                Request a quote
              </Button>
              <Button nativeButton={false} render={<Link href="/app/cart" />}>
                <ShoppingCartIcon data-icon="inline-start" />
                View cart
              </Button>
            </>
          ) : null
        }
      />

      <Card size="sm">
        <CardContent className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5 text-sm sm:flex-row sm:flex-wrap sm:gap-x-6">
            <span className="flex items-center gap-1.5">
              <MapPinIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              {supplier.address}, {supplier.city}
            </span>
            <a
              href={`tel:${supplier.phone.replace(/[^\d+]/g, '')}`}
              className="flex w-fit items-center gap-1.5 rounded-sm text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-3 focus-visible:ring-ring/50"
            >
              <PhoneIcon className="size-4 shrink-0" aria-hidden="true" />
              <span className="figures">{supplier.phone}</span>
            </a>
            <span className="text-muted-foreground">
              PAN/VAT <span className="figures">{supplier.panVatNo}</span>
            </span>
          </div>
          <SupplierTerms supplier={supplier} />
          {supplier.deliveryNote ? (
            <p className="text-sm leading-relaxed text-muted-foreground">{supplier.deliveryNote}</p>
          ) : null}
        </CardContent>
      </Card>

      <SupplierCatalog products={products} canOrder={canOrder} canTrack={can(context.role, 'inventory:manage')} />
    </PageBody>
  )
}
