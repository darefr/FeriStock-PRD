import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { PageBody } from '@/components/app/page-header'
import { OrderView } from '@/components/orders/order-view'
import { getOrderDetail } from '@/lib/domain/orders'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'
import { idSchema } from '@/lib/validation'

export const metadata: Metadata = { title: 'Order' }

export default async function OrderPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>
  searchParams: Promise<{ payment?: string | string[] }>
}) {
  const context = await requireContext()
  const id = idSchema.safeParse((await params).id)
  if (!id.success) notFound()
  const order = await getOrderDetail(context, id.data)
  if (!order) notFound()
  const { payment } = await searchParams

  return (
    <PageBody>
      <OrderView
        initialOrder={order}
        paymentOutcome={typeof payment === 'string' ? payment : null}
        permissions={{
          place: can(context.role, 'orders:place'),
          manage: can(context.role, 'orders:manage'),
          fulfil: can(context.role, 'fulfilment:update'),
          pay: can(context.role, 'payments:manage'),
        }}
      />
    </PageBody>
  )
}
