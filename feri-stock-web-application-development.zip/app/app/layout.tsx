import type { Metadata } from 'next'
import { after } from 'next/server'
import { AppShell } from '@/components/shell/app-shell'
import { MEMBER_ROLE_LABEL, ORG_ROLE_LABEL } from '@/lib/constants'
import { getNavBadges } from '@/lib/domain/dashboard'
import { runDueSchedules } from '@/lib/domain/schedules'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = {
  robots: { index: false, follow: false },
}

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const context = await requireContext()
  const badges = await getNavBadges(context)

  if (context.isRetailer) {
    // Recurring restock orders that have come due are generated after the page is sent,
    // so schedules keep running whenever someone from the shop opens the app.
    after(async () => {
      await runDueSchedules({ orgId: context.org.id }).catch((error) =>
        console.error('[schedules] catch-up run failed', error),
      )
    })
  }

  return (
    <AppShell
      orgName={context.org.name}
      orgRoleLabel={ORG_ROLE_LABEL[context.org.role]}
      userName={context.user.name}
      userEmail={context.user.email}
      memberRoleLabel={MEMBER_ROLE_LABEL[context.role]}
      isRetailer={context.isRetailer}
      isSupplier={context.isSupplier}
      badges={badges}
    >
      {children}
    </AppShell>
  )
}
