import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody } from '@/components/app/page-header'
import { SchedulesView } from '@/components/schedules/schedules-view'
import { listSuppliers } from '@/lib/domain/catalog'
import { listSchedules } from '@/lib/domain/schedules'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Schedules' }

export default async function SchedulesPage() {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const [schedules, suppliers] = await Promise.all([listSchedules(context), listSuppliers(context)])

  return (
    <PageBody>
      <SchedulesView
        schedules={schedules}
        suppliers={suppliers.map((supplier) => ({ id: supplier.id, name: supplier.name }))}
        canOrder={can(context.role, 'orders:place')}
      />
    </PageBody>
  )
}
