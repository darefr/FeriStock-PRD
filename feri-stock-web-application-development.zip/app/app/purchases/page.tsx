import { ShoppingCartIcon } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { OrdersView } from '@/components/orders/orders-view'
import { Button } from '@/components/ui/button'
import { listOrders } from '@/lib/domain/orders'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Purchases' }

export default async function PurchasesPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const [{ status }, orders] = await Promise.all([searchParams, listOrders(context, 'retailer')])

  return (
    <PageBody>
      <PageHeader
        title="Purchases"
        description="Purchase orders you have sent to suppliers, from acceptance to delivery and payment."
        actions={
          <Button variant="outline" nativeButton={false} render={<Link href="/app/cart" />}>
            <ShoppingCartIcon data-icon="inline-start" />
            Cart
          </Button>
        }
      />
      <OrdersView orders={orders} side="retailer" initialTab={status} />
    </PageBody>
  )
}
