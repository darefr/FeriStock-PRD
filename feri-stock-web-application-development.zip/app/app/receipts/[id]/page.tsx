import { ChevronLeftIcon } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Money } from '@/components/app/money'
import { PageBody } from '@/components/app/page-header'
import { Stamp } from '@/components/app/stamp'
import { Logo } from '@/components/brand/logo'
import { PrintButton } from '@/components/receipts/print-button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBsDate } from '@/lib/bs-date'
import { ORDER_TYPE_LABEL, PAYMENT_METHOD_LABEL, type OrderType, type PaymentMethod } from '@/lib/constants'
import { formatDate, formatDateString, formatDateTime } from '@/lib/dates'
import type { ReceiptParty, ReceiptSnapshot } from '@/lib/db/schema'
import { getReceiptForViewer } from '@/lib/domain/receipts'
import { requireContext } from '@/lib/session'
import { idSchema } from '@/lib/validation'

export const metadata: Metadata = { title: 'Receipt' }

function Party({ role, party }: { role: string; party: ReceiptParty }) {
  return (
    <div className="flex flex-col gap-0.5 text-sm">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{role}</span>
      <span className="text-base font-semibold">{party.name}</span>
      <span className="leading-relaxed">
        {party.address}, {party.city}
      </span>
      <span>
        PAN/VAT <span className="figures font-medium">{party.panVatNo}</span>
      </span>
      <span className="figures">{party.phone}</span>
    </div>
  )
}

function stampFor(snapshot: ReceiptSnapshot): { tone: 'paid' | 'credit' | 'due'; label: string; detail?: string } {
  const { totals, order } = snapshot
  const due = order.creditApproved && order.dueDate ? `Due ${formatDateString(order.dueDate)}` : undefined
  if (totals.totalPaisa > 0 && totals.balancePaisa === 0) return { tone: 'paid', label: 'Paid' }
  if (totals.paidToDatePaisa > 0) return { tone: 'credit', label: 'Part paid', detail: due }
  if (order.creditApproved) return { tone: 'credit', label: 'Udharo', detail: due }
  return { tone: 'due', label: 'Unpaid' }
}

export default async function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const context = await requireContext()
  const id = idSchema.safeParse((await params).id)
  if (!id.success) notFound()
  const receipt = await getReceiptForViewer(context, id.data)
  if (!receipt) notFound()

  const { snapshot } = receipt
  const stamp = stampFor(snapshot)
  const isPayment = snapshot.kind === 'payment' && snapshot.payment !== null

  return (
    <PageBody className="max-w-3xl print:max-w-none print:p-0">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link
          href={`/app/orders/${receipt.orderId}`}
          className="inline-flex items-center gap-1 rounded-sm text-sm text-muted-foreground outline-none hover:text-foreground focus-visible:ring-3 focus-visible:ring-ring/50"
        >
          <ChevronLeftIcon className="size-4" aria-hidden="true" />
          Order {snapshot.order.orderNo}
        </Link>
        <PrintButton />
      </div>

      <article className="flex flex-col gap-8 rounded-xl bg-card p-5 ring-1 ring-foreground/10 sm:p-8 print:rounded-none print:p-0 print:ring-0">
        <header className="flex items-start justify-between gap-4">
          <div className="flex flex-col gap-3">
            <Logo />
            <div className="flex flex-col gap-1">
              <h1 className="text-xl font-semibold tracking-tight">
                {isPayment ? 'Order & Payment Receipt' : 'Order Confirmation Receipt'}
              </h1>
              <p className="text-sm text-muted-foreground">
                No. <span className="figures font-medium text-foreground">{receipt.receiptNo}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Issued {formatDateTime(receipt.issuedAt)} · Miti {formatBsDate(receipt.issuedAt)} BS
              </p>
            </div>
          </div>
          <Stamp tone={stamp.tone} detail={stamp.detail} className="mt-2 mr-2 shrink-0">
            {stamp.label}
          </Stamp>
        </header>

        <section className="grid gap-6 sm:grid-cols-2" aria-label="Parties">
          <Party role="Supplier" party={snapshot.supplier} />
          <Party role="Buyer" party={snapshot.buyer} />
        </section>

        <section aria-label="Order details">
          <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm sm:grid-cols-4">
            <div className="flex flex-col gap-0.5">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Order</dt>
              <dd className="figures font-medium">{snapshot.order.orderNo}</dd>
            </div>
            <div className="flex flex-col gap-0.5">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Type</dt>
              <dd>{ORDER_TYPE_LABEL[snapshot.order.orderType as OrderType] ?? snapshot.order.orderType}</dd>
            </div>
            <div className="flex flex-col gap-0.5">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Ordered</dt>
              <dd>{snapshot.order.placedAt ? formatDate(snapshot.order.placedAt) : 'Not recorded'}</dd>
            </div>
            <div className="flex flex-col gap-0.5">
              <dt className="text-xs uppercase tracking-wider text-muted-foreground">Accepted</dt>
              <dd>{snapshot.order.acceptedAt ? formatDate(snapshot.order.acceptedAt) : 'Not recorded'}</dd>
            </div>
          </dl>
        </section>

        <section aria-label="Items">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Rate</TableHead>
                <TableHead className="text-right">Amount</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {snapshot.items.map((item, index) => (
                <TableRow key={`${item.sku ?? item.name}-${index}`}>
                  <TableCell className="whitespace-normal">
                    <span className="font-medium">{item.name}</span>
                    {item.sku ? <span className="figures block text-xs text-muted-foreground">{item.sku}</span> : null}
                  </TableCell>
                  <TableCell className="text-right">
                    <span className="figures">{item.qty}</span> {item.unit}
                  </TableCell>
                  <TableCell className="text-right">
                    <Money paisa={item.unitPricePaisa} decimals="always" symbol={false} />
                  </TableCell>
                  <TableCell className="text-right">
                    <Money paisa={item.lineTotalPaisa} decimals="always" symbol={false} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <dl className="ml-auto mt-4 flex w-full max-w-xs flex-col gap-1.5 text-sm">
            <div className="flex items-center justify-between gap-4 font-semibold">
              <dt>Order total (NPR)</dt>
              <dd>
                <Money paisa={snapshot.totals.totalPaisa} decimals="always" />
              </dd>
            </div>
            <div className="flex items-center justify-between gap-4">
              <dt className="text-muted-foreground">Paid to date</dt>
              <dd>
                <Money paisa={snapshot.totals.paidToDatePaisa} decimals="always" />
              </dd>
            </div>
            <div className="flex items-center justify-between gap-4 border-t pt-1.5 font-medium">
              <dt>Balance due</dt>
              <dd>
                <Money paisa={snapshot.totals.balancePaisa} decimals="always" />
              </dd>
            </div>
          </dl>
        </section>

        {snapshot.payment ? (
          <section className="rounded-lg border p-4" aria-label="Payment">
            <h2 className="text-sm font-semibold">This payment</h2>
            <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-3 text-sm sm:grid-cols-4">
              <div className="flex flex-col gap-0.5">
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">Amount</dt>
                <dd className="font-semibold">
                  <Money paisa={snapshot.payment.amountPaisa} decimals="always" />
                </dd>
              </div>
              <div className="flex flex-col gap-0.5">
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">Method</dt>
                <dd>
                  {PAYMENT_METHOD_LABEL[snapshot.payment.method as PaymentMethod] ?? snapshot.payment.method}
                  {snapshot.payment.gatewayEnv === 'test' ? ' (test)' : ''}
                </dd>
              </div>
              <div className="flex flex-col gap-0.5">
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">Reference</dt>
                <dd className="figures break-all font-medium">
                  {snapshot.payment.transactionRef ?? snapshot.payment.gatewayTxnId ?? 'None given'}
                </dd>
              </div>
              <div className="flex flex-col gap-0.5">
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">Paid on</dt>
                <dd>{formatDateTime(snapshot.payment.paidAt)}</dd>
              </div>
            </dl>
          </section>
        ) : null}

        <footer className="flex flex-col gap-1 border-t pt-4 text-xs leading-relaxed text-muted-foreground">
          <p>
            {snapshot.payment
              ? 'Paid by the buyer directly to the supplier. FeriStock does not collect, hold or transfer funds.'
              : 'Issued when the supplier accepted the order. Payment is made by the buyer directly to the supplier.'}
          </p>
          <p>This receipt is a frozen record. It does not change if business details, prices or the order change later.</p>
        </footer>
      </article>
    </PageBody>
  )
}
