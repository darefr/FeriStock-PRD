import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody } from '@/components/app/page-header'
import { InventoryView } from '@/components/inventory/inventory-view'
import { listInventory } from '@/lib/domain/inventory'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Inventory' }

export default async function InventoryPage({ searchParams }: { searchParams: Promise<{ filter?: string }> }) {
  const context = await requireContext()
  if (!context.isRetailer) redirect('/app')
  const [{ filter }, items] = await Promise.all([searchParams, listInventory(context)])

  return (
    <PageBody>
      <InventoryView
        initialItems={items}
        initialFilter={filter === 'attention' ? 'restock' : 'all'}
        canManage={can(context.role, 'inventory:manage')}
        canOrder={can(context.role, 'orders:place')}
      />
    </PageBody>
  )
}
