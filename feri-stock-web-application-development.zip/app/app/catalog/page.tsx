import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { PageBody } from '@/components/app/page-header'
import { CatalogView } from '@/components/catalog/catalog-view'
import { listOwnProducts } from '@/lib/domain/catalog'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Catalog' }

export default async function CatalogPage() {
  const context = await requireContext()
  if (!context.isSupplier) redirect('/app')
  const products = await listOwnProducts(context)
  return (
    <PageBody>
      <CatalogView products={products} canManage={can(context.role, 'catalog:manage')} />
    </PageBody>
  )
}
