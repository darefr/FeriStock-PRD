import { LockIcon } from 'lucide-react'
import { redirect } from 'next/navigation'
import { PaymentMethodsForm } from '@/components/settings/payment-methods-form'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { getPaymentConfigView } from '@/lib/domain/orgs'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export default async function PaymentSettingsPage() {
  const context = await requireContext()
  if (!context.isSupplier) redirect('/app/settings')

  if (!can(context.role, 'payments:configure')) {
    return (
      <Alert>
        <LockIcon />
        <AlertTitle>Only owners can see payment credentials</AlertTitle>
        <AlertDescription>
          Gateway keys, bank details and the payment QR are managed by an owner of {context.org.name}.
        </AlertDescription>
      </Alert>
    )
  }

  return <PaymentMethodsForm config={await getPaymentConfigView(context.org.id)} />
}
