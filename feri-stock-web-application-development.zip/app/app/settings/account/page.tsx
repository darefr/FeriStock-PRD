import { AccountForm } from '@/components/settings/account-form'
import { requireContext } from '@/lib/session'

export default async function AccountSettingsPage() {
  const { user } = await requireContext()
  return <AccountForm name={user.name} email={user.email} />
}
