import { LockIcon } from 'lucide-react'
import { BusinessForm } from '@/components/settings/business-form'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ORG_ROLE_LABEL } from '@/lib/constants'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export default async function BusinessSettingsPage() {
  const { org, role } = await requireContext()

  if (can(role, 'org:manage')) {
    return (
      <BusinessForm
        organization={{
          name: org.name,
          role: org.role,
          panVatNo: org.panVatNo,
          city: org.city,
          address: org.address,
          phone: org.phone,
          email: org.email ?? '',
        }}
      />
    )
  }

  const rows = [
    ['Business name', org.name],
    ['Type', ORG_ROLE_LABEL[org.role]],
    ['PAN / VAT number', org.panVatNo],
    ['Address', `${org.address}, ${org.city}`],
    ['Phone', org.phone],
    ['Email', org.email ?? 'Not set'],
  ]

  return (
    <div className="flex flex-col gap-4">
      <Alert>
        <LockIcon />
        <AlertTitle>Only owners can change these details</AlertTitle>
        <AlertDescription>Ask an owner of {org.name} if something here needs correcting.</AlertDescription>
      </Alert>
      <Card>
        <CardHeader>
          <CardTitle>Business details</CardTitle>
          <CardDescription>Printed on every purchase order and receipt.</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="flex flex-col divide-y">
            {rows.map(([label, value]) => (
              <div key={label} className="flex flex-col gap-0.5 py-2.5 first:pt-0 last:pb-0 sm:flex-row sm:gap-4">
                <dt className="text-sm text-muted-foreground sm:w-44 sm:shrink-0">{label}</dt>
                <dd className="text-sm font-medium">{value}</dd>
              </div>
            ))}
          </dl>
        </CardContent>
      </Card>
    </div>
  )
}
