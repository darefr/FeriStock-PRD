import { LockIcon } from 'lucide-react'
import { redirect } from 'next/navigation'
import { SupplierTermsForm } from '@/components/settings/supplier-terms-form'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { getSupplierSettings } from '@/lib/domain/orgs'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export default async function SellingSettingsPage() {
  const context = await requireContext()
  if (!context.isSupplier) redirect('/app/settings')

  if (!can(context.role, 'org:manage')) {
    return (
      <Alert>
        <LockIcon />
        <AlertTitle>Only owners can change selling terms</AlertTitle>
        <AlertDescription>
          Delivery methods, minimum order value and credit terms are set by an owner of {context.org.name}.
        </AlertDescription>
      </Alert>
    )
  }

  return <SupplierTermsForm settings={await getSupplierSettings(context.org.id)} />
}
