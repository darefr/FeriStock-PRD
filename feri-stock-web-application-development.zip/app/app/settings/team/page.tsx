import { TeamView } from '@/components/settings/team-view'
import { listMembers, listOpenInvites } from '@/lib/domain/orgs'
import { can } from '@/lib/permissions'
import { requireContext } from '@/lib/session'

export default async function TeamSettingsPage() {
  const context = await requireContext()
  const canManage = can(context.role, 'team:manage')
  const [members, invites] = await Promise.all([
    listMembers(context),
    canManage ? listOpenInvites(context) : Promise.resolve([]),
  ])
  return <TeamView members={members} invites={invites} canManage={canManage} />
}
