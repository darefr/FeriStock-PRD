import type { Metadata } from 'next'
import { PageBody, PageHeader } from '@/components/app/page-header'
import { SettingsNav } from '@/components/settings/settings-nav'
import { requireContext } from '@/lib/session'

export const metadata: Metadata = { title: 'Settings' }

export default async function SettingsLayout({ children }: { children: React.ReactNode }) {
  const context = await requireContext()
  return (
    <PageBody className="max-w-3xl">
      <PageHeader title="Settings" description={context.org.name} />
      <SettingsNav isSupplier={context.isSupplier} />
      {children}
    </PageBody>
  )
}
