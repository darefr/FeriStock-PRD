import { CheckIcon } from 'lucide-react'
import Link from 'next/link'
import { Logo } from '@/components/brand/logo'

const POINTS = [
  'Count stock up and down from the shop floor',
  'Send purchase orders to your wholesaler in one tap',
  'Follow the van or the bilti until the goods arrive',
  'Pay by eSewa, Khalti or bank — straight to the supplier',
]

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)]">
      <aside className="hidden flex-col justify-between gap-10 bg-primary p-10 text-primary-foreground lg:flex xl:p-14">
        <Link
          href="/"
          className="w-fit rounded-md outline-none focus-visible:ring-3 focus-visible:ring-primary-foreground/50"
        >
          <Logo tone="inverse" />
        </Link>
        <div className="flex max-w-md flex-col gap-8">
          <p className="text-balance text-4xl font-semibold leading-tight tracking-tight font-stretch-[88%]">
            Stock, orders and udharo in one ledger.
          </p>
          <ul className="flex flex-col gap-3">
            {POINTS.map((point) => (
              <li key={point} className="flex items-start gap-3 text-base leading-relaxed text-primary-foreground/90">
                <CheckIcon className="mt-1 size-4 shrink-0 text-warning" aria-hidden="true" />
                {point}
              </li>
            ))}
          </ul>
        </div>
        <p className="max-w-md text-sm leading-relaxed text-primary-foreground/70">
          FeriStock never holds your money. Every payment goes directly from the buyer to the supplier&apos;s own
          account.
        </p>
      </aside>
      <main className="flex flex-col items-center justify-center px-5 py-10">
        <div className="flex w-full max-w-sm flex-col gap-8">
          <Link
            href="/"
            className="w-fit rounded-md outline-none focus-visible:ring-3 focus-visible:ring-ring/50 lg:hidden"
          >
            <Logo />
          </Link>
          {children}
        </div>
      </main>
    </div>
  )
}
