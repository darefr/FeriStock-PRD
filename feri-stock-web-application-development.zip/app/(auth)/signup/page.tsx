import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { SignupForm } from '@/components/auth/signup-form'
import { getSessionUser } from '@/lib/session'

export const metadata: Metadata = { title: 'Create account' }

export default async function SignupPage() {
  if (await getSessionUser()) redirect('/app')
  return <SignupForm />
}
