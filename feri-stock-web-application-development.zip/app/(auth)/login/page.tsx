import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { LoginForm } from '@/components/auth/login-form'
import { getSessionUser } from '@/lib/session'

export const metadata: Metadata = { title: 'Log in' }

/** Only same-site app paths are accepted as a post-login destination. */
function safeNext(value: string | string[] | undefined): string {
  const next = Array.isArray(value) ? value[0] : value
  return next && /^\/app(\/[\w\-./?=&%]*)?$/.test(next) ? next : '/app'
}

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string | string[] }>
}) {
  const next = safeNext((await searchParams).next)
  if (await getSessionUser()) redirect(next)
  return <LoginForm next={next} />
}
