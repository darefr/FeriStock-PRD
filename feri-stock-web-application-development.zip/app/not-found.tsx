import Link from 'next/link'
import { Logo } from '@/components/brand/logo'
import { Button } from '@/components/ui/button'

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col items-start justify-center gap-6 px-5">
      <Logo />
      <div className="flex flex-col gap-2">
        <p className="figures text-sm text-muted-foreground">404</p>
        <h1 className="text-pretty text-2xl font-semibold tracking-tight">This page is not on the shelf</h1>
        <p className="text-sm leading-relaxed text-muted-foreground">
          The link may be old, or the page may have moved. Head back and pick up from there.
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button nativeButton={false} render={<Link href="/" />}>
          Go to home
        </Button>
        <Button variant="outline" nativeButton={false} render={<Link href="/app" />}>
          Open my workspace
        </Button>
      </div>
    </main>
  )
}
