// Temporary diagnostic: logs which hosts reach the dev server. Removed once preview origins are verified.
import { NextResponse, type NextRequest } from 'next/server'

const NAMES = ['host', 'origin', 'referer', 'x-forwarded-host', 'x-forwarded-proto', 'sec-fetch-site', 'sec-fetch-dest']

export function proxy(request: NextRequest) {
  const headers = Object.fromEntries(NAMES.map((name) => [name, request.headers.get(name)]))
  console.log('[v0] proxy', request.method, request.nextUrl.pathname, JSON.stringify(headers))
  return NextResponse.next()
}

export const config = { matcher: ['/', '/login', '/signup', '/api/auth/:path*'] }
