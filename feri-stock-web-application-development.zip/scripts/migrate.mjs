// Applies pending SQL migrations to the hosted PostgreSQL database.
// Runs as part of `pnpm build`, so every deployment ships with an up-to-date schema.
import { fileURLToPath } from 'node:url'
import { drizzle } from 'drizzle-orm/node-postgres'
import { migrate } from 'drizzle-orm/node-postgres/migrator'
import pg from 'pg'

// Prefer a direct (non-pooled) connection for DDL when the provider exposes one.
const url =
  process.env.DATABASE_URL_UNPOOLED ||
  process.env.POSTGRES_URL_NON_POOLING ||
  process.env.DATABASE_URL ||
  process.env.POSTGRES_URL

if (!url) {
  console.log('[migrate] No DATABASE_URL set - skipping database migrations.')
  process.exit(0)
}

const migrationsFolder = fileURLToPath(new URL('../drizzle', import.meta.url))
const pool = new pg.Pool({ connectionString: url, max: 1 })
const db = drizzle(pool)

try {
  try {
    await migrate(db, { migrationsFolder })
  } catch (error) {
    // A parallel deployment may be applying the same migration; once it finishes this is a no-op.
    console.warn('[migrate] First attempt failed, retrying once:', error instanceof Error ? error.message : error)
    await new Promise((resolve) => setTimeout(resolve, 3000))
    await migrate(db, { migrationsFolder })
  }
  console.log('[migrate] Database schema is up to date.')
} catch (error) {
  console.error('[migrate] Migration failed:', error)
  process.exitCode = 1
} finally {
  await pool.end()
}
