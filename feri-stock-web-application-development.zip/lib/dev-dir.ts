import { mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

/**
 * Where development-only state lives (the embedded database and a local encryption key).
 * Kept outside the project so it is never committed or deployed. Never used in production.
 */
export function devDataDir(): string {
  const dir = process.env.FERISTOCK_DEV_DIR ?? join(tmpdir(), 'feristock-dev')
  mkdirSync(dir, { recursive: true, mode: 0o700 })
  return dir
}
