import type { ScheduleFrequency } from './constants'
import { nptParts, nptToInstant } from './dates'

export type ScheduleRule = {
  frequency: ScheduleFrequency
  /** 0 (Sunday) – 6 (Saturday); used when frequency is weekly. */
  dayOfWeek: number | null
  /** 1 – 28; used when frequency is monthly. Capped at 28 so every month has the day. */
  dayOfMonth: number | null
  /** "HH:MM" in Nepal time. */
  timeOfDay: string
}

/** The first run strictly after `after` for a recurring restock rule, evaluated in Nepal time. */
export function computeNextRun(rule: ScheduleRule, after: Date): Date {
  const [hour, minute] = rule.timeOfDay.split(':').map(Number)
  const now = nptParts(after)

  if (rule.frequency === 'weekly') {
    const target = rule.dayOfWeek ?? 0
    let offset = (target - now.weekday + 7) % 7
    let candidate = nptToInstant(now.year, now.month, now.day + offset, hour, minute)
    if (candidate.getTime() <= after.getTime()) {
      offset += 7
      candidate = nptToInstant(now.year, now.month, now.day + offset, hour, minute)
    }
    return candidate
  }

  const day = Math.min(Math.max(rule.dayOfMonth ?? 1, 1), 28)
  let candidate = nptToInstant(now.year, now.month, day, hour, minute)
  if (candidate.getTime() <= after.getTime()) {
    candidate = nptToInstant(now.year, now.month + 1, day, hour, minute)
  }
  return candidate
}
