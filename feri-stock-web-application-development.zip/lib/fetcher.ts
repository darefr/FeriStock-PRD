/** SWR fetcher for the app's own JSON endpoints. Surfaces the server's error message when there is one. */
export async function fetcher<T>(url: string): Promise<T> {
  const response = await fetch(url, { credentials: 'same-origin' })
  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as { error?: string } | null
    throw new Error(body?.error ?? 'Could not load the latest data.')
  }
  return response.json() as Promise<T>
}
