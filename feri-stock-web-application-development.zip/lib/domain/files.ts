import 'server-only'
import { and, eq, inArray } from 'drizzle-orm'
import { LIMITS, type FileKind } from '@/lib/constants'
import { db } from '@/lib/db'
import { files, orders, supplierPaymentConfigs } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { assertAllowed, type AppContext } from '@/lib/context'
import { sideOf } from './order-core'

// Bilti photos, payment screenshots and QR codes are business documents, so they are stored
// privately in the database and only ever served through an authorization check.

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])

/** Identifies an image by its leading bytes; the browser-supplied type is never trusted. */
export function sniffImageType(bytes: Buffer): 'image/jpeg' | 'image/png' | 'image/webp' | null {
  if (bytes.length < 12) return null
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg'
  if (bytes.subarray(0, 8).equals(PNG_SIGNATURE)) return 'image/png'
  if (bytes.subarray(0, 4).toString('latin1') === 'RIFF' && bytes.subarray(8, 12).toString('latin1') === 'WEBP') {
    return 'image/webp'
  }
  return null
}

export async function storeFile(context: AppContext, kind: FileKind, bytes: Buffer): Promise<string> {
  if (kind === 'bilti_photo') assertAllowed(context, { capability: 'fulfilment:update', side: 'supplier' })
  if (kind === 'payment_proof') assertAllowed(context, { capability: 'payments:manage', side: 'retailer' })
  if (kind === 'qr_image') assertAllowed(context, { capability: 'payments:configure', side: 'supplier' })

  if (bytes.length === 0) throw AppError.invalid('The file is empty.')
  if (bytes.length > LIMITS.maxUploadBytes) throw AppError.invalid('Images must be 2 MB or smaller.')
  const contentType = sniffImageType(bytes)
  if (!contentType) throw AppError.invalid('Upload a JPG, PNG or WebP image.')

  return db.transaction(async (tx) => {
    const [row] = await tx
      .insert(files)
      .values({
        orgId: context.org.id,
        kind,
        contentType,
        sizeBytes: bytes.length,
        data: bytes,
        createdBy: context.user.id,
      })
      .returning({ id: files.id })
    if (kind === 'qr_image') {
      await tx
        .insert(supplierPaymentConfigs)
        .values({ orgId: context.org.id, qrFileId: row.id })
        .onConflictDoUpdate({ target: supplierPaymentConfigs.orgId, set: { qrFileId: row.id } })
    }
    return row.id
  })
}

/**
 * Returns a file only when the viewer's organization is entitled to it:
 * its own uploads, documents attached to an order it is a party to,
 * or the current payment QR of a supplier it has an accepted order with.
 */
export async function getFileForViewer(
  context: AppContext,
  fileId: string,
): Promise<{ contentType: string; data: Buffer } | null> {
  const [meta] = await db
    .select({ id: files.id, orgId: files.orgId, kind: files.kind, orderId: files.orderId })
    .from(files)
    .where(eq(files.id, fileId))
    .limit(1)
  if (!meta) return null

  let allowed = meta.orgId === context.org.id

  if (!allowed && meta.orderId) {
    const [order] = await db
      .select({ retailerOrgId: orders.retailerOrgId, supplierOrgId: orders.supplierOrgId })
      .from(orders)
      .where(eq(orders.id, meta.orderId))
      .limit(1)
    allowed = Boolean(order && sideOf(order, context.org.id) !== null)
  }

  if (!allowed && meta.kind === 'qr_image') {
    const [config] = await db
      .select({ qrFileId: supplierPaymentConfigs.qrFileId })
      .from(supplierPaymentConfigs)
      .where(eq(supplierPaymentConfigs.orgId, meta.orgId))
      .limit(1)
    if (config?.qrFileId === meta.id) {
      const [order] = await db
        .select({ id: orders.id })
        .from(orders)
        .where(
          and(
            eq(orders.supplierOrgId, meta.orgId),
            eq(orders.retailerOrgId, context.org.id),
            inArray(orders.status, ['accepted', 'packed', 'dispatched', 'delivered']),
          ),
        )
        .limit(1)
      allowed = Boolean(order)
    }
  }

  if (!allowed) return null
  const [row] = await db
    .select({ contentType: files.contentType, data: files.data })
    .from(files)
    .where(eq(files.id, fileId))
    .limit(1)
  return row ?? null
}
