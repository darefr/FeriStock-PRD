import type { CreditState, OrderStatus, PaymentStatus } from '../constants'

export type OrderSide = 'retailer' | 'supplier'

/** Orders the supplier has committed to; payment and credit only apply from here on. */
const COMMITTED: readonly OrderStatus[] = ['accepted', 'packed', 'dispatched', 'delivered']
const CLOSED: readonly OrderStatus[] = ['cancelled', 'rejected']

export const isCommitted = (status: OrderStatus) => COMMITTED.includes(status)
export const isClosed = (status: OrderStatus) => CLOSED.includes(status)
export const isInProgress = (status: OrderStatus) =>
  status === 'pending' || status === 'accepted' || status === 'packed' || status === 'dispatched'

export function balanceOf(order: { totalPaisa: number; paidPaisa: number }): number {
  return Math.max(0, order.totalPaisa - order.paidPaisa)
}

export function derivePaymentStatus(input: {
  totalPaisa: number
  paidPaisa: number
  creditState: CreditState
  hasPendingProof: boolean
}): PaymentStatus {
  if (input.totalPaisa > 0 && input.paidPaisa >= input.totalPaisa) return 'paid'
  if (input.paidPaisa > 0) return 'partial'
  if (input.hasPendingProof) return 'pending'
  if (input.creditState === 'approved') return 'credit'
  return 'unpaid'
}

/** Approved credit that is past its due date with money still owed. */
export function isOverdue(
  order: { totalPaisa: number; paidPaisa: number; creditState: CreditState; dueDate: string | null; status: OrderStatus },
  today: string,
): boolean {
  if (order.creditState !== 'approved' || !order.dueDate || isClosed(order.status)) return false
  return balanceOf(order) > 0 && order.dueDate < today
}

export type OrderAction =
  | 'submit_draft'
  | 'cancel'
  | 'accept'
  | 'reject'
  | 'pack'
  | 'dispatch'
  | 'mark_delivered'
  | 'confirm_delivery'
  | 'pay'
  | 'request_credit'
  | 'decide_credit'
  | 'record_payment'

export type OrderActionInput = {
  status: OrderStatus
  totalPaisa: number
  paidPaisa: number
  creditState: CreditState
  stockSyncedAt: Date | string | null
}

/**
 * The single source of truth for what each party may do to an order in its current state.
 * The server enforces it and the interface uses it to decide which buttons to show.
 */
export function orderActions(order: OrderActionInput, side: OrderSide): Set<OrderAction> {
  const actions = new Set<OrderAction>()
  const owes = isCommitted(order.status) && balanceOf(order) > 0

  if (side === 'retailer') {
    if (order.status === 'draft') {
      actions.add('submit_draft')
      actions.add('cancel')
    }
    if (order.status === 'pending') actions.add('cancel')
    if (order.status === 'dispatched') actions.add('confirm_delivery')
    // The supplier closed the delivery; the shop still has to count the goods into stock.
    if (order.status === 'delivered' && !order.stockSyncedAt) actions.add('confirm_delivery')
    if (owes) {
      actions.add('pay')
      if (order.creditState === 'none' || order.creditState === 'declined') actions.add('request_credit')
    }
  } else {
    if (order.status === 'pending') {
      actions.add('accept')
      actions.add('reject')
    }
    if (order.status === 'accepted') actions.add('pack')
    if (order.status === 'packed') actions.add('dispatch')
    if (order.status === 'dispatched') actions.add('mark_delivered')
    // Once money has been received the order can no longer be cancelled from inside the app.
    if ((order.status === 'accepted' || order.status === 'packed') && order.paidPaisa === 0) actions.add('cancel')
    if (owes) actions.add('record_payment')
    if (isCommitted(order.status) && order.creditState === 'requested') actions.add('decide_credit')
  }

  return actions
}
