import 'server-only'
import { randomUUID } from 'node:crypto'
import { and, eq, isNull } from 'drizzle-orm'
import { LIMITS, PAYMENT_METHOD_LABEL, type GatewayEnv } from '@/lib/constants'
import { decryptSecret, randomToken } from '@/lib/crypto'
import { addDays, formatDateString, todayNpt } from '@/lib/dates'
import { db, type Tx } from '@/lib/db'
import { files, orders, paymentRecords, supplierPaymentConfigs, supplierSettings } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { formatNpr } from '@/lib/money'
import { assertAllowed, type AppContext } from '@/lib/context'
import { buildEsewaForm, checkEsewaPayment, type EsewaForm } from './gateways/esewa'
import { initiateKhaltiPayment, lookupKhaltiPayment } from './gateways/khalti'
import type { GatewayCheck } from './gateways/types'
import {
  actorOf,
  lockOrder,
  lockOrderAs,
  logOrderEvent,
  recomputeOrderPayment,
  sideOf,
  SYSTEM_ACTOR,
  type Actor,
} from './order-core'
import { balanceOf } from './order-rules'
import { issueReceipt } from './receipts'

// FeriStock never holds money. Wallet payments are created with the supplier's own merchant
// credentials and settle straight to the supplier; this module only records and verifies them.

/**
 * Marks a payment record as verified, updates the order's totals and issues the receipt —
 * all in one transaction, exactly once. A verified record is frozen by a database trigger.
 */
async function finalizeVerifiedPayment(
  tx: Tx,
  params: {
    paymentId: string
    orderId: string
    transactionRef: string | null
    rawResponse?: Record<string, unknown>
    verifiedBy: string | null
    actor: Actor
  },
): Promise<{ alreadyVerified: boolean; receiptId: string | null }> {
  await lockOrder(tx, params.orderId)
  const [payment] = await tx.select().from(paymentRecords).where(eq(paymentRecords.id, params.paymentId)).for('update')
  if (!payment) throw AppError.notFound('Payment not found.')
  if (payment.status === 'verified') return { alreadyVerified: true, receiptId: null }

  const now = new Date()
  const receiptId = randomUUID()
  const transactionRef = params.transactionRef ?? payment.transactionRef
  await tx
    .update(paymentRecords)
    .set({
      status: 'verified',
      transactionRef,
      rawResponse: params.rawResponse ?? payment.rawResponse,
      verifiedBy: params.verifiedBy,
      paidAt: now,
      verifiedAt: now,
      receiptUrl: `/app/receipts/${receiptId}`,
    })
    .where(eq(paymentRecords.id, payment.id))

  const order = await recomputeOrderPayment(tx, payment.orderId)
  await issueReceipt(tx, {
    receiptId,
    orderId: payment.orderId,
    kind: 'payment',
    payment: {
      id: payment.id,
      method: payment.method,
      transactionRef,
      gatewayTxnId: payment.gatewayTxnId,
      gatewayEnv: payment.gatewayEnv,
      amountPaisa: payment.amountPaisa,
      paidAt: now,
    },
  })

  const balance = balanceOf(order)
  await logOrderEvent(
    tx,
    payment.orderId,
    params.actor,
    'payment',
    `${formatNpr(payment.amountPaisa)} received via ${PAYMENT_METHOD_LABEL[payment.method]}${
      transactionRef ? ` (ref ${transactionRef})` : ''
    }. ${balance > 0 ? `Balance ${formatNpr(balance)}.` : 'Order paid in full.'}`,
    { amountPaisa: payment.amountPaisa, method: payment.method },
  )
  return { alreadyVerified: false, receiptId }
}

// ---------------------------------------------------------------------------
// eSewa / Khalti checkout
// ---------------------------------------------------------------------------

export type GatewayStart =
  | { kind: 'form'; paymentId: string; form: EsewaForm }
  | { kind: 'redirect'; paymentId: string; url: string }

export async function startGatewayPayment(
  context: AppContext,
  input: { orderId: string; method: 'esewa' | 'khalti'; amountPaisa: number },
  appUrl: string,
): Promise<GatewayStart> {
  assertAllowed(context, { capability: 'payments:manage', side: 'retailer' })

  const prepared = await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'retailer', 'pay')
    const balance = balanceOf(order)
    if (input.amountPaisa > balance) {
      throw AppError.invalid(`The outstanding balance on this order is ${formatNpr(balance)}.`)
    }
    const [config] = await tx
      .select()
      .from(supplierPaymentConfigs)
      .where(eq(supplierPaymentConfigs.orgId, order.supplierOrgId))
      .limit(1)

    if (input.method === 'esewa') {
      if (!config?.esewaEnabled || !config.esewaMerchantId || !config.esewaSecretEnc) {
        throw AppError.invalid('This supplier does not accept eSewa payments.')
      }
      const secret = decryptSecret(config.esewaSecretEnc)
      if (!secret) {
        throw AppError.config('The supplier needs to re-enter their eSewa credentials before eSewa payments can be taken.')
      }
      const transactionUuid = `${order.orderNo}-${randomToken()}`
      const [payment] = await tx
        .insert(paymentRecords)
        .values({
          orderId: order.id,
          method: 'esewa',
          gatewayTxnId: transactionUuid,
          gatewayEnv: config.esewaEnv,
          amountPaisa: input.amountPaisa,
          status: 'initiated',
          // Remembered so the status lookup still targets the right merchant if the supplier changes it later.
          rawResponse: { merchantCode: config.esewaMerchantId },
          createdBy: context.user.id,
        })
        .returning()
      return { order, payment, secret, merchantCode: config.esewaMerchantId, env: config.esewaEnv }
    }

    if (!config?.khaltiEnabled || !config.khaltiSecretEnc) {
      throw AppError.invalid('This supplier does not accept Khalti payments.')
    }
    if (input.amountPaisa < LIMITS.khaltiMinPaisa) {
      throw AppError.invalid(`Khalti payments start at ${formatNpr(LIMITS.khaltiMinPaisa)}.`)
    }
    const secret = decryptSecret(config.khaltiSecretEnc)
    if (!secret) {
      throw AppError.config('The supplier needs to re-enter their Khalti credentials before Khalti payments can be taken.')
    }
    const [payment] = await tx
      .insert(paymentRecords)
      .values({
        orderId: order.id,
        method: 'khalti',
        gatewayEnv: config.khaltiEnv,
        amountPaisa: input.amountPaisa,
        status: 'initiated',
        createdBy: context.user.id,
      })
      .returning()
    return { order, payment, secret, merchantCode: null, env: config.khaltiEnv }
  })

  const { order, payment, secret, env } = prepared

  if (payment.method === 'esewa') {
    const returnUrl = `${appUrl}/api/payments/esewa/return/${payment.id}`
    return {
      kind: 'form',
      paymentId: payment.id,
      form: buildEsewaForm({
        env,
        merchantCode: prepared.merchantCode as string,
        secret,
        amountPaisa: payment.amountPaisa,
        transactionUuid: payment.gatewayTxnId as string,
        successUrl: returnUrl,
        failureUrl: returnUrl,
      }),
    }
  }

  // The gateway call happens outside any database transaction so a slow gateway never holds locks.
  try {
    const { pidx, paymentUrl } = await initiateKhaltiPayment({
      env,
      secret,
      amountPaisa: payment.amountPaisa,
      purchaseOrderId: payment.id,
      purchaseOrderName: `FeriStock order ${order.orderNo}`,
      returnUrl: `${appUrl}/api/payments/khalti/return/${payment.id}`,
      websiteUrl: appUrl,
      customer: { name: context.org.name, email: context.user.email, phone: context.org.phone.replace(/\D/g, '').slice(-10) },
    })
    await db.update(paymentRecords).set({ gatewayTxnId: pidx }).where(eq(paymentRecords.id, payment.id))
    return { kind: 'redirect', paymentId: payment.id, url: paymentUrl }
  } catch (error) {
    await db
      .update(paymentRecords)
      .set({ status: 'failed', note: error instanceof Error ? error.message.slice(0, 280) : 'Could not start payment.' })
      .where(and(eq(paymentRecords.id, payment.id), eq(paymentRecords.status, 'initiated')))
    throw error
  }
}

export type VerificationOutcome = 'verified' | 'pending' | 'failed' | 'mismatch' | 'unavailable'

/**
 * Asks the gateway, server to server, whether a payment completed and for exactly the expected amount.
 * This is the only path that can mark a wallet payment as paid — browser redirects are never trusted.
 * Safe to call repeatedly: a payment that was abandoned can still be picked up later if the money moved.
 */
export async function verifyGatewayPayment(paymentId: string): Promise<{ outcome: VerificationOutcome; orderId: string }> {
  const [row] = await db
    .select({ payment: paymentRecords, order: orders, config: supplierPaymentConfigs })
    .from(paymentRecords)
    .innerJoin(orders, eq(orders.id, paymentRecords.orderId))
    .leftJoin(supplierPaymentConfigs, eq(supplierPaymentConfigs.orgId, orders.supplierOrgId))
    .where(eq(paymentRecords.id, paymentId))
    .limit(1)
  if (!row) throw AppError.notFound('Payment not found.')

  const { payment, order, config } = row
  if (payment.status === 'verified') return { outcome: 'verified', orderId: order.id }
  if (payment.method !== 'esewa' && payment.method !== 'khalti') {
    throw AppError.invalid('Only wallet payments are verified with a gateway.')
  }
  if (payment.status !== 'initiated' && payment.status !== 'failed') return { outcome: 'failed', orderId: order.id }
  if (!payment.gatewayTxnId) return { outcome: 'failed', orderId: order.id }

  const env: GatewayEnv = payment.gatewayEnv ?? 'test'
  let check: GatewayCheck
  if (payment.method === 'esewa') {
    const merchantCode = String(payment.rawResponse?.merchantCode ?? config?.esewaMerchantId ?? '')
    if (!merchantCode) return { outcome: 'unavailable', orderId: order.id }
    check = await checkEsewaPayment({
      env,
      merchantCode,
      amountPaisa: payment.amountPaisa,
      transactionUuid: payment.gatewayTxnId,
    })
    check.raw = { merchantCode, ...check.raw }
  } else {
    const secret = config?.khaltiSecretEnc ? decryptSecret(config.khaltiSecretEnc) : null
    if (!secret) return { outcome: 'unavailable', orderId: order.id }
    check = await lookupKhaltiPayment({ env, secret, pidx: payment.gatewayTxnId })
  }

  if (check.state === 'pending' || check.state === 'unavailable') {
    return { outcome: check.state, orderId: order.id }
  }

  if (check.state === 'failed') {
    await db
      .update(paymentRecords)
      .set({ status: 'failed', rawResponse: check.raw, note: `Gateway status: ${check.status}` })
      .where(and(eq(paymentRecords.id, payment.id), eq(paymentRecords.status, 'initiated')))
    return { outcome: 'failed', orderId: order.id }
  }

  // The gateway says the money moved. Credit it only if the amount is exactly what was requested.
  if (check.amountPaisa !== payment.amountPaisa) {
    await db.transaction(async (tx) => {
      const flagged = await tx
        .update(paymentRecords)
        .set({
          status: 'failed',
          rawResponse: check.raw,
          note: `Amount mismatch: expected ${formatNpr(payment.amountPaisa)}, gateway reported ${
            check.amountPaisa === null ? 'no amount' : formatNpr(check.amountPaisa)
          }.`,
        })
        .where(and(eq(paymentRecords.id, payment.id), eq(paymentRecords.status, 'initiated')))
        .returning({ id: paymentRecords.id })
      // Log once, the first time the mismatch is seen; later re-checks stay quiet.
      if (flagged.length === 0) return
      await logOrderEvent(
        tx,
        order.id,
        SYSTEM_ACTOR,
        'payment',
        `A ${PAYMENT_METHOD_LABEL[payment.method]} payment was not credited because the amount confirmed by the gateway did not match the amount requested. Contact the supplier before paying again.`,
      )
    })
    return { outcome: 'mismatch', orderId: order.id }
  }

  await db.transaction(async (tx) => {
    await finalizeVerifiedPayment(tx, {
      paymentId: payment.id,
      orderId: order.id,
      transactionRef: check.reference,
      rawResponse: check.raw,
      verifiedBy: null,
      actor: SYSTEM_ACTOR,
    })
  })
  return { outcome: 'verified', orderId: order.id }
}

/** Lets either party re-run verification for a wallet payment on one of their orders. */
export async function recheckGatewayPayment(context: AppContext, paymentId: string): Promise<VerificationOutcome> {
  const [row] = await db
    .select({ retailerOrgId: orders.retailerOrgId, supplierOrgId: orders.supplierOrgId })
    .from(paymentRecords)
    .innerJoin(orders, eq(orders.id, paymentRecords.orderId))
    .where(eq(paymentRecords.id, paymentId))
    .limit(1)
  if (!row || sideOf(row, context.org.id) === null) throw AppError.notFound('Payment not found.')
  const { outcome } = await verifyGatewayPayment(paymentId)
  return outcome
}

// ---------------------------------------------------------------------------
// QR / bank transfer with proof, confirmed by the supplier
// ---------------------------------------------------------------------------

export async function submitPaymentProof(
  context: AppContext,
  input: { orderId: string; amountPaisa: number; transactionRef: string; proofFileId: string | null; note: string },
): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'retailer' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'retailer', 'pay')
    const balance = balanceOf(order)
    if (input.amountPaisa > balance) {
      throw AppError.invalid(`The outstanding balance on this order is ${formatNpr(balance)}.`)
    }

    if (input.proofFileId) {
      const attached = await tx
        .update(files)
        .set({ orderId: order.id })
        .where(
          and(
            eq(files.id, input.proofFileId),
            eq(files.orgId, context.org.id),
            eq(files.kind, 'payment_proof'),
            isNull(files.orderId),
          ),
        )
        .returning({ id: files.id })
      if (attached.length === 0) throw AppError.invalid('The screenshot could not be attached. Please upload it again.')
    }

    await tx.insert(paymentRecords).values({
      orderId: order.id,
      method: 'qr_bank',
      transactionRef: input.transactionRef || null,
      amountPaisa: input.amountPaisa,
      status: 'pending_verification',
      proofFileId: input.proofFileId,
      note: input.note || null,
      createdBy: context.user.id,
    })
    await recomputeOrderPayment(tx, order.id)
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'payment',
      `Payment proof submitted for ${formatNpr(input.amountPaisa)}${
        input.transactionRef ? ` (ref ${input.transactionRef})` : ''
      }. Waiting for the supplier to confirm.`,
    )
  })
}

async function lockPendingProof(tx: Tx, context: AppContext, paymentId: string) {
  const [peek] = await tx
    .select({ orderId: paymentRecords.orderId })
    .from(paymentRecords)
    .where(eq(paymentRecords.id, paymentId))
    .limit(1)
  if (!peek) throw AppError.notFound('Payment not found.')
  await lockOrderAs(tx, context, peek.orderId, 'supplier')
  const [payment] = await tx.select().from(paymentRecords).where(eq(paymentRecords.id, paymentId)).for('update')
  if (payment.status !== 'pending_verification') {
    throw AppError.conflict('This payment has already been handled. Refresh to see its status.')
  }
  return payment
}

export async function confirmPaymentProof(context: AppContext, paymentId: string): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'supplier' })
  await db.transaction(async (tx) => {
    const payment = await lockPendingProof(tx, context, paymentId)
    await finalizeVerifiedPayment(tx, {
      paymentId: payment.id,
      orderId: payment.orderId,
      transactionRef: payment.transactionRef,
      verifiedBy: context.user.id,
      actor: actorOf(context),
    })
  })
}

export async function rejectPaymentProof(context: AppContext, paymentId: string, reason: string): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'supplier' })
  await db.transaction(async (tx) => {
    const payment = await lockPendingProof(tx, context, paymentId)
    await tx
      .update(paymentRecords)
      .set({ status: 'rejected', rejectReason: reason, verifiedBy: context.user.id })
      .where(eq(paymentRecords.id, payment.id))
    await recomputeOrderPayment(tx, payment.orderId)
    await logOrderEvent(
      tx,
      payment.orderId,
      actorOf(context),
      'payment',
      `Payment proof for ${formatNpr(payment.amountPaisa)} was not accepted: ${reason}`,
    )
  })
}

/** The supplier records money they received directly — cash, cheque or a transfer they have already checked. */
export async function recordReceivedPayment(
  context: AppContext,
  input: { orderId: string; amountPaisa: number; transactionRef: string; note: string },
): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'supplier' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'supplier', 'record_payment')
    const balance = balanceOf(order)
    if (input.amountPaisa > balance) {
      throw AppError.invalid(`The outstanding balance on this order is ${formatNpr(balance)}.`)
    }
    const [payment] = await tx
      .insert(paymentRecords)
      .values({
        orderId: order.id,
        method: 'cash',
        transactionRef: input.transactionRef || null,
        amountPaisa: input.amountPaisa,
        status: 'pending_verification',
        note: input.note || null,
        createdBy: context.user.id,
      })
      .returning()
    await finalizeVerifiedPayment(tx, {
      paymentId: payment.id,
      orderId: order.id,
      transactionRef: payment.transactionRef,
      verifiedBy: context.user.id,
      actor: actorOf(context),
    })
  })
}

// ---------------------------------------------------------------------------
// Credit (udharo)
// ---------------------------------------------------------------------------

export async function requestCredit(context: AppContext, orderId: string): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'retailer' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, orderId, 'retailer', 'request_credit')
    const [settings] = await tx
      .select({ creditEnabled: supplierSettings.creditEnabled })
      .from(supplierSettings)
      .where(eq(supplierSettings.orgId, order.supplierOrgId))
      .limit(1)
    if (!settings?.creditEnabled) throw AppError.invalid('This supplier does not offer credit.')
    await tx.update(orders).set({ creditState: 'requested' }).where(eq(orders.id, order.id))
    await logOrderEvent(tx, order.id, actorOf(context), 'credit', 'Asked the supplier to allow payment on credit (udharo).')
  })
}

export async function decideCredit(
  context: AppContext,
  input: { orderId: string; approve: boolean; dueDate: string | null },
): Promise<void> {
  assertAllowed(context, { capability: 'payments:manage', side: 'supplier' })
  const today = todayNpt()
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'supplier', 'decide_credit')
    if (input.approve) {
      if (!input.dueDate || input.dueDate < today) throw AppError.invalid('Choose a due date from today onwards.')
      if (input.dueDate > addDays(today, 365)) throw AppError.invalid('Choose a due date within the next year.')
      await tx.update(orders).set({ creditState: 'approved', dueDate: input.dueDate }).where(eq(orders.id, order.id))
    } else {
      await tx.update(orders).set({ creditState: 'declined', dueDate: null }).where(eq(orders.id, order.id))
    }
    await recomputeOrderPayment(tx, order.id)
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'credit',
      input.approve
        ? `Credit (udharo) approved. Payment is due by ${formatDateString(input.dueDate as string)}.`
        : 'Credit (udharo) declined.',
    )
  })
}
