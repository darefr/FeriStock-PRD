import 'server-only'
import { and, desc, eq, isNull } from 'drizzle-orm'
import type { StockReason } from '@/lib/constants'
import { db, type Tx } from '@/lib/db'
import { cartItems, orders, organizations, products, retailerInventory, stockMovements, user } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { assertAllowed, type AppContext } from '@/lib/context'
import type { AddInventoryInput } from '@/lib/validation'
import { stockStatus, suggestReorderQty, type StockStatus } from './stock-rules'

export type InventoryItemDto = {
  id: string
  name: string
  sku: string | null
  unit: string
  isCustom: boolean
  currentQty: number
  reorderThreshold: number
  reorderQty: number | null
  alertsEnabled: boolean
  autoReorder: boolean
  status: StockStatus
  /** Quantity a one-tap reorder would add to the cart; null when the item cannot be ordered from a catalog. */
  suggestedQty: number | null
  cartQty: number
  product: { id: string; pricePaisa: number; moq: number; isActive: boolean; schemeNote: string | null } | null
  supplier: { id: string; name: string } | null
  updatedAt: string
}

export async function listInventory(context: AppContext): Promise<InventoryItemDto[]> {
  assertAllowed(context, { side: 'retailer' })
  const rows = await db
    .select({
      item: retailerInventory,
      product: products,
      supplierName: organizations.name,
      cartQty: cartItems.qty,
    })
    .from(retailerInventory)
    .leftJoin(products, eq(products.id, retailerInventory.productId))
    .leftJoin(organizations, eq(organizations.id, products.supplierOrgId))
    .leftJoin(
      cartItems,
      and(eq(cartItems.productId, retailerInventory.productId), eq(cartItems.retailerOrgId, retailerInventory.retailerOrgId)),
    )
    .where(and(eq(retailerInventory.retailerOrgId, context.org.id), isNull(retailerInventory.archivedAt)))

  return rows
    .map(({ item, product, supplierName, cartQty }): InventoryItemDto => {
      const orderable = product !== null && product.isActive
      return {
        id: item.id,
        name: product?.name ?? item.customName ?? 'Unnamed item',
        sku: product?.sku ?? null,
        unit: product?.unit ?? item.customUnit ?? 'pcs',
        isCustom: product === null,
        currentQty: item.currentQty,
        reorderThreshold: item.reorderThreshold,
        reorderQty: item.reorderQty,
        alertsEnabled: item.alertsEnabled,
        autoReorder: item.autoReorder,
        status: stockStatus(item.currentQty, item.reorderThreshold),
        suggestedQty: orderable
          ? suggestReorderQty({
              currentQty: item.currentQty,
              reorderThreshold: item.reorderThreshold,
              reorderQty: item.reorderQty,
              moq: product.moq,
            })
          : null,
        cartQty: cartQty ?? 0,
        product: product
          ? {
              id: product.id,
              pricePaisa: product.pricePaisa,
              moq: product.moq,
              isActive: product.isActive,
              schemeNote: product.schemeNote,
            }
          : null,
        supplier: product && supplierName ? { id: product.supplierOrgId, name: supplierName } : null,
        updatedAt: item.updatedAt.toISOString(),
      }
    })
    .sort((a, b) => a.name.localeCompare(b.name))
}

/**
 * Applies a stock change and writes the matching ledger entry.
 * The caller must already hold a row lock on the inventory item (SELECT ... FOR UPDATE).
 */
export async function applyStockChange(
  tx: Tx,
  change: {
    item: { id: string; retailerOrgId: string; currentQty: number }
    newQty: number
    reason: StockReason
    orderId?: string | null
    userId: string | null
  },
): Promise<number> {
  const newQty = Math.max(0, change.newQty)
  const delta = newQty - change.item.currentQty
  if (delta === 0) return newQty
  await tx.update(retailerInventory).set({ currentQty: newQty }).where(eq(retailerInventory.id, change.item.id))
  await tx.insert(stockMovements).values({
    inventoryId: change.item.id,
    retailerOrgId: change.item.retailerOrgId,
    delta,
    qtyAfter: newQty,
    reason: change.reason,
    orderId: change.orderId ?? null,
    userId: change.userId,
  })
  return newQty
}

export async function addInventoryItem(context: AppContext, input: AddInventoryInput): Promise<string> {
  assertAllowed(context, { capability: 'inventory:manage', side: 'retailer' })
  const orgId = context.org.id

  return db.transaction(async (tx) => {
    if (input.productId) {
      const [product] = await tx
        .select({ id: products.id, supplierOrgId: products.supplierOrgId, isActive: products.isActive })
        .from(products)
        .where(eq(products.id, input.productId))
        .limit(1)
      if (!product || !product.isActive) throw AppError.invalid('This product is no longer available.')
      if (product.supplierOrgId === orgId) {
        throw AppError.invalid('Products from your own catalog cannot be tracked as purchased stock.')
      }

      const [existing] = await tx
        .select()
        .from(retailerInventory)
        .where(and(eq(retailerInventory.retailerOrgId, orgId), eq(retailerInventory.productId, product.id)))
        .for('update')
      if (existing && !existing.archivedAt) throw AppError.conflict('This product is already in your inventory.')
      if (existing) {
        await tx
          .update(retailerInventory)
          .set({ archivedAt: null, reorderThreshold: input.reorderThreshold, reorderQty: input.reorderQty })
          .where(eq(retailerInventory.id, existing.id))
        await applyStockChange(tx, {
          item: existing,
          newQty: input.currentQty,
          reason: 'correction',
          userId: context.user.id,
        })
        return existing.id
      }

      const [created] = await tx
        .insert(retailerInventory)
        .values({
          retailerOrgId: orgId,
          productId: product.id,
          preferredSupplierId: product.supplierOrgId,
          currentQty: 0,
          reorderThreshold: input.reorderThreshold,
          reorderQty: input.reorderQty,
        })
        .returning()
      await applyStockChange(tx, { item: created, newQty: input.currentQty, reason: 'initial', userId: context.user.id })
      return created.id
    }

    const [created] = await tx
      .insert(retailerInventory)
      .values({
        retailerOrgId: orgId,
        customName: input.customName,
        customUnit: input.customUnit,
        currentQty: 0,
        reorderThreshold: input.reorderThreshold,
        reorderQty: input.reorderQty,
      })
      .returning()
    await applyStockChange(tx, { item: created, newQty: input.currentQty, reason: 'initial', userId: context.user.id })
    return created.id
  })
}

async function lockItem(tx: Tx, context: AppContext, inventoryId: string) {
  const [item] = await tx
    .select()
    .from(retailerInventory)
    .where(
      and(
        eq(retailerInventory.id, inventoryId),
        eq(retailerInventory.retailerOrgId, context.org.id),
        isNull(retailerInventory.archivedAt),
      ),
    )
    .for('update')
  if (!item) throw AppError.notFound('This item is no longer in your inventory.')
  return item
}

/** Counts stock up or down. Never goes below zero; returns the quantity actually on record afterwards. */
export async function adjustStock(context: AppContext, inventoryId: string, delta: number): Promise<number> {
  assertAllowed(context, { capability: 'stock:update', side: 'retailer' })
  return db.transaction(async (tx) => {
    const item = await lockItem(tx, context, inventoryId)
    return applyStockChange(tx, {
      item,
      newQty: item.currentQty + delta,
      reason: 'manual',
      userId: context.user.id,
    })
  })
}

/** Sets the counted quantity outright, for example after a shelf count. */
export async function setStock(context: AppContext, inventoryId: string, qty: number): Promise<number> {
  assertAllowed(context, { capability: 'stock:update', side: 'retailer' })
  return db.transaction(async (tx) => {
    const item = await lockItem(tx, context, inventoryId)
    return applyStockChange(tx, { item, newQty: qty, reason: 'correction', userId: context.user.id })
  })
}

export async function updateInventorySettings(
  context: AppContext,
  input: {
    inventoryId: string
    reorderThreshold: number
    reorderQty: number | null
    alertsEnabled: boolean
    autoReorder: boolean
  },
): Promise<void> {
  assertAllowed(context, { capability: 'inventory:manage', side: 'retailer' })
  const updated = await db
    .update(retailerInventory)
    .set({
      reorderThreshold: input.reorderThreshold,
      reorderQty: input.reorderQty,
      alertsEnabled: input.alertsEnabled,
      autoReorder: input.autoReorder,
    })
    .where(
      and(
        eq(retailerInventory.id, input.inventoryId),
        eq(retailerInventory.retailerOrgId, context.org.id),
        isNull(retailerInventory.archivedAt),
      ),
    )
    .returning({ id: retailerInventory.id })
  if (updated.length === 0) throw AppError.notFound('This item is no longer in your inventory.')
}

/** Stops tracking an item. Its stock history is kept, and re-adding the product restores it. */
export async function archiveInventoryItem(context: AppContext, inventoryId: string): Promise<void> {
  assertAllowed(context, { capability: 'inventory:manage', side: 'retailer' })
  await db
    .update(retailerInventory)
    .set({ archivedAt: new Date() })
    .where(and(eq(retailerInventory.id, inventoryId), eq(retailerInventory.retailerOrgId, context.org.id)))
}

export type StockMovementDto = {
  id: string
  delta: number
  qtyAfter: number
  reason: StockReason
  orderNo: string | null
  orderId: string | null
  userName: string | null
  createdAt: string
}

export async function getStockHistory(context: AppContext, inventoryId: string): Promise<StockMovementDto[]> {
  assertAllowed(context, { side: 'retailer' })
  const rows = await db
    .select({
      id: stockMovements.id,
      delta: stockMovements.delta,
      qtyAfter: stockMovements.qtyAfter,
      reason: stockMovements.reason,
      orderId: stockMovements.orderId,
      orderNo: orders.orderNo,
      userName: user.name,
      createdAt: stockMovements.createdAt,
    })
    .from(stockMovements)
    .leftJoin(user, eq(user.id, stockMovements.userId))
    .leftJoin(orders, eq(orders.id, stockMovements.orderId))
    .where(and(eq(stockMovements.inventoryId, inventoryId), eq(stockMovements.retailerOrgId, context.org.id)))
    .orderBy(desc(stockMovements.createdAt))
    .limit(40)
  return rows.map((row) => ({ ...row, createdAt: row.createdAt.toISOString() }))
}
