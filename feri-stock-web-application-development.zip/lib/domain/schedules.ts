import 'server-only'
import { and, asc, eq, inArray, lte } from 'drizzle-orm'
import type { ScheduleFrequency, ScheduleMode } from '@/lib/constants'
import { db, type Tx } from '@/lib/db'
import { orders, organizations, products, recurringScheduleItems, recurringSchedules } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { sortTiers, unitPriceForQty } from '@/lib/money'
import { computeNextRun } from '@/lib/schedule'
import { assertAllowed, type AppContext } from '@/lib/context'
import type { ScheduleInput } from '@/lib/validation'
import { insertOrder, logOrderEvent, SYSTEM_ACTOR, type OrderLineInput } from './order-core'

export type ScheduleDto = {
  id: string
  name: string
  supplier: { id: string; name: string }
  frequency: ScheduleFrequency
  dayOfWeek: number | null
  dayOfMonth: number | null
  timeOfDay: string
  mode: ScheduleMode
  isActive: boolean
  nextRunAt: string
  lastRunAt: string | null
  lastOrder: { id: string; orderNo: string } | null
  items: Array<{ productId: string; name: string; sku: string; unit: string; qty: number; moq: number; isActive: boolean }>
}

export async function listSchedules(context: AppContext): Promise<ScheduleDto[]> {
  assertAllowed(context, { side: 'retailer' })
  const rows = await db
    .select({ schedule: recurringSchedules, supplierName: organizations.name, lastOrderNo: orders.orderNo })
    .from(recurringSchedules)
    .innerJoin(organizations, eq(organizations.id, recurringSchedules.supplierOrgId))
    .leftJoin(orders, eq(orders.id, recurringSchedules.lastOrderId))
    .where(eq(recurringSchedules.retailerOrgId, context.org.id))
    .orderBy(asc(recurringSchedules.nextRunAt))
  if (rows.length === 0) return []

  const itemRows = await db
    .select({ item: recurringScheduleItems, product: products })
    .from(recurringScheduleItems)
    .innerJoin(products, eq(products.id, recurringScheduleItems.productId))
    .where(
      inArray(
        recurringScheduleItems.scheduleId,
        rows.map((row) => row.schedule.id),
      ),
    )
    .orderBy(asc(products.name))

  return rows.map(({ schedule, supplierName, lastOrderNo }) => ({
    id: schedule.id,
    name: schedule.name,
    supplier: { id: schedule.supplierOrgId, name: supplierName },
    frequency: schedule.frequency,
    dayOfWeek: schedule.dayOfWeek,
    dayOfMonth: schedule.dayOfMonth,
    timeOfDay: schedule.timeOfDay,
    mode: schedule.mode,
    isActive: schedule.isActive,
    nextRunAt: schedule.nextRunAt.toISOString(),
    lastRunAt: schedule.lastRunAt?.toISOString() ?? null,
    lastOrder: schedule.lastOrderId && lastOrderNo ? { id: schedule.lastOrderId, orderNo: lastOrderNo } : null,
    items: itemRows
      .filter(({ item }) => item.scheduleId === schedule.id)
      .map(({ item, product }) => ({
        productId: product.id,
        name: product.name,
        sku: product.sku,
        unit: product.unit,
        qty: item.qty,
        moq: product.moq,
        isActive: product.isActive,
      })),
  }))
}

export async function saveSchedule(context: AppContext, input: ScheduleInput): Promise<string> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  const orgId = context.org.id
  if (input.supplierOrgId === orgId) throw AppError.invalid('Choose another organization as the supplier.')

  const productIds = [...new Set(input.items.map((item) => item.productId))]
  if (productIds.length !== input.items.length) throw AppError.invalid('Each product can appear only once in a schedule.')

  return db.transaction(async (tx) => {
    const found = await tx
      .select({ id: products.id, name: products.name, moq: products.moq, unit: products.unit })
      .from(products)
      .where(
        and(inArray(products.id, productIds), eq(products.supplierOrgId, input.supplierOrgId), eq(products.isActive, true)),
      )
    if (found.length !== productIds.length) {
      throw AppError.invalid('Some of these products are no longer available from this supplier.')
    }
    for (const product of found) {
      const line = input.items.find((item) => item.productId === product.id)
      if (line && line.qty < product.moq) {
        throw AppError.invalid(`${product.name} has a minimum order of ${product.moq} ${product.unit}.`)
      }
    }

    const rule = {
      frequency: input.frequency,
      dayOfWeek: input.frequency === 'weekly' ? input.dayOfWeek : null,
      dayOfMonth: input.frequency === 'monthly' ? input.dayOfMonth : null,
      timeOfDay: input.timeOfDay,
    }
    const values = {
      supplierOrgId: input.supplierOrgId,
      name: input.name,
      ...rule,
      mode: input.mode,
      isActive: input.isActive,
      nextRunAt: computeNextRun(rule, new Date()),
    }

    let scheduleId = input.id
    if (scheduleId) {
      const updated = await tx
        .update(recurringSchedules)
        .set(values)
        .where(and(eq(recurringSchedules.id, scheduleId), eq(recurringSchedules.retailerOrgId, orgId)))
        .returning({ id: recurringSchedules.id })
      if (updated.length === 0) throw AppError.notFound('Schedule not found.')
      await tx.delete(recurringScheduleItems).where(eq(recurringScheduleItems.scheduleId, scheduleId))
    } else {
      const [created] = await tx
        .insert(recurringSchedules)
        .values({ retailerOrgId: orgId, createdBy: context.user.id, ...values })
        .returning({ id: recurringSchedules.id })
      scheduleId = created.id
    }

    await tx
      .insert(recurringScheduleItems)
      .values(input.items.map((item) => ({ scheduleId: scheduleId as string, productId: item.productId, qty: item.qty })))
    return scheduleId
  })
}

export async function setScheduleActive(context: AppContext, scheduleId: string, isActive: boolean): Promise<void> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  await db.transaction(async (tx) => {
    const [schedule] = await tx
      .select()
      .from(recurringSchedules)
      .where(and(eq(recurringSchedules.id, scheduleId), eq(recurringSchedules.retailerOrgId, context.org.id)))
      .for('update')
    if (!schedule) throw AppError.notFound('Schedule not found.')
    await tx
      .update(recurringSchedules)
      // Resuming starts from the next future slot instead of firing for the time it was paused.
      .set({ isActive, ...(isActive ? { nextRunAt: computeNextRun(schedule, new Date()) } : {}) })
      .where(eq(recurringSchedules.id, schedule.id))
  })
}

export async function deleteSchedule(context: AppContext, scheduleId: string): Promise<void> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  await db
    .delete(recurringSchedules)
    .where(and(eq(recurringSchedules.id, scheduleId), eq(recurringSchedules.retailerOrgId, context.org.id)))
}

type RunResult = { orderId: string; orderNo: string; status: 'draft' | 'pending' } | null

/**
 * Generates the order for one schedule and moves it to its next slot.
 * The schedule row is locked and re-checked, so two triggers at the same moment
 * (the daily job and someone opening the app) can never produce two orders.
 */
async function executeSchedule(tx: Tx, scheduleId: string, options: { force: boolean; now: Date }): Promise<RunResult> {
  const [schedule] = await tx.select().from(recurringSchedules).where(eq(recurringSchedules.id, scheduleId)).for('update')
  if (!schedule) return null
  if (!options.force && (!schedule.isActive || schedule.nextRunAt.getTime() > options.now.getTime())) return null

  const rows = await tx
    .select({ item: recurringScheduleItems, product: products })
    .from(recurringScheduleItems)
    .innerJoin(products, eq(products.id, recurringScheduleItems.productId))
    .where(eq(recurringScheduleItems.scheduleId, schedule.id))
    .orderBy(asc(products.name))

  const available = rows.filter(({ product }) => product.isActive)
  const lines: OrderLineInput[] = available.map(({ item, product }) => {
    const qty = Math.max(item.qty, product.moq)
    return {
      productId: product.id,
      sku: product.sku,
      name: product.name,
      unit: product.unit,
      qty,
      unitPricePaisa: unitPriceForQty(product.pricePaisa, sortTiers(product.bulkTiersJson ?? []), qty),
    }
  })

  let result: RunResult = null
  if (lines.length > 0) {
    const status = schedule.mode === 'auto' ? 'pending' : 'draft'
    const order = await insertOrder(tx, {
      retailerOrgId: schedule.retailerOrgId,
      supplierOrgId: schedule.supplierOrgId,
      orderType: 'scheduled',
      status,
      lines,
      retailerNote: `Recurring order: ${schedule.name}`,
      placedBy: schedule.createdBy,
      scheduleId: schedule.id,
    })
    const skipped = rows.length - available.length
    await logOrderEvent(
      tx,
      order.id,
      SYSTEM_ACTOR,
      'status',
      `${status === 'pending' ? 'Sent automatically' : 'Draft created'} by the recurring schedule “${schedule.name}”${
        skipped > 0 ? `; ${skipped} unavailable ${skipped === 1 ? 'product was' : 'products were'} left out` : ''
      }.`,
      { status },
    )
    result = { orderId: order.id, orderNo: order.orderNo, status }
  }

  await tx
    .update(recurringSchedules)
    .set({
      lastRunAt: options.now,
      // One order per run even after a long gap: skip straight to the next future slot.
      nextRunAt: computeNextRun(schedule, options.now),
      ...(result ? { lastOrderId: result.orderId } : {}),
    })
    .where(eq(recurringSchedules.id, schedule.id))
  return result
}

export async function runScheduleNow(context: AppContext, scheduleId: string): Promise<RunResult> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  return db.transaction(async (tx) => {
    const [owned] = await tx
      .select({ id: recurringSchedules.id })
      .from(recurringSchedules)
      .where(and(eq(recurringSchedules.id, scheduleId), eq(recurringSchedules.retailerOrgId, context.org.id)))
      .limit(1)
    if (!owned) throw AppError.notFound('Schedule not found.')
    const result = await executeSchedule(tx, scheduleId, { force: true, now: new Date() })
    if (!result) throw AppError.invalid('None of the products in this schedule are available right now.')
    return result
  })
}

/**
 * Runs every schedule whose time has come. Called by the daily cron job for all organizations,
 * and for a single organization whenever one of its members opens the app, so schedules
 * keep working even without a cron job.
 */
export async function runDueSchedules(options: { orgId?: string } = {}): Promise<{ ran: number; orders: number }> {
  const now = new Date()
  const due = await db
    .select({ id: recurringSchedules.id })
    .from(recurringSchedules)
    .where(
      and(
        eq(recurringSchedules.isActive, true),
        lte(recurringSchedules.nextRunAt, now),
        options.orgId ? eq(recurringSchedules.retailerOrgId, options.orgId) : undefined,
      ),
    )
    .orderBy(asc(recurringSchedules.nextRunAt))
    .limit(200)

  let ran = 0
  let created = 0
  for (const { id } of due) {
    try {
      const result = await db.transaction((tx) => executeSchedule(tx, id, { force: false, now }))
      ran += 1
      if (result) created += 1
    } catch (error) {
      console.error('[schedules] failed to run schedule', id, error)
    }
  }
  return { ran, orders: created }
}
