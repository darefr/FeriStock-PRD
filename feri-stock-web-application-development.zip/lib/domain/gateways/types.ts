/** The outcome of asking a payment gateway, server to server, what happened to a transaction. */
export type GatewayCheck = {
  /**
   * complete    — the gateway confirms the money moved
   * pending     — started but not finished; check again later
   * failed      — cancelled, expired, refunded or not found
   * unavailable — the gateway could not be reached or gave an unknown answer
   */
  state: 'complete' | 'pending' | 'failed' | 'unavailable'
  /** The gateway's own status word, kept for the audit trail. */
  status: string
  /** The gateway's transaction reference (eSewa ref_id / Khalti transaction_id). */
  reference: string | null
  amountPaisa: number | null
  raw: Record<string, unknown>
}
