import 'server-only'
import type { GatewayEnv } from '@/lib/constants'
import { AppError } from '@/lib/errors'
import type { GatewayCheck } from './types'

// Khalti Web Checkout (KPG-2) — https://docs.khalti.com/khalti-epayment/
// Each request is authorised with the *supplier's* secret key, so the payment
// is created in, and settles to, the supplier's own Khalti merchant account.

const BASE_URL: Record<GatewayEnv, string> = {
  test: 'https://dev.khalti.com/api/v2',
  live: 'https://khalti.com/api/v2',
}

async function khaltiRequest(
  env: GatewayEnv,
  secret: string,
  path: string,
  payload: Record<string, unknown>,
): Promise<{ httpStatus: number; body: Record<string, unknown> }> {
  const response = await fetch(`${BASE_URL[env]}${path}`, {
    method: 'POST',
    headers: { Authorization: `Key ${secret}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    cache: 'no-store',
    signal: AbortSignal.timeout(15_000),
  })
  const body = (await response.json().catch(() => ({}))) as Record<string, unknown>
  return { httpStatus: response.status, body }
}

function firstMessage(body: Record<string, unknown>): string | null {
  for (const [key, value] of Object.entries(body)) {
    if (key === 'error_key' || key === 'status_code') continue
    if (typeof value === 'string') return value
    if (Array.isArray(value) && typeof value[0] === 'string') return value[0]
  }
  return null
}

export async function initiateKhaltiPayment(input: {
  env: GatewayEnv
  secret: string
  amountPaisa: number
  purchaseOrderId: string
  purchaseOrderName: string
  returnUrl: string
  websiteUrl: string
  customer: { name: string; email: string; phone: string }
}): Promise<{ pidx: string; paymentUrl: string }> {
  let result: Awaited<ReturnType<typeof khaltiRequest>>
  try {
    result = await khaltiRequest(input.env, input.secret, '/epayment/initiate/', {
      return_url: input.returnUrl,
      website_url: input.websiteUrl,
      amount: input.amountPaisa,
      purchase_order_id: input.purchaseOrderId,
      purchase_order_name: input.purchaseOrderName,
      customer_info: input.customer,
    })
  } catch {
    throw AppError.gateway('Khalti could not be reached. Please try again in a moment.')
  }

  const { httpStatus, body } = result
  if (httpStatus === 401) {
    throw AppError.gateway('Khalti rejected the supplier’s credentials. Ask the supplier to check their Khalti setup.')
  }
  if (httpStatus >= 400 || typeof body.pidx !== 'string' || typeof body.payment_url !== 'string') {
    throw AppError.gateway(firstMessage(body) ?? 'Khalti could not start this payment.')
  }
  return { pidx: body.pidx, paymentUrl: body.payment_url }
}

/** Server-to-server lookup — the authority on whether a Khalti payment completed. */
export async function lookupKhaltiPayment(input: { env: GatewayEnv; secret: string; pidx: string }): Promise<GatewayCheck> {
  let result: Awaited<ReturnType<typeof khaltiRequest>>
  try {
    result = await khaltiRequest(input.env, input.secret, '/epayment/lookup/', { pidx: input.pidx })
  } catch (error) {
    return {
      state: 'unavailable',
      status: 'UNREACHABLE',
      reference: null,
      amountPaisa: null,
      raw: { error: error instanceof Error ? error.message : 'request failed' },
    }
  }

  const { body } = result
  const status = String(body.status ?? '')
  const base = {
    status: status || 'UNKNOWN',
    reference: body.transaction_id ? String(body.transaction_id) : null,
    amountPaisa: typeof body.total_amount === 'number' ? Math.round(body.total_amount) : null,
    raw: body,
  }

  // Khalti: "Only the status with Completed must be treated as success."
  if (status === 'Completed') {
    const sameTransaction = String(body.pidx ?? '') === input.pidx && body.refunded !== true
    return { ...base, state: sameTransaction ? 'complete' : 'failed' }
  }
  if (status === 'Pending' || status === 'Initiated') return { ...base, state: 'pending' }
  if (status === 'Expired' || status === 'User canceled' || status === 'Refunded' || status === 'Partially Refunded') {
    return { ...base, state: 'failed' }
  }
  return { ...base, state: 'unavailable' }
}

/**
 * Checks a secret key without creating a payment: looking up a pidx that cannot exist
 * returns 401 for a bad key and a validation error for a good one.
 */
export async function checkKhaltiKey(input: { env: GatewayEnv; secret: string }): Promise<'valid' | 'invalid' | 'unknown'> {
  try {
    const { httpStatus } = await khaltiRequest(input.env, input.secret, '/epayment/lookup/', {
      pidx: 'feristock-key-check',
    })
    if (httpStatus === 401 || httpStatus === 403) return 'invalid'
    if (httpStatus === 400 || httpStatus === 404 || httpStatus === 200) return 'valid'
    return 'unknown'
  } catch {
    return 'unknown'
  }
}
