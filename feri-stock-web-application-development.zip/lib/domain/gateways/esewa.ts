import 'server-only'
import type { GatewayEnv } from '@/lib/constants'
import { hmacSha256Base64 } from '@/lib/crypto'
import { paisaToRupeeString } from '@/lib/money'
import type { GatewayCheck } from './types'

// eSewa ePay v2 — https://developer.esewa.com.np/pages/Epay
// The buyer's browser posts a signed form to eSewa using the *supplier's* merchant code,
// so the money settles directly into the supplier's eSewa merchant wallet.

const ENDPOINTS: Record<GatewayEnv, { form: string; status: string }> = {
  test: {
    form: 'https://rc-epay.esewa.com.np/api/epay/main/v2/form',
    status: 'https://rc.esewa.com.np/api/epay/transaction/status/',
  },
  live: {
    form: 'https://epay.esewa.com.np/api/epay/main/v2/form',
    status: 'https://esewa.com.np/api/epay/transaction/status/',
  },
}

const SIGNED_FIELDS = 'total_amount,transaction_uuid,product_code'

export function esewaRequestSignature(
  secret: string,
  fields: { totalAmount: string; transactionUuid: string; productCode: string },
): string {
  return hmacSha256Base64(
    secret,
    `total_amount=${fields.totalAmount},transaction_uuid=${fields.transactionUuid},product_code=${fields.productCode}`,
  )
}

export type EsewaForm = { action: string; fields: Record<string, string> }

export function buildEsewaForm(input: {
  env: GatewayEnv
  merchantCode: string
  secret: string
  amountPaisa: number
  transactionUuid: string
  successUrl: string
  failureUrl: string
}): EsewaForm {
  const totalAmount = paisaToRupeeString(input.amountPaisa)
  return {
    action: ENDPOINTS[input.env].form,
    fields: {
      amount: totalAmount,
      tax_amount: '0',
      total_amount: totalAmount,
      transaction_uuid: input.transactionUuid,
      product_code: input.merchantCode,
      product_service_charge: '0',
      product_delivery_charge: '0',
      success_url: input.successUrl,
      failure_url: input.failureUrl,
      signed_field_names: SIGNED_FIELDS,
      signature: esewaRequestSignature(input.secret, {
        totalAmount,
        transactionUuid: input.transactionUuid,
        productCode: input.merchantCode,
      }),
    },
  }
}

/** eSewa reports rupees, sometimes formatted ("1,000.0"); convert to paisa or null when unreadable. */
export function esewaAmountToPaisa(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null
  const parsed = typeof value === 'number' ? value : Number(String(value).replace(/,/g, ''))
  if (!Number.isFinite(parsed) || parsed < 0) return null
  return Math.round(parsed * 100)
}

/** Server-to-server status lookup — the authority on whether an eSewa payment completed. */
export async function checkEsewaPayment(input: {
  env: GatewayEnv
  merchantCode: string
  amountPaisa: number
  transactionUuid: string
}): Promise<GatewayCheck> {
  const url = new URL(ENDPOINTS[input.env].status)
  url.searchParams.set('product_code', input.merchantCode)
  url.searchParams.set('total_amount', paisaToRupeeString(input.amountPaisa))
  url.searchParams.set('transaction_uuid', input.transactionUuid)

  let body: Record<string, unknown>
  try {
    const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(15_000) })
    body = (await response.json()) as Record<string, unknown>
  } catch (error) {
    return {
      state: 'unavailable',
      status: 'UNREACHABLE',
      reference: null,
      amountPaisa: null,
      raw: { error: error instanceof Error ? error.message : 'request failed' },
    }
  }

  const status = String(body.status ?? '')
  const base = {
    status: status || 'UNKNOWN',
    reference: body.ref_id ? String(body.ref_id) : null,
    amountPaisa: esewaAmountToPaisa(body.total_amount),
    raw: body,
  }

  if (status === 'COMPLETE') {
    // Guard against a response for some other transaction or merchant.
    const sameTransaction =
      String(body.transaction_uuid ?? '') === input.transactionUuid &&
      String(body.product_code ?? '') === input.merchantCode
    return { ...base, state: sameTransaction ? 'complete' : 'failed' }
  }
  if (status === 'PENDING' || status === 'AMBIGUOUS') return { ...base, state: 'pending' }
  if (status === 'NOT_FOUND' || status === 'CANCELED' || status === 'FULL_REFUND' || status === 'PARTIAL_REFUND') {
    return { ...base, state: 'failed' }
  }
  return { ...base, state: 'unavailable' }
}
