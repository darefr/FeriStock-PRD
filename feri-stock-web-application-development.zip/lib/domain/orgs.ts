import 'server-only'
import { and, asc, count, desc, eq, gt, isNull } from 'drizzle-orm'
import { LIMITS, type DeliveryMode, type GatewayEnv, type MemberRole } from '@/lib/constants'
import { encryptSecret, generateInviteCode } from '@/lib/crypto'
import { db, type Executor } from '@/lib/db'
import {
  invites,
  memberships,
  orders,
  organizations,
  products,
  retailerInventory,
  supplierPaymentConfigs,
  supplierSettings,
  user,
  type BankDetails,
  type Organization,
} from '@/lib/db/schema'
import { AppError, isUniqueViolation } from '@/lib/errors'
import { assertAllowed, type AppContext, type SessionUser } from '@/lib/context'
import type { OrganizationInput, PaymentConfigInput, SupplierSettingsInput } from '@/lib/validation'
import { checkKhaltiKey } from './gateways/khalti'

async function ensureSupplierRows(executor: Executor, orgId: string) {
  await executor.insert(supplierSettings).values({ orgId }).onConflictDoNothing()
  await executor.insert(supplierPaymentConfigs).values({ orgId }).onConflictDoNothing()
}

export async function createOrganization(currentUser: SessionUser, input: OrganizationInput): Promise<Organization> {
  try {
    return await db.transaction(async (tx) => {
      const [org] = await tx
        .insert(organizations)
        .values({
          name: input.name,
          role: input.role,
          panVatNo: input.panVatNo,
          city: input.city,
          address: input.address,
          phone: input.phone,
          email: input.email || null,
        })
        .returning()
      // The unique index on memberships.user_id rejects a second organization for the same user.
      await tx.insert(memberships).values({ orgId: org.id, userId: currentUser.id, role: 'owner' })
      if (org.role !== 'retailer') await ensureSupplierRows(tx, org.id)
      return org
    })
  } catch (error) {
    if (isUniqueViolation(error)) throw AppError.conflict('You already belong to an organization.')
    throw error
  }
}

export async function joinOrganization(currentUser: SessionUser, code: string): Promise<string> {
  try {
    return await db.transaction(async (tx) => {
      const [invite] = await tx.select().from(invites).where(eq(invites.code, code)).for('update')
      if (!invite || invite.revokedAt || invite.usedAt || invite.expiresAt.getTime() < Date.now()) {
        throw AppError.invalid('This invite code is not valid. Ask the organization owner for a new one.')
      }
      await tx.insert(memberships).values({ orgId: invite.orgId, userId: currentUser.id, role: invite.role })
      await tx.update(invites).set({ usedBy: currentUser.id, usedAt: new Date() }).where(eq(invites.id, invite.id))
      return invite.orgId
    })
  } catch (error) {
    if (isUniqueViolation(error)) throw AppError.conflict('You already belong to an organization.')
    throw error
  }
}

export async function updateOrganization(context: AppContext, input: OrganizationInput): Promise<void> {
  assertAllowed(context, { capability: 'org:manage' })
  const orgId = context.org.id

  if (input.role !== context.org.role) {
    if (input.role === 'retailer') {
      const [{ value: productCount }] = await db
        .select({ value: count() })
        .from(products)
        .where(eq(products.supplierOrgId, orgId))
      const [{ value: salesCount }] = await db
        .select({ value: count() })
        .from(orders)
        .where(eq(orders.supplierOrgId, orgId))
      if (productCount > 0 || salesCount > 0) {
        throw AppError.invalid(
          'This organization already has a catalog or sales orders, so it has to stay a supplier. Choose “Retail + Wholesale” instead.',
        )
      }
    }
    if (input.role === 'supplier') {
      const [{ value: inventoryCount }] = await db
        .select({ value: count() })
        .from(retailerInventory)
        .where(eq(retailerInventory.retailerOrgId, orgId))
      const [{ value: purchaseCount }] = await db
        .select({ value: count() })
        .from(orders)
        .where(eq(orders.retailerOrgId, orgId))
      if (inventoryCount > 0 || purchaseCount > 0) {
        throw AppError.invalid(
          'This organization already tracks stock or has purchase orders, so it has to stay a retailer. Choose “Retail + Wholesale” instead.',
        )
      }
    }
  }

  await db.transaction(async (tx) => {
    await tx
      .update(organizations)
      .set({
        name: input.name,
        role: input.role,
        panVatNo: input.panVatNo,
        city: input.city,
        address: input.address,
        phone: input.phone,
        email: input.email || null,
      })
      .where(eq(organizations.id, orgId))
    if (input.role !== 'retailer') await ensureSupplierRows(tx, orgId)
  })
}

// ---------------------------------------------------------------------------
// Supplier terms
// ---------------------------------------------------------------------------

export type SupplierSettingsDto = {
  deliveryModes: DeliveryMode[]
  deliveryNote: string
  creditEnabled: boolean
  creditDays: number
  minOrderPaisa: number
}

export async function getSupplierSettings(orgId: string): Promise<SupplierSettingsDto> {
  const [row] = await db.select().from(supplierSettings).where(eq(supplierSettings.orgId, orgId)).limit(1)
  return {
    deliveryModes: row?.deliveryModes ?? ['own_van', 'bilti', 'pickup'],
    deliveryNote: row?.deliveryNote ?? '',
    creditEnabled: row?.creditEnabled ?? false,
    creditDays: row?.creditDays ?? 15,
    minOrderPaisa: row?.minOrderPaisa ?? 0,
  }
}

export async function updateSupplierSettings(context: AppContext, input: SupplierSettingsInput): Promise<void> {
  assertAllowed(context, { capability: 'org:manage', side: 'supplier' })
  const values = {
    deliveryModes: [...new Set(input.deliveryModes)],
    deliveryNote: input.deliveryNote,
    creditEnabled: input.creditEnabled,
    creditDays: input.creditDays,
    minOrderPaisa: input.minOrderPaisa,
  }
  await db
    .insert(supplierSettings)
    .values({ orgId: context.org.id, ...values })
    .onConflictDoUpdate({ target: supplierSettings.orgId, set: values })
}

// ---------------------------------------------------------------------------
// Payment methods. Secrets go in encrypted and never come back out to a browser.
// ---------------------------------------------------------------------------

export type PaymentConfigView = {
  esewa: { enabled: boolean; merchantId: string; env: GatewayEnv; hasSecret: boolean }
  khalti: { enabled: boolean; env: GatewayEnv; hasSecret: boolean }
  bank: BankDetails | null
  qrFileId: string | null
}

export async function getPaymentConfigView(orgId: string): Promise<PaymentConfigView> {
  const [row] = await db.select().from(supplierPaymentConfigs).where(eq(supplierPaymentConfigs.orgId, orgId)).limit(1)
  return {
    esewa: {
      enabled: row?.esewaEnabled ?? false,
      merchantId: row?.esewaMerchantId ?? '',
      env: row?.esewaEnv ?? 'test',
      hasSecret: Boolean(row?.esewaSecretEnc),
    },
    khalti: {
      enabled: row?.khaltiEnabled ?? false,
      env: row?.khaltiEnv ?? 'test',
      hasSecret: Boolean(row?.khaltiSecretEnc),
    },
    bank: row?.bankDetailsJson ?? null,
    qrFileId: row?.qrFileId ?? null,
  }
}

export async function updatePaymentConfig(context: AppContext, input: PaymentConfigInput): Promise<void> {
  assertAllowed(context, { capability: 'payments:configure', side: 'supplier' })
  const orgId = context.org.id
  const [current] = await db.select().from(supplierPaymentConfigs).where(eq(supplierPaymentConfigs.orgId, orgId)).limit(1)

  const esewaSecretEnc = input.esewaSecret ? encryptSecret(input.esewaSecret) : (current?.esewaSecretEnc ?? null)
  if (input.esewaEnabled && (!input.esewaMerchantId || !esewaSecretEnc)) {
    throw AppError.invalid('Enter your eSewa merchant code and secret key to turn on eSewa payments.')
  }

  let khaltiSecretEnc = current?.khaltiSecretEnc ?? null
  if (input.khaltiSecret) {
    const verdict = await checkKhaltiKey({ env: input.khaltiEnv, secret: input.khaltiSecret })
    if (verdict === 'invalid') {
      throw AppError.invalid(
        `Khalti did not accept this secret key for the ${input.khaltiEnv === 'live' ? 'live' : 'test'} environment. Check the key and the selected environment.`,
      )
    }
    khaltiSecretEnc = encryptSecret(input.khaltiSecret)
  }
  if (input.khaltiEnabled && !khaltiSecretEnc) {
    throw AppError.invalid('Enter your Khalti secret key to turn on Khalti payments.')
  }

  const hasBankField = Boolean(input.bankName || input.accountName || input.accountNumber || input.branch)
  if (hasBankField && (!input.bankName || !input.accountName || !input.accountNumber)) {
    throw AppError.invalid('Bank details need the bank name, account name and account number.')
  }
  const bankDetailsJson: BankDetails | null = hasBankField
    ? {
        bankName: input.bankName,
        accountName: input.accountName,
        accountNumber: input.accountNumber,
        branch: input.branch,
      }
    : null

  const values = {
    esewaEnabled: input.esewaEnabled,
    esewaMerchantId: input.esewaMerchantId || null,
    esewaSecretEnc,
    esewaEnv: input.esewaEnv,
    khaltiEnabled: input.khaltiEnabled,
    khaltiSecretEnc,
    khaltiEnv: input.khaltiEnv,
    bankDetailsJson,
  }
  await db
    .insert(supplierPaymentConfigs)
    .values({ orgId, ...values })
    .onConflictDoUpdate({ target: supplierPaymentConfigs.orgId, set: values })
}

export async function removeQrImage(context: AppContext): Promise<void> {
  assertAllowed(context, { capability: 'payments:configure', side: 'supplier' })
  await db.update(supplierPaymentConfigs).set({ qrFileId: null }).where(eq(supplierPaymentConfigs.orgId, context.org.id))
}

// ---------------------------------------------------------------------------
// Team
// ---------------------------------------------------------------------------

export type MemberDto = {
  membershipId: string
  userId: string
  name: string
  email: string
  role: MemberRole
  joinedAt: string
  isYou: boolean
}

export type InviteDto = {
  id: string
  code: string
  role: MemberRole
  expiresAt: string
  createdAt: string
}

export async function listMembers(context: AppContext): Promise<MemberDto[]> {
  const rows = await db
    .select({
      membershipId: memberships.id,
      userId: user.id,
      name: user.name,
      email: user.email,
      role: memberships.role,
      joinedAt: memberships.createdAt,
    })
    .from(memberships)
    .innerJoin(user, eq(user.id, memberships.userId))
    .where(eq(memberships.orgId, context.org.id))
    .orderBy(asc(memberships.createdAt))
  return rows.map((row) => ({ ...row, joinedAt: row.joinedAt.toISOString(), isYou: row.userId === context.user.id }))
}

export async function listOpenInvites(context: AppContext): Promise<InviteDto[]> {
  assertAllowed(context, { capability: 'team:manage' })
  const rows = await db
    .select()
    .from(invites)
    .where(
      and(
        eq(invites.orgId, context.org.id),
        isNull(invites.usedAt),
        isNull(invites.revokedAt),
        gt(invites.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(invites.createdAt))
  return rows.map((row) => ({
    id: row.id,
    code: row.code,
    role: row.role,
    expiresAt: row.expiresAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  }))
}

export async function createInvite(context: AppContext, role: MemberRole): Promise<InviteDto> {
  assertAllowed(context, { capability: 'team:manage' })
  if (role === 'owner') throw AppError.invalid('Invite people as manager or staff, then promote them to owner if needed.')
  const [row] = await db
    .insert(invites)
    .values({
      orgId: context.org.id,
      code: generateInviteCode(),
      role,
      createdBy: context.user.id,
      expiresAt: new Date(Date.now() + LIMITS.inviteTtlDays * 24 * 60 * 60 * 1000),
    })
    .returning()
  return {
    id: row.id,
    code: row.code,
    role: row.role,
    expiresAt: row.expiresAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  }
}

export async function revokeInvite(context: AppContext, inviteId: string): Promise<void> {
  assertAllowed(context, { capability: 'team:manage' })
  await db
    .update(invites)
    .set({ revokedAt: new Date() })
    .where(and(eq(invites.id, inviteId), eq(invites.orgId, context.org.id), isNull(invites.usedAt)))
}

async function ownerCount(executor: Executor, orgId: string): Promise<number> {
  const [{ value }] = await executor
    .select({ value: count() })
    .from(memberships)
    .where(and(eq(memberships.orgId, orgId), eq(memberships.role, 'owner')))
  return value
}

export async function changeMemberRole(context: AppContext, membershipId: string, role: MemberRole): Promise<void> {
  assertAllowed(context, { capability: 'team:manage' })
  await db.transaction(async (tx) => {
    const [member] = await tx
      .select()
      .from(memberships)
      .where(and(eq(memberships.id, membershipId), eq(memberships.orgId, context.org.id)))
      .for('update')
    if (!member) throw AppError.notFound('That person is no longer in your organization.')
    if (member.role === role) return
    if (member.role === 'owner' && (await ownerCount(tx, context.org.id)) <= 1) {
      throw AppError.invalid('An organization needs at least one owner. Make someone else an owner first.')
    }
    await tx.update(memberships).set({ role }).where(eq(memberships.id, member.id))
  })
}

export async function removeMember(context: AppContext, membershipId: string): Promise<void> {
  assertAllowed(context, { capability: 'team:manage' })
  await db.transaction(async (tx) => {
    const [member] = await tx
      .select()
      .from(memberships)
      .where(and(eq(memberships.id, membershipId), eq(memberships.orgId, context.org.id)))
      .for('update')
    if (!member) return
    if (member.role === 'owner' && (await ownerCount(tx, context.org.id)) <= 1) {
      throw AppError.invalid('An organization needs at least one owner. Make someone else an owner first.')
    }
    await tx.delete(memberships).where(eq(memberships.id, member.id))
  })
}
