import 'server-only'
import { and, asc, eq, ilike, inArray, ne, or, sql } from 'drizzle-orm'
import type { DeliveryMode } from '@/lib/constants'
import { db } from '@/lib/db'
import {
  cartItems,
  organizations,
  products,
  retailerInventory,
  supplierPaymentConfigs,
  supplierSettings,
  type Product,
} from '@/lib/db/schema'
import { AppError, isUniqueViolation } from '@/lib/errors'
import { sortTiers, type BulkTier } from '@/lib/money'
import { assertAllowed, type AppContext } from '@/lib/context'
import type { ProductInput } from '@/lib/validation'

export type ProductDto = {
  id: string
  sku: string
  name: string
  unit: string
  category: string | null
  pricePaisa: number
  moq: number
  schemeNote: string | null
  bulkTiers: BulkTier[]
  isActive: boolean
  updatedAt: string
}

function toProductDto(product: Product): ProductDto {
  return {
    id: product.id,
    sku: product.sku,
    name: product.name,
    unit: product.unit,
    category: product.category,
    pricePaisa: product.pricePaisa,
    moq: product.moq,
    schemeNote: product.schemeNote,
    bulkTiers: sortTiers(product.bulkTiersJson ?? []),
    isActive: product.isActive,
    updatedAt: product.updatedAt.toISOString(),
  }
}

const escapeLike = (value: string) => value.replace(/[\\%_]/g, '\\$&')

// ---------------------------------------------------------------------------
// Supplier: manage own catalog
// ---------------------------------------------------------------------------

export async function listOwnProducts(context: AppContext): Promise<ProductDto[]> {
  assertAllowed(context, { side: 'supplier' })
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.supplierOrgId, context.org.id))
    .orderBy(asc(products.name))
  return rows.map(toProductDto)
}

function productValues(input: ProductInput) {
  return {
    sku: input.sku.toUpperCase(),
    name: input.name,
    unit: input.unit,
    category: input.category || null,
    pricePaisa: input.pricePaisa,
    moq: input.moq,
    schemeNote: input.schemeNote || null,
    bulkTiersJson: sortTiers(input.bulkTiers),
    isActive: input.isActive,
  }
}

export async function createProduct(context: AppContext, input: ProductInput): Promise<string> {
  assertAllowed(context, { capability: 'catalog:manage', side: 'supplier' })
  try {
    const [row] = await db
      .insert(products)
      .values({ supplierOrgId: context.org.id, ...productValues(input) })
      .returning({ id: products.id })
    return row.id
  } catch (error) {
    if (isUniqueViolation(error)) throw AppError.conflict('You already have a product with this SKU.')
    throw error
  }
}

export async function updateProduct(context: AppContext, productId: string, input: ProductInput): Promise<void> {
  assertAllowed(context, { capability: 'catalog:manage', side: 'supplier' })
  try {
    const updated = await db
      .update(products)
      .set(productValues(input))
      .where(and(eq(products.id, productId), eq(products.supplierOrgId, context.org.id)))
      .returning({ id: products.id })
    if (updated.length === 0) throw AppError.notFound('Product not found.')
  } catch (error) {
    if (isUniqueViolation(error)) throw AppError.conflict('You already have a product with this SKU.')
    throw error
  }
}

export async function setProductActive(context: AppContext, productId: string, isActive: boolean): Promise<void> {
  assertAllowed(context, { capability: 'catalog:manage', side: 'supplier' })
  const updated = await db
    .update(products)
    .set({ isActive })
    .where(and(eq(products.id, productId), eq(products.supplierOrgId, context.org.id)))
    .returning({ id: products.id })
  if (updated.length === 0) throw AppError.notFound('Product not found.')
}

// ---------------------------------------------------------------------------
// Retailer: browse suppliers and their catalogs
// ---------------------------------------------------------------------------

export type SupplierSummary = {
  id: string
  name: string
  city: string
  address: string
  phone: string
  panVatNo: string
  productCount: number
  deliveryModes: DeliveryMode[]
  deliveryNote: string
  creditEnabled: boolean
  creditDays: number
  minOrderPaisa: number
  payments: { esewa: boolean; khalti: boolean; qrBank: boolean }
}

const supplierColumns = {
  id: organizations.id,
  name: organizations.name,
  city: organizations.city,
  address: organizations.address,
  phone: organizations.phone,
  panVatNo: organizations.panVatNo,
  deliveryModes: supplierSettings.deliveryModes,
  deliveryNote: supplierSettings.deliveryNote,
  creditEnabled: supplierSettings.creditEnabled,
  creditDays: supplierSettings.creditDays,
  minOrderPaisa: supplierSettings.minOrderPaisa,
  esewaEnabled: supplierPaymentConfigs.esewaEnabled,
  khaltiEnabled: supplierPaymentConfigs.khaltiEnabled,
  qrFileId: supplierPaymentConfigs.qrFileId,
  bankDetailsJson: supplierPaymentConfigs.bankDetailsJson,
}

type SupplierRow = {
  id: string
  name: string
  city: string
  address: string
  phone: string
  panVatNo: string
  deliveryModes: DeliveryMode[] | null
  deliveryNote: string | null
  creditEnabled: boolean | null
  creditDays: number | null
  minOrderPaisa: number | null
  esewaEnabled: boolean | null
  khaltiEnabled: boolean | null
  qrFileId: string | null
  bankDetailsJson: unknown
}

function toSupplierSummary(row: SupplierRow, productCount: number): SupplierSummary {
  return {
    id: row.id,
    name: row.name,
    city: row.city,
    address: row.address,
    phone: row.phone,
    panVatNo: row.panVatNo,
    productCount,
    deliveryModes: row.deliveryModes ?? [],
    deliveryNote: row.deliveryNote ?? '',
    creditEnabled: row.creditEnabled ?? false,
    creditDays: row.creditDays ?? 0,
    minOrderPaisa: row.minOrderPaisa ?? 0,
    payments: {
      esewa: row.esewaEnabled ?? false,
      khalti: row.khaltiEnabled ?? false,
      qrBank: Boolean(row.qrFileId || row.bankDetailsJson),
    },
  }
}

/** Organizations another business can buy from: suppliers and dual-role organizations, never itself. */
const isSupplierFor = (viewerOrgId: string) =>
  and(inArray(organizations.role, ['supplier', 'both']), ne(organizations.id, viewerOrgId))

export async function listSuppliers(context: AppContext, query = ''): Promise<SupplierSummary[]> {
  assertAllowed(context, { side: 'retailer' })
  const term = query.trim()
  const rows = await db
    .select(supplierColumns)
    .from(organizations)
    .leftJoin(supplierSettings, eq(supplierSettings.orgId, organizations.id))
    .leftJoin(supplierPaymentConfigs, eq(supplierPaymentConfigs.orgId, organizations.id))
    .where(
      and(
        isSupplierFor(context.org.id),
        term
          ? or(ilike(organizations.name, `%${escapeLike(term)}%`), ilike(organizations.city, `%${escapeLike(term)}%`))
          : undefined,
      ),
    )
    .orderBy(asc(organizations.name))
    .limit(200)
  if (rows.length === 0) return []

  const counts = await db
    .select({ supplierOrgId: products.supplierOrgId, value: sql<number>`count(*)`.mapWith(Number) })
    .from(products)
    .where(
      and(
        inArray(
          products.supplierOrgId,
          rows.map((row) => row.id),
        ),
        eq(products.isActive, true),
      ),
    )
    .groupBy(products.supplierOrgId)
  const countBySupplier = new Map(counts.map((row) => [row.supplierOrgId, row.value]))
  return rows.map((row) => toSupplierSummary(row, countBySupplier.get(row.id) ?? 0))
}

export type CatalogProductDto = ProductDto & {
  supplierId: string
  supplierName: string
  cartQty: number
  inventoryId: string | null
}

async function decorateForRetailer(
  context: AppContext,
  rows: Array<{ product: Product; supplierName: string }>,
): Promise<CatalogProductDto[]> {
  if (rows.length === 0) return []
  const ids = rows.map((row) => row.product.id)
  const [cartRows, inventoryRows] = await Promise.all([
    db
      .select({ productId: cartItems.productId, qty: cartItems.qty })
      .from(cartItems)
      .where(and(eq(cartItems.retailerOrgId, context.org.id), inArray(cartItems.productId, ids))),
    db
      .select({ productId: retailerInventory.productId, id: retailerInventory.id, archivedAt: retailerInventory.archivedAt })
      .from(retailerInventory)
      .where(and(eq(retailerInventory.retailerOrgId, context.org.id), inArray(retailerInventory.productId, ids))),
  ])
  const cartByProduct = new Map(cartRows.map((row) => [row.productId, row.qty]))
  const inventoryByProduct = new Map(
    inventoryRows.filter((row) => !row.archivedAt).map((row) => [row.productId as string, row.id]),
  )
  return rows.map(({ product, supplierName }) => ({
    ...toProductDto(product),
    supplierId: product.supplierOrgId,
    supplierName,
    cartQty: cartByProduct.get(product.id) ?? 0,
    inventoryId: inventoryByProduct.get(product.id) ?? null,
  }))
}

export async function getSupplierProfile(
  context: AppContext,
  supplierId: string,
): Promise<{ supplier: SupplierSummary; products: CatalogProductDto[] } | null> {
  assertAllowed(context, { side: 'retailer' })
  const [row] = await db
    .select(supplierColumns)
    .from(organizations)
    .leftJoin(supplierSettings, eq(supplierSettings.orgId, organizations.id))
    .leftJoin(supplierPaymentConfigs, eq(supplierPaymentConfigs.orgId, organizations.id))
    .where(and(eq(organizations.id, supplierId), isSupplierFor(context.org.id)))
    .limit(1)
  if (!row) return null

  const productRows = await db
    .select()
    .from(products)
    .where(and(eq(products.supplierOrgId, supplierId), eq(products.isActive, true)))
    .orderBy(asc(products.category), asc(products.name))
  const decorated = await decorateForRetailer(
    context,
    productRows.map((product) => ({ product, supplierName: row.name })),
  )
  return { supplier: toSupplierSummary(row, productRows.length), products: decorated }
}

/** Active products across every supplier, for adding items to inventory, schedules and quotes. */
export async function searchCatalog(
  context: AppContext,
  options: { query?: string; supplierId?: string; limit?: number } = {},
): Promise<CatalogProductDto[]> {
  assertAllowed(context, { side: 'retailer' })
  const term = options.query?.trim() ?? ''
  const rows = await db
    .select({ product: products, supplierName: organizations.name })
    .from(products)
    .innerJoin(organizations, eq(organizations.id, products.supplierOrgId))
    .where(
      and(
        eq(products.isActive, true),
        isSupplierFor(context.org.id),
        options.supplierId ? eq(products.supplierOrgId, options.supplierId) : undefined,
        term
          ? or(ilike(products.name, `%${escapeLike(term)}%`), ilike(products.sku, `%${escapeLike(term)}%`))
          : undefined,
      ),
    )
    .orderBy(asc(products.name))
    .limit(Math.min(options.limit ?? 30, 200))
  return decorateForRetailer(context, rows)
}
