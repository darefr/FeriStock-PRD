import 'server-only'
import { asc, eq, gt, and } from 'drizzle-orm'
import type { ReceiptKind } from '@/lib/constants'
import { db, type Tx } from '@/lib/db'
import {
  orderItems,
  orders,
  organizations,
  receipts,
  type Organization,
  type ReceiptParty,
  type ReceiptSnapshot,
} from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import type { AppContext } from '@/lib/context'
import { sideOf } from './order-core'
import { balanceOf } from './order-rules'

const partyOf = (org: Organization): ReceiptParty => ({
  name: org.name,
  panVatNo: org.panVatNo,
  address: org.address,
  city: org.city,
  phone: org.phone,
})

/**
 * Issues an Order & Payment Receipt. Everything printed on it is copied into the receipt row,
 * so later edits to a business profile or catalog can never change a document already issued.
 * Call this after the order's payment totals have been recomputed.
 */
export async function issueReceipt(
  tx: Tx,
  params: {
    receiptId?: string
    orderId: string
    kind: ReceiptKind
    payment?: {
      id: string
      method: string
      transactionRef: string | null
      gatewayTxnId: string | null
      gatewayEnv: string | null
      amountPaisa: number
      paidAt: Date
    }
  },
): Promise<{ id: string; receiptNo: string }> {
  const [order] = await tx.select().from(orders).where(eq(orders.id, params.orderId))
  if (!order) throw AppError.notFound('Order not found.')
  const [supplier] = await tx.select().from(organizations).where(eq(organizations.id, order.supplierOrgId))
  const [buyer] = await tx.select().from(organizations).where(eq(organizations.id, order.retailerOrgId))
  const items = await tx
    .select()
    .from(orderItems)
    .where(and(eq(orderItems.orderId, order.id), gt(orderItems.qty, 0)))
    .orderBy(asc(orderItems.position))

  const snapshot: ReceiptSnapshot = {
    version: 1,
    kind: params.kind,
    order: {
      orderNo: order.orderNo,
      orderType: order.orderType,
      placedAt: order.placedAt?.toISOString() ?? null,
      acceptedAt: order.acceptedAt?.toISOString() ?? null,
      dueDate: order.dueDate,
      creditApproved: order.creditState === 'approved',
    },
    supplier: partyOf(supplier),
    buyer: partyOf(buyer),
    items: items.map((item) => ({
      sku: item.sku,
      name: item.name,
      unit: item.unit,
      qty: item.qty,
      unitPricePaisa: item.unitPricePaisa,
      lineTotalPaisa: item.lineTotalPaisa,
    })),
    totals: {
      totalPaisa: order.totalPaisa,
      paidToDatePaisa: order.paidPaisa,
      balancePaisa: balanceOf(order),
    },
    payment: params.payment
      ? {
          method: params.payment.method,
          transactionRef: params.payment.transactionRef,
          gatewayTxnId: params.payment.gatewayTxnId,
          gatewayEnv: params.payment.gatewayEnv,
          amountPaisa: params.payment.amountPaisa,
          paidAt: params.payment.paidAt.toISOString(),
        }
      : null,
  }

  const [row] = await tx
    .insert(receipts)
    .values({
      id: params.receiptId,
      orderId: order.id,
      paymentRecordId: params.payment?.id ?? null,
      kind: params.kind,
      snapshot,
    })
    .returning({ id: receipts.id, receiptNo: receipts.receiptNo })
  return row
}

export type ReceiptDto = {
  id: string
  receiptNo: string
  kind: ReceiptKind
  issuedAt: string
  orderId: string
  snapshot: ReceiptSnapshot
}

/** A receipt is visible only to the two organizations named on it. */
export async function getReceiptForViewer(context: AppContext, receiptId: string): Promise<ReceiptDto | null> {
  const [row] = await db
    .select({ receipt: receipts, retailerOrgId: orders.retailerOrgId, supplierOrgId: orders.supplierOrgId })
    .from(receipts)
    .innerJoin(orders, eq(orders.id, receipts.orderId))
    .where(eq(receipts.id, receiptId))
    .limit(1)
  if (!row || sideOf(row, context.org.id) === null) return null
  return {
    id: row.receipt.id,
    receiptNo: row.receipt.receiptNo,
    kind: row.receipt.kind,
    issuedAt: row.receipt.issuedAt.toISOString(),
    orderId: row.receipt.orderId,
    snapshot: row.receipt.snapshot,
  }
}
