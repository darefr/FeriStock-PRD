import 'server-only'
import { and, asc, count, desc, eq, gt, gte, inArray, isNull, ne, sql } from 'drizzle-orm'
import type { CreditState, OrderStatus, PaymentStatus } from '@/lib/constants'
import { addDays, daysBetween, nptToInstant, todayNpt } from '@/lib/dates'
import { db } from '@/lib/db'
import {
  cartItems,
  orderItems,
  orders,
  organizations,
  paymentRecords,
  products,
  quoteRequests,
  recurringSchedules,
  retailerInventory,
} from '@/lib/db/schema'
import type { AppContext } from '@/lib/context'
import { listInventory, type InventoryItemDto } from './inventory'
import { orderVisibleTo } from './order-core'
import { balanceOf, isOverdue, type OrderSide } from './order-rules'
import { listOrders, type OrderListItem } from './orders'
import { stockStatus } from './stock-rules'

const COMMITTED: OrderStatus[] = ['accepted', 'packed', 'dispatched', 'delivered']

// ---------------------------------------------------------------------------
// Navigation badges — the counts that tell each role what is waiting on them
// ---------------------------------------------------------------------------

export type NavBadges = {
  cart: number
  stockAlerts: number
  purchases: number
  sales: number
  quotes: number
}

export async function getNavBadges(context: AppContext): Promise<NavBadges> {
  const orgId = context.org.id
  const badges: NavBadges = { cart: 0, stockAlerts: 0, purchases: 0, sales: 0, quotes: 0 }

  if (context.isRetailer) {
    const [[cart], stockRows, [purchases], [quoted]] = await Promise.all([
      db.select({ value: count() }).from(cartItems).where(eq(cartItems.retailerOrgId, orgId)),
      db
        .select({ qty: retailerInventory.currentQty, threshold: retailerInventory.reorderThreshold })
        .from(retailerInventory)
        .where(
          and(
            eq(retailerInventory.retailerOrgId, orgId),
            isNull(retailerInventory.archivedAt),
            eq(retailerInventory.alertsEnabled, true),
          ),
        ),
      // Drafts to review and deliveries to confirm.
      db
        .select({ value: count() })
        .from(orders)
        .where(
          and(
            eq(orders.retailerOrgId, orgId),
            sql`(${orders.status} in ('draft', 'dispatched') or (${orders.status} = 'delivered' and ${orders.stockSyncedAt} is null))`,
          ),
        ),
      db
        .select({ value: count() })
        .from(quoteRequests)
        .where(and(eq(quoteRequests.retailerOrgId, orgId), eq(quoteRequests.status, 'quoted'))),
    ])
    badges.cart = cart.value
    badges.stockAlerts = stockRows.filter((row) => stockStatus(row.qty, row.threshold) !== 'ok').length
    badges.purchases = purchases.value
    badges.quotes += quoted.value
  }

  if (context.isSupplier) {
    const [[pending], [proofs], [requested]] = await Promise.all([
      db
        .select({ value: count() })
        .from(orders)
        .where(and(eq(orders.supplierOrgId, orgId), eq(orders.status, 'pending'))),
      db
        .select({ value: count() })
        .from(paymentRecords)
        .innerJoin(orders, eq(orders.id, paymentRecords.orderId))
        .where(and(eq(orders.supplierOrgId, orgId), eq(paymentRecords.status, 'pending_verification'))),
      db
        .select({ value: count() })
        .from(quoteRequests)
        .where(and(eq(quoteRequests.supplierOrgId, orgId), eq(quoteRequests.status, 'requested'))),
    ])
    badges.sales = pending.value + proofs.value
    badges.quotes += requested.value
  }

  return badges
}

// ---------------------------------------------------------------------------
// Udharo & dues ledger
// ---------------------------------------------------------------------------

export type LedgerRow = {
  orderId: string
  orderNo: string
  counterparty: { id: string; name: string }
  status: OrderStatus
  paymentStatus: PaymentStatus
  creditState: CreditState
  totalPaisa: number
  paidPaisa: number
  balancePaisa: number
  dueDate: string | null
  overdue: boolean
  /** Negative when overdue, positive when still to come; null without a due date. */
  daysUntilDue: number | null
}

export type Ledger = {
  rows: LedgerRow[]
  parties: Array<{ id: string; name: string; balancePaisa: number; overduePaisa: number; orders: number }>
  totals: { balancePaisa: number; onCreditPaisa: number; overduePaisa: number; overdueCount: number }
}

/** Every accepted order that still has money owed, from the buyer's or the seller's point of view. */
export async function getLedger(context: AppContext, side: OrderSide): Promise<Ledger> {
  const counterpartyId = side === 'retailer' ? orders.supplierOrgId : orders.retailerOrgId
  const rows = await db
    .select({ order: orders, counterpartyName: organizations.name })
    .from(orders)
    .innerJoin(organizations, eq(organizations.id, counterpartyId))
    .where(
      and(
        orderVisibleTo(context.org.id, side),
        inArray(orders.status, COMMITTED),
        gt(sql`${orders.totalPaisa} - ${orders.paidPaisa}`, 0),
      ),
    )
    .orderBy(sql`${orders.dueDate} asc nulls last`, asc(orders.acceptedAt))
    .limit(500)

  const today = todayNpt()
  const ledgerRows: LedgerRow[] = rows.map(({ order, counterpartyName }) => ({
    orderId: order.id,
    orderNo: order.orderNo,
    counterparty: { id: side === 'retailer' ? order.supplierOrgId : order.retailerOrgId, name: counterpartyName },
    status: order.status,
    paymentStatus: order.paymentStatus,
    creditState: order.creditState,
    totalPaisa: order.totalPaisa,
    paidPaisa: order.paidPaisa,
    balancePaisa: balanceOf(order),
    dueDate: order.creditState === 'approved' ? order.dueDate : null,
    overdue: isOverdue(order, today),
    daysUntilDue: order.creditState === 'approved' && order.dueDate ? daysBetween(today, order.dueDate) : null,
  }))

  const parties = new Map<string, Ledger['parties'][number]>()
  for (const row of ledgerRows) {
    const party = parties.get(row.counterparty.id) ?? {
      id: row.counterparty.id,
      name: row.counterparty.name,
      balancePaisa: 0,
      overduePaisa: 0,
      orders: 0,
    }
    party.balancePaisa += row.balancePaisa
    party.overduePaisa += row.overdue ? row.balancePaisa : 0
    party.orders += 1
    parties.set(party.id, party)
  }

  return {
    rows: ledgerRows,
    parties: [...parties.values()].sort((a, b) => b.balancePaisa - a.balancePaisa),
    totals: {
      balancePaisa: ledgerRows.reduce((sum, row) => sum + row.balancePaisa, 0),
      onCreditPaisa: ledgerRows.reduce((sum, row) => sum + (row.creditState === 'approved' ? row.balancePaisa : 0), 0),
      overduePaisa: ledgerRows.reduce((sum, row) => sum + (row.overdue ? row.balancePaisa : 0), 0),
      overdueCount: ledgerRows.filter((row) => row.overdue).length,
    },
  }
}

// ---------------------------------------------------------------------------
// Retailer overview
// ---------------------------------------------------------------------------

export type RetailerOverview = {
  stock: { tracked: number; low: number; out: number }
  needsRestock: InventoryItemDto[]
  orders: { drafts: number; awaitingSupplier: number; beingPrepared: number; inTransit: number }
  incoming: OrderListItem[]
  dues: Ledger['totals']
  nextSchedule: { name: string; supplierName: string; nextRunAt: string } | null
}

export async function getRetailerOverview(context: AppContext): Promise<RetailerOverview> {
  const orgId = context.org.id
  const [inventory, statusRows, incoming, ledger, [schedule]] = await Promise.all([
    listInventory(context),
    db
      .select({ status: orders.status, value: sql<number>`count(*)`.mapWith(Number) })
      .from(orders)
      .where(eq(orders.retailerOrgId, orgId))
      .groupBy(orders.status),
    listOrders(context, 'retailer', { statuses: ['dispatched'], limit: 5 }),
    getLedger(context, 'retailer'),
    db
      .select({
        name: recurringSchedules.name,
        supplierName: organizations.name,
        nextRunAt: recurringSchedules.nextRunAt,
      })
      .from(recurringSchedules)
      .innerJoin(organizations, eq(organizations.id, recurringSchedules.supplierOrgId))
      .where(and(eq(recurringSchedules.retailerOrgId, orgId), eq(recurringSchedules.isActive, true)))
      .orderBy(asc(recurringSchedules.nextRunAt))
      .limit(1),
  ])

  const byStatus = new Map(statusRows.map((row) => [row.status, row.value]))
  const severity = { out: 0, low: 1, ok: 2 } as const
  const attention = inventory
    .filter((item) => item.status !== 'ok' && item.alertsEnabled)
    .sort((a, b) => severity[a.status] - severity[b.status] || a.currentQty - b.currentQty)

  return {
    stock: {
      tracked: inventory.length,
      low: inventory.filter((item) => item.status === 'low').length,
      out: inventory.filter((item) => item.status === 'out').length,
    },
    needsRestock: attention.slice(0, 6),
    orders: {
      drafts: byStatus.get('draft') ?? 0,
      awaitingSupplier: byStatus.get('pending') ?? 0,
      beingPrepared: (byStatus.get('accepted') ?? 0) + (byStatus.get('packed') ?? 0),
      inTransit: byStatus.get('dispatched') ?? 0,
    },
    incoming,
    dues: ledger.totals,
    nextSchedule: schedule
      ? { name: schedule.name, supplierName: schedule.supplierName, nextRunAt: schedule.nextRunAt.toISOString() }
      : null,
  }
}

// ---------------------------------------------------------------------------
// Supplier overview
// ---------------------------------------------------------------------------

export type SupplierOverview = {
  pipeline: { pending: number; accepted: number; packed: number; dispatched: number }
  proofsToConfirm: number
  creditRequests: number
  quotesToAnswer: number
  receivables: Ledger['totals']
  catalog: { active: number; inactive: number }
  /** Accepted order value per day for the last 14 days, in Nepal time. */
  sales: Array<{ date: string; totalPaisa: number; orders: number }>
  topProducts: Array<{ name: string; unit: string; qty: number; totalPaisa: number }>
  newOrders: OrderListItem[]
}

const SALES_DAYS = 14

export async function getSupplierOverview(context: AppContext): Promise<SupplierOverview> {
  const orgId = context.org.id
  const today = todayNpt()
  const firstDay = addDays(today, -(SALES_DAYS - 1))
  const [year, month, day] = firstDay.split('-').map(Number)
  const salesSince = nptToInstant(year, month, day)
  const [topYear, topMonth, topDay] = addDays(today, -29).split('-').map(Number)
  const topSince = nptToInstant(topYear, topMonth, topDay)

  // Bucket by Nepal calendar day without depending on the server's time zone setting.
  const nepalDay = sql<string>`to_char((${orders.acceptedAt} at time zone 'UTC') + interval '5 hours 45 minutes', 'YYYY-MM-DD')`
  const notCancelled = ne(orders.status, 'cancelled')

  const [statusRows, [proofs], [credit], [quotes], ledger, catalogRows, salesRows, topRows, newOrders] = await Promise.all([
    db
      .select({ status: orders.status, value: sql<number>`count(*)`.mapWith(Number) })
      .from(orders)
      .where(eq(orders.supplierOrgId, orgId))
      .groupBy(orders.status),
    db
      .select({ value: count() })
      .from(paymentRecords)
      .innerJoin(orders, eq(orders.id, paymentRecords.orderId))
      .where(and(eq(orders.supplierOrgId, orgId), eq(paymentRecords.status, 'pending_verification'))),
    db
      .select({ value: count() })
      .from(orders)
      .where(
        and(eq(orders.supplierOrgId, orgId), eq(orders.creditState, 'requested'), inArray(orders.status, COMMITTED)),
      ),
    db
      .select({ value: count() })
      .from(quoteRequests)
      .where(and(eq(quoteRequests.supplierOrgId, orgId), eq(quoteRequests.status, 'requested'))),
    getLedger(context, 'supplier'),
    db
      .select({ isActive: products.isActive, value: sql<number>`count(*)`.mapWith(Number) })
      .from(products)
      .where(eq(products.supplierOrgId, orgId))
      .groupBy(products.isActive),
    db
      .select({
        date: nepalDay,
        totalPaisa: sql<number>`coalesce(sum(${orders.totalPaisa}), 0)`.mapWith(Number),
        orders: sql<number>`count(*)`.mapWith(Number),
      })
      .from(orders)
      .where(and(eq(orders.supplierOrgId, orgId), gte(orders.acceptedAt, salesSince), notCancelled))
      .groupBy(nepalDay),
    db
      .select({
        name: orderItems.name,
        unit: orderItems.unit,
        qty: sql<number>`sum(${orderItems.qty})`.mapWith(Number),
        totalPaisa: sql<number>`sum(${orderItems.lineTotalPaisa})`.mapWith(Number),
      })
      .from(orderItems)
      .innerJoin(orders, eq(orders.id, orderItems.orderId))
      .where(and(eq(orders.supplierOrgId, orgId), gte(orders.acceptedAt, topSince), notCancelled, gt(orderItems.qty, 0)))
      .groupBy(orderItems.name, orderItems.unit)
      .orderBy(desc(sql`sum(${orderItems.lineTotalPaisa})`))
      .limit(5),
    listOrders(context, 'supplier', { statuses: ['pending'], limit: 5 }),
  ])

  const byStatus = new Map(statusRows.map((row) => [row.status, row.value]))
  const salesByDate = new Map(salesRows.map((row) => [row.date, row]))

  return {
    pipeline: {
      pending: byStatus.get('pending') ?? 0,
      accepted: byStatus.get('accepted') ?? 0,
      packed: byStatus.get('packed') ?? 0,
      dispatched: byStatus.get('dispatched') ?? 0,
    },
    proofsToConfirm: proofs.value,
    creditRequests: credit.value,
    quotesToAnswer: quotes.value,
    receivables: ledger.totals,
    catalog: {
      active: catalogRows.find((row) => row.isActive)?.value ?? 0,
      inactive: catalogRows.find((row) => !row.isActive)?.value ?? 0,
    },
    sales: Array.from({ length: SALES_DAYS }, (_, index) => {
      const date = addDays(firstDay, index)
      const row = salesByDate.get(date)
      return { date, totalPaisa: row?.totalPaisa ?? 0, orders: row?.orders ?? 0 }
    }),
    topProducts: topRows,
    newOrders,
  }
}
