import 'server-only'
import { and, asc, desc, eq, inArray, isNull, sql } from 'drizzle-orm'
import { alias } from 'drizzle-orm/pg-core'
import {
  DELIVERY_MODE_LABEL,
  type CreditState,
  type DeliveryMode,
  type GatewayEnv,
  type OrderStatus,
  type OrderType,
  type PaymentMethod,
  type PaymentRecordStatus,
  type PaymentStatus,
  type ReceiptKind,
} from '@/lib/constants'
import { todayNpt } from '@/lib/dates'
import { db, type Tx } from '@/lib/db'
import {
  cartItems,
  files,
  orderEvents,
  orderItems,
  orders,
  organizations,
  paymentRecords,
  products,
  receipts,
  retailerInventory,
  shipments,
  supplierPaymentConfigs,
  supplierSettings,
  type BankDetails,
  type Order,
  type ReceiptParty,
} from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { formatNpr, sortTiers, unitPriceForQty } from '@/lib/money'
import { assertAllowed, type AppContext } from '@/lib/context'
import type { AcceptOrderInput, DispatchInput } from '@/lib/validation'
import { applyStockChange } from './inventory'
import {
  actorOf,
  insertOrder,
  lockOrderAs,
  logOrderEvent,
  orderVisibleTo,
  recomputeOrderPayment,
  sideOf,
  type OrderLineInput,
} from './order-core'
import { balanceOf, isOverdue, orderActions, type OrderAction, type OrderSide } from './order-rules'
import { issueReceipt } from './receipts'

// ---------------------------------------------------------------------------
// Reading
// ---------------------------------------------------------------------------

export type OrderListItem = {
  id: string
  orderNo: string
  orderType: OrderType
  status: OrderStatus
  totalPaisa: number
  paidPaisa: number
  paymentStatus: PaymentStatus
  creditState: CreditState
  dueDate: string | null
  overdue: boolean
  counterparty: { id: string; name: string; city: string }
  itemCount: number
  placedAt: string | null
  createdAt: string
}

export async function listOrders(
  context: AppContext,
  side: OrderSide,
  options: { statuses?: OrderStatus[]; limit?: number } = {},
): Promise<OrderListItem[]> {
  assertAllowed(context, { side })
  const counterpartyId = side === 'retailer' ? orders.supplierOrgId : orders.retailerOrgId
  const rows = await db
    .select({
      order: orders,
      counterpartyName: organizations.name,
      counterpartyCity: organizations.city,
      itemCount: sql<number>`(select count(*) from ${orderItems} where ${orderItems.orderId} = ${orders.id} and ${orderItems.qty} > 0)`.mapWith(
        Number,
      ),
    })
    .from(orders)
    .innerJoin(organizations, eq(organizations.id, counterpartyId))
    .where(
      and(
        orderVisibleTo(context.org.id, side),
        options.statuses?.length ? inArray(orders.status, options.statuses) : undefined,
        // A draft belongs to the buyer alone until it is submitted.
        side === 'supplier' ? sql`${orders.status} <> 'draft'` : undefined,
      ),
    )
    .orderBy(desc(orders.createdAt))
    .limit(Math.min(options.limit ?? 200, 500))

  const today = todayNpt()
  return rows.map(({ order, counterpartyName, counterpartyCity, itemCount }) => ({
    id: order.id,
    orderNo: order.orderNo,
    orderType: order.orderType,
    status: order.status,
    totalPaisa: order.totalPaisa,
    paidPaisa: order.paidPaisa,
    paymentStatus: order.paymentStatus,
    creditState: order.creditState,
    dueDate: order.dueDate,
    overdue: isOverdue(order, today),
    counterparty: {
      id: side === 'retailer' ? order.supplierOrgId : order.retailerOrgId,
      name: counterpartyName,
      city: counterpartyCity,
    },
    itemCount,
    placedAt: order.placedAt?.toISOString() ?? null,
    createdAt: order.createdAt.toISOString(),
  }))
}

export async function countOrdersByStatus(context: AppContext, side: OrderSide): Promise<Record<OrderStatus, number>> {
  const rows = await db
    .select({ status: orders.status, value: sql<number>`count(*)`.mapWith(Number) })
    .from(orders)
    .where(orderVisibleTo(context.org.id, side))
    .groupBy(orders.status)
  const result: Record<OrderStatus, number> = {
    draft: 0,
    pending: 0,
    accepted: 0,
    packed: 0,
    dispatched: 0,
    delivered: 0,
    cancelled: 0,
    rejected: 0,
  }
  for (const row of rows) result[row.status] = row.value
  return result
}

export type OrderDetail = {
  id: string
  orderNo: string
  orderType: OrderType
  status: OrderStatus
  viewerSide: OrderSide
  totalPaisa: number
  paidPaisa: number
  balancePaisa: number
  paymentStatus: PaymentStatus
  creditState: CreditState
  dueDate: string | null
  overdue: boolean
  retailerNote: string | null
  supplierNote: string | null
  cancelReason: string | null
  quoteId: string | null
  scheduleId: string | null
  timestamps: {
    createdAt: string
    placedAt: string | null
    acceptedAt: string | null
    packedAt: string | null
    dispatchedAt: string | null
    deliveredAt: string | null
    stockSyncedAt: string | null
    closedAt: string | null
  }
  retailer: ReceiptParty & { id: string }
  supplier: ReceiptParty & { id: string }
  items: Array<{
    id: string
    sku: string | null
    name: string
    unit: string
    requestedQty: number
    qty: number
    unitPricePaisa: number
    lineTotalPaisa: number
    receivedQty: number | null
  }>
  shipment: null | {
    deliveryMode: DeliveryMode
    carrierOrVan: string | null
    driverName: string | null
    driverPhone: string | null
    biltiRef: string | null
    biltiPhotoFileId: string | null
    note: string | null
    dispatchedAt: string
    deliveredAt: string | null
  }
  payments: Array<{
    id: string
    method: PaymentMethod
    status: PaymentRecordStatus
    amountPaisa: number
    transactionRef: string | null
    gatewayEnv: GatewayEnv | null
    note: string | null
    rejectReason: string | null
    proofFileId: string | null
    createdAt: string
    paidAt: string | null
    receipt: { id: string; receiptNo: string } | null
  }>
  receipts: Array<{ id: string; receiptNo: string; kind: ReceiptKind; issuedAt: string }>
  events: Array<{ id: string; type: string; message: string; actorName: string | null; createdAt: string }>
  actions: OrderAction[]
  /** How the supplier can be paid and on what terms. Gateway secrets are never included. */
  supplierTerms: {
    esewa: boolean
    esewaEnv: GatewayEnv
    khalti: boolean
    khaltiEnv: GatewayEnv
    qrFileId: string | null
    bank: BankDetails | null
    creditEnabled: boolean
    creditDays: number
    deliveryModes: DeliveryMode[]
  }
}

const iso = (value: Date | null) => value?.toISOString() ?? null

export async function getOrderDetail(context: AppContext, orderId: string): Promise<OrderDetail | null> {
  const retailer = alias(organizations, 'retailer')
  const supplier = alias(organizations, 'supplier')
  const [row] = await db
    .select({ order: orders, retailer, supplier })
    .from(orders)
    .innerJoin(retailer, eq(retailer.id, orders.retailerOrgId))
    .innerJoin(supplier, eq(supplier.id, orders.supplierOrgId))
    .where(eq(orders.id, orderId))
    .limit(1)
  if (!row) return null

  const { order } = row
  const viewerSide = sideOf(order, context.org.id)
  if (!viewerSide) return null
  if (viewerSide === 'supplier' && order.status === 'draft') return null

  const [items, eventRows, shipmentRows, paymentRows, receiptRows, configRows, settingsRows] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, order.id)).orderBy(asc(orderItems.position)),
    db.select().from(orderEvents).where(eq(orderEvents.orderId, order.id)).orderBy(asc(orderEvents.createdAt)),
    db.select().from(shipments).where(eq(shipments.orderId, order.id)).limit(1),
    db.select().from(paymentRecords).where(eq(paymentRecords.orderId, order.id)).orderBy(desc(paymentRecords.createdAt)),
    db.select().from(receipts).where(eq(receipts.orderId, order.id)).orderBy(asc(receipts.issuedAt)),
    db.select().from(supplierPaymentConfigs).where(eq(supplierPaymentConfigs.orgId, order.supplierOrgId)).limit(1),
    db.select().from(supplierSettings).where(eq(supplierSettings.orgId, order.supplierOrgId)).limit(1),
  ])
  const [shipment] = shipmentRows
  const [config] = configRows
  const [settings] = settingsRows
  const receiptByPayment = new Map(
    receiptRows.filter((receipt) => receipt.paymentRecordId).map((receipt) => [receipt.paymentRecordId as string, receipt]),
  )

  return {
    id: order.id,
    orderNo: order.orderNo,
    orderType: order.orderType,
    status: order.status,
    viewerSide,
    totalPaisa: order.totalPaisa,
    paidPaisa: order.paidPaisa,
    balancePaisa: balanceOf(order),
    paymentStatus: order.paymentStatus,
    creditState: order.creditState,
    dueDate: order.dueDate,
    overdue: isOverdue(order, todayNpt()),
    retailerNote: order.retailerNote,
    supplierNote: order.supplierNote,
    cancelReason: order.cancelReason,
    quoteId: order.quoteId,
    scheduleId: order.scheduleId,
    timestamps: {
      createdAt: order.createdAt.toISOString(),
      placedAt: iso(order.placedAt),
      acceptedAt: iso(order.acceptedAt),
      packedAt: iso(order.packedAt),
      dispatchedAt: iso(order.dispatchedAt),
      deliveredAt: iso(order.deliveredAt),
      stockSyncedAt: iso(order.stockSyncedAt),
      closedAt: iso(order.closedAt),
    },
    retailer: {
      id: row.retailer.id,
      name: row.retailer.name,
      panVatNo: row.retailer.panVatNo,
      address: row.retailer.address,
      city: row.retailer.city,
      phone: row.retailer.phone,
    },
    supplier: {
      id: row.supplier.id,
      name: row.supplier.name,
      panVatNo: row.supplier.panVatNo,
      address: row.supplier.address,
      city: row.supplier.city,
      phone: row.supplier.phone,
    },
    items: items.map((item) => ({
      id: item.id,
      sku: item.sku,
      name: item.name,
      unit: item.unit,
      requestedQty: item.requestedQty,
      qty: item.qty,
      unitPricePaisa: item.unitPricePaisa,
      lineTotalPaisa: item.lineTotalPaisa,
      receivedQty: item.receivedQty,
    })),
    shipment: shipment
      ? {
          deliveryMode: shipment.deliveryMode,
          carrierOrVan: shipment.carrierOrVan,
          driverName: shipment.driverName,
          driverPhone: shipment.driverPhone,
          biltiRef: shipment.biltiRef,
          biltiPhotoFileId: shipment.biltiPhotoFileId,
          note: shipment.note,
          dispatchedAt: shipment.dispatchedAt.toISOString(),
          deliveredAt: iso(shipment.deliveredAt),
        }
      : null,
    payments: paymentRows.map((payment) => {
      const receipt = receiptByPayment.get(payment.id)
      return {
        id: payment.id,
        method: payment.method,
        status: payment.status,
        amountPaisa: payment.amountPaisa,
        transactionRef: payment.transactionRef,
        gatewayEnv: payment.gatewayEnv,
        note: payment.note,
        rejectReason: payment.rejectReason,
        proofFileId: payment.proofFileId,
        createdAt: payment.createdAt.toISOString(),
        paidAt: iso(payment.paidAt),
        receipt: receipt ? { id: receipt.id, receiptNo: receipt.receiptNo } : null,
      }
    }),
    receipts: receiptRows.map((receipt) => ({
      id: receipt.id,
      receiptNo: receipt.receiptNo,
      kind: receipt.kind,
      issuedAt: receipt.issuedAt.toISOString(),
    })),
    events: eventRows.map((event) => ({
      id: event.id,
      type: event.type,
      message: event.message,
      actorName: event.actorName,
      createdAt: event.createdAt.toISOString(),
    })),
    actions: [...orderActions(order, viewerSide)],
    supplierTerms: {
      esewa: Boolean(config?.esewaEnabled && config.esewaMerchantId && config.esewaSecretEnc),
      esewaEnv: config?.esewaEnv ?? 'test',
      khalti: Boolean(config?.khaltiEnabled && config.khaltiSecretEnc),
      khaltiEnv: config?.khaltiEnv ?? 'test',
      qrFileId: config?.qrFileId ?? null,
      bank: config?.bankDetailsJson ?? null,
      creditEnabled: settings?.creditEnabled ?? false,
      creditDays: settings?.creditDays ?? 15,
      deliveryModes: settings?.deliveryModes ?? ['own_van', 'bilti', 'pickup'],
    },
  }
}

// ---------------------------------------------------------------------------
// Retailer: placing orders
// ---------------------------------------------------------------------------

/** Turns the cart lines for one supplier into a purchase order, priced by the server at current catalog prices. */
export async function placeOrderFromCart(
  context: AppContext,
  input: { supplierOrgId: string; note: string; requestCredit: boolean },
): Promise<{ orderId: string; orderNo: string }> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  const orgId = context.org.id

  return db.transaction(async (tx) => {
    const rows = await tx
      .select({ cart: cartItems, product: products })
      .from(cartItems)
      .innerJoin(products, eq(products.id, cartItems.productId))
      .where(and(eq(cartItems.retailerOrgId, orgId), eq(products.supplierOrgId, input.supplierOrgId)))
      .orderBy(asc(products.name))
    if (rows.length === 0) throw AppError.invalid('Your cart has no items for this supplier.')

    const [supplier] = await tx
      .select({ org: organizations, settings: supplierSettings })
      .from(organizations)
      .leftJoin(supplierSettings, eq(supplierSettings.orgId, organizations.id))
      .where(eq(organizations.id, input.supplierOrgId))
      .limit(1)
    if (!supplier || supplier.org.role === 'retailer') throw AppError.invalid('This supplier is no longer available.')

    const lines: OrderLineInput[] = rows.map(({ cart, product }) => {
      if (!product.isActive) throw AppError.invalid(`${product.name} is no longer available. Remove it to continue.`)
      if (cart.qty < product.moq) {
        throw AppError.invalid(`${product.name} has a minimum order of ${product.moq} ${product.unit}.`)
      }
      return {
        productId: product.id,
        sku: product.sku,
        name: product.name,
        unit: product.unit,
        qty: cart.qty,
        unitPricePaisa: unitPriceForQty(product.pricePaisa, sortTiers(product.bulkTiersJson ?? []), cart.qty),
      }
    })

    const total = lines.reduce((sum, line) => sum + line.unitPricePaisa * line.qty, 0)
    const minOrder = supplier.settings?.minOrderPaisa ?? 0
    if (minOrder > 0 && total < minOrder) {
      throw AppError.invalid(`${supplier.org.name} takes orders of ${formatNpr(minOrder)} or more.`)
    }
    if (input.requestCredit && !supplier.settings?.creditEnabled) {
      throw AppError.invalid(`${supplier.org.name} does not offer credit. Untick the udharo request to continue.`)
    }

    const order = await insertOrder(tx, {
      retailerOrgId: orgId,
      supplierOrgId: input.supplierOrgId,
      orderType: 'reorder',
      status: 'pending',
      lines,
      retailerNote: input.note,
      requestCredit: input.requestCredit,
      placedBy: context.user.id,
    })
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'status',
      input.requestCredit ? 'Purchase order sent, with a request to buy on credit (udharo).' : 'Purchase order sent.',
      { status: 'pending' },
    )

    await tx.delete(cartItems).where(
      and(
        eq(cartItems.retailerOrgId, orgId),
        inArray(
          cartItems.productId,
          lines.map((line) => line.productId as string),
        ),
      ),
    )
    return { orderId: order.id, orderNo: order.orderNo }
  })
}

/** Sends a draft (created by a recurring schedule) to the supplier, re-priced at today's catalog prices. */
export async function submitDraftOrder(context: AppContext, orderId: string): Promise<void> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, orderId, 'retailer', 'submit_draft')
    const rows = await tx
      .select({ item: orderItems, product: products })
      .from(orderItems)
      .leftJoin(products, eq(products.id, orderItems.productId))
      .where(eq(orderItems.orderId, order.id))

    let total = 0
    for (const { item, product } of rows) {
      if (!product || !product.isActive) {
        throw AppError.invalid(`${item.name} is no longer available from this supplier. Discard this draft and reorder.`)
      }
      const qty = Math.max(item.qty, product.moq)
      const unitPricePaisa = unitPriceForQty(product.pricePaisa, sortTiers(product.bulkTiersJson ?? []), qty)
      total += unitPricePaisa * qty
      await tx
        .update(orderItems)
        .set({ qty, requestedQty: qty, unitPricePaisa, lineTotalPaisa: unitPricePaisa * qty })
        .where(eq(orderItems.id, item.id))
    }

    await tx
      .update(orders)
      .set({ status: 'pending', placedAt: new Date(), placedBy: context.user.id, totalPaisa: total })
      .where(eq(orders.id, order.id))
    await logOrderEvent(tx, order.id, actorOf(context), 'status', 'Draft reviewed and sent to the supplier.', {
      status: 'pending',
    })
  })
}

/** A buyer may withdraw an order the supplier has not accepted; a supplier may cancel one that is not yet dispatched or paid. */
export async function cancelOrder(context: AppContext, orderId: string, reason: string): Promise<void> {
  await db.transaction(async (tx) => {
    const side = await peekSide(tx, context, orderId)
    if (!side) throw AppError.notFound('Order not found.')
    assertAllowed(context, { capability: side === 'retailer' ? 'orders:place' : 'orders:manage' })
    const order = await lockOrderAs(tx, context, orderId, side, 'cancel')
    await tx
      .update(orders)
      .set({ status: 'cancelled', closedAt: new Date(), cancelReason: reason })
      .where(eq(orders.id, order.id))
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'status',
      `Order cancelled by the ${side === 'retailer' ? 'buyer' : 'supplier'}: ${reason}`,
      { status: 'cancelled' },
    )
  })
}

async function peekSide(tx: Tx, context: AppContext, orderId: string): Promise<OrderSide | null> {
  const [row] = await tx
    .select({ retailerOrgId: orders.retailerOrgId, supplierOrgId: orders.supplierOrgId })
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1)
  return row ? sideOf(row, context.org.id) : null
}

// ---------------------------------------------------------------------------
// Supplier: fulfilment
// ---------------------------------------------------------------------------

/**
 * Accepts a purchase order. The supplier may supply less than requested or lower a price,
 * but never more or dearer than the buyer ordered — that needs a new order or a quote.
 */
export async function acceptOrder(context: AppContext, input: AcceptOrderInput): Promise<void> {
  assertAllowed(context, { capability: 'orders:manage', side: 'supplier' })
  const today = todayNpt()

  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'supplier', 'accept')
    const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, order.id))
    const requested = new Map(input.items.map((item) => [item.itemId, item]))
    if (requested.size !== items.length || items.some((item) => !requested.has(item.id))) {
      throw AppError.conflict('This order has changed since you opened it. Refresh and try again.')
    }

    let total = 0
    let adjusted = 0
    for (const item of items) {
      const next = requested.get(item.id)!
      if (next.qty > item.requestedQty) {
        throw AppError.invalid(
          `${item.name}: the buyer ordered ${item.requestedQty} ${item.unit}. You can supply that many or fewer.`,
        )
      }
      if (next.unitPricePaisa > item.unitPricePaisa) {
        throw AppError.invalid(`${item.name}: the price cannot be raised above the ordered price.`)
      }
      if (next.qty !== item.qty || next.unitPricePaisa !== item.unitPricePaisa) {
        adjusted += 1
        await tx
          .update(orderItems)
          .set({ qty: next.qty, unitPricePaisa: next.unitPricePaisa, lineTotalPaisa: next.qty * next.unitPricePaisa })
          .where(eq(orderItems.id, item.id))
        const changes: string[] = []
        if (next.qty !== item.qty) changes.push(`quantity ${item.qty} → ${next.qty} ${item.unit}`)
        if (next.unitPricePaisa !== item.unitPricePaisa) {
          changes.push(`price ${formatNpr(item.unitPricePaisa)} → ${formatNpr(next.unitPricePaisa)}`)
        }
        await logOrderEvent(tx, order.id, actorOf(context), 'adjustment', `${item.name}: ${changes.join(', ')}.`)
      }
      total += next.qty * next.unitPricePaisa
    }
    if (items.every((item) => requested.get(item.id)!.qty === 0)) {
      throw AppError.invalid('There is nothing left to supply. Reject the order instead.')
    }

    let creditState = order.creditState
    let dueDate: string | null = null
    if (order.creditState === 'requested') {
      if (!input.credit) {
        throw AppError.invalid('The buyer asked to pay on credit. Approve it with a due date, or decline it.')
      }
      if (input.credit.approve) {
        if (!input.credit.dueDate || input.credit.dueDate < today) {
          throw AppError.invalid('Choose a credit due date from today onwards.')
        }
        creditState = 'approved'
        dueDate = input.credit.dueDate
      } else {
        creditState = 'declined'
      }
    }

    await tx
      .update(orders)
      .set({
        status: 'accepted',
        acceptedAt: new Date(),
        totalPaisa: total,
        supplierNote: input.supplierNote || null,
        creditState,
        dueDate,
      })
      .where(eq(orders.id, order.id))
    await recomputeOrderPayment(tx, order.id)

    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'status',
      adjusted > 0 ? `Order accepted with ${adjusted} adjusted ${adjusted === 1 ? 'line' : 'lines'}.` : 'Order accepted.',
      { status: 'accepted' },
    )
    if (order.creditState === 'requested') {
      await logOrderEvent(
        tx,
        order.id,
        actorOf(context),
        'credit',
        creditState === 'approved'
          ? `Credit (udharo) approved. Payment is due by ${dueDate}.`
          : 'Credit (udharo) declined. Payment is due before dispatch.',
      )
    }
    await issueReceipt(tx, { orderId: order.id, kind: 'order' })
  })
}

export async function rejectOrder(context: AppContext, orderId: string, reason: string): Promise<void> {
  assertAllowed(context, { capability: 'orders:manage', side: 'supplier' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, orderId, 'supplier', 'reject')
    await tx
      .update(orders)
      .set({ status: 'rejected', closedAt: new Date(), cancelReason: reason })
      .where(eq(orders.id, order.id))
    await logOrderEvent(tx, order.id, actorOf(context), 'status', `Order rejected: ${reason}`, { status: 'rejected' })
  })
}

export async function markPacked(context: AppContext, orderId: string): Promise<void> {
  assertAllowed(context, { capability: 'fulfilment:update', side: 'supplier' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, orderId, 'supplier', 'pack')
    await tx.update(orders).set({ status: 'packed', packedAt: new Date() }).where(eq(orders.id, order.id))
    await logOrderEvent(tx, order.id, actorOf(context), 'status', 'Order packed and ready to dispatch.', {
      status: 'packed',
    })
  })
}

export async function dispatchOrder(context: AppContext, input: DispatchInput): Promise<void> {
  assertAllowed(context, { capability: 'fulfilment:update', side: 'supplier' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'supplier', 'dispatch')
    const now = new Date()

    if (input.biltiPhotoFileId) {
      // The photo must be the supplier's own unattached upload; attaching it shares it with the buyer.
      const attached = await tx
        .update(files)
        .set({ orderId: order.id })
        .where(
          and(
            eq(files.id, input.biltiPhotoFileId),
            eq(files.orgId, context.org.id),
            eq(files.kind, 'bilti_photo'),
            isNull(files.orderId),
          ),
        )
        .returning({ id: files.id })
      if (attached.length === 0) throw AppError.invalid('The bilti photo could not be attached. Please upload it again.')
    }

    await tx.insert(shipments).values({
      orderId: order.id,
      deliveryMode: input.deliveryMode,
      carrierOrVan: input.carrierOrVan || null,
      driverName: input.driverName || null,
      driverPhone: input.driverPhone || null,
      biltiRef: input.biltiRef || null,
      biltiPhotoFileId: input.biltiPhotoFileId,
      note: input.note || null,
      dispatchedAt: now,
    })
    await tx.update(orders).set({ status: 'dispatched', dispatchedAt: now }).where(eq(orders.id, order.id))

    const detail =
      input.deliveryMode === 'bilti'
        ? `via ${input.carrierOrVan}, bilti no. ${input.biltiRef}`
        : input.deliveryMode === 'own_van'
          ? [input.carrierOrVan, input.driverName].filter(Boolean).join(', ')
          : 'ready for the buyer to collect'
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'shipment',
      `Dispatched — ${DELIVERY_MODE_LABEL[input.deliveryMode]}${detail ? `: ${detail}` : ''}.`,
      { status: 'dispatched', deliveryMode: input.deliveryMode },
    )
  })
}

/** The supplier closes a delivery the buyer has not confirmed. Stock is counted in when the buyer confirms receipt. */
export async function markDelivered(context: AppContext, orderId: string): Promise<void> {
  assertAllowed(context, { capability: 'fulfilment:update', side: 'supplier' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, orderId, 'supplier', 'mark_delivered')
    const now = new Date()
    await tx.update(orders).set({ status: 'delivered', deliveredAt: now }).where(eq(orders.id, order.id))
    await tx.update(shipments).set({ deliveredAt: now }).where(eq(shipments.orderId, order.id))
    await logOrderEvent(tx, order.id, actorOf(context), 'status', 'Marked as delivered by the supplier.', {
      status: 'delivered',
    })
  })
}

// ---------------------------------------------------------------------------
// Retailer: receiving goods
// ---------------------------------------------------------------------------

async function inventoryRowFor(tx: Tx, order: Order, item: { productId: string | null; name: string; unit: string }) {
  if (item.productId) {
    const [existing] = await tx
      .select()
      .from(retailerInventory)
      .where(and(eq(retailerInventory.retailerOrgId, order.retailerOrgId), eq(retailerInventory.productId, item.productId)))
      .for('update')
    if (existing) {
      if (existing.archivedAt) {
        await tx.update(retailerInventory).set({ archivedAt: null }).where(eq(retailerInventory.id, existing.id))
      }
      return existing
    }
    const [created] = await tx
      .insert(retailerInventory)
      .values({
        retailerOrgId: order.retailerOrgId,
        productId: item.productId,
        preferredSupplierId: order.supplierOrgId,
        currentQty: 0,
      })
      .returning()
    return created
  }

  // Unlisted goods from a custom quote are matched to a shop-defined item by name.
  const [existing] = await tx
    .select()
    .from(retailerInventory)
    .where(
      and(
        eq(retailerInventory.retailerOrgId, order.retailerOrgId),
        isNull(retailerInventory.productId),
        isNull(retailerInventory.archivedAt),
        sql`lower(${retailerInventory.customName}) = lower(${item.name})`,
      ),
    )
    .limit(1)
    .for('update')
  if (existing) return existing
  const [created] = await tx
    .insert(retailerInventory)
    .values({ retailerOrgId: order.retailerOrgId, customName: item.name, customUnit: item.unit, currentQty: 0 })
    .returning()
  return created
}

/**
 * The buyer confirms the goods arrived. Received quantities are added to live shop stock
 * exactly once, with a ledger entry per item linking back to the order.
 */
export async function confirmDelivery(
  context: AppContext,
  input: { orderId: string; items: Array<{ itemId: string; receivedQty: number }> },
): Promise<void> {
  assertAllowed(context, { capability: 'fulfilment:update', side: 'retailer' })
  await db.transaction(async (tx) => {
    const order = await lockOrderAs(tx, context, input.orderId, 'retailer', 'confirm_delivery')
    const items = await tx
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, order.id))
      .orderBy(asc(orderItems.position))
    const received = new Map(input.items.map((item) => [item.itemId, item.receivedQty]))
    const now = new Date()

    let units = 0
    let shortLines = 0
    for (const item of items) {
      if (item.qty === 0) continue
      const receivedQty = received.get(item.id) ?? item.qty
      await tx.update(orderItems).set({ receivedQty }).where(eq(orderItems.id, item.id))
      if (receivedQty < item.qty) shortLines += 1
      if (receivedQty <= 0) continue
      const inventoryRow = await inventoryRowFor(tx, order, item)
      await applyStockChange(tx, {
        item: inventoryRow,
        newQty: inventoryRow.currentQty + receivedQty,
        reason: 'delivery',
        orderId: order.id,
        userId: context.user.id,
      })
      units += receivedQty
    }

    await tx
      .update(orders)
      // deliveredAt is write-once: keep the supplier's timestamp if they already closed the delivery.
      .set({ status: 'delivered', stockSyncedAt: now, ...(order.deliveredAt ? {} : { deliveredAt: now }) })
      .where(eq(orders.id, order.id))
    await tx
      .update(shipments)
      .set({ deliveredAt: now })
      .where(and(eq(shipments.orderId, order.id), isNull(shipments.deliveredAt)))

    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'stock',
      `Delivery confirmed. ${units} ${units === 1 ? 'unit' : 'units'} added to shop stock${
        shortLines > 0 ? `; ${shortLines} ${shortLines === 1 ? 'line was' : 'lines were'} short` : ''
      }.`,
      { status: 'delivered' },
    )
  })
}
