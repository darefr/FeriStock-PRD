import 'server-only'
import { and, asc, desc, eq, inArray, sql } from 'drizzle-orm'
import { alias } from 'drizzle-orm/pg-core'
import type { QuoteStatus } from '@/lib/constants'
import { todayNpt } from '@/lib/dates'
import { db, type Tx } from '@/lib/db'
import { orders, organizations, products, quoteItems, quoteRequests, supplierSettings, type QuoteRequest } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { assertAllowed, type AppContext } from '@/lib/context'
import type { QuoteRequestInput, QuoteResponseInput } from '@/lib/validation'
import { actorOf, insertOrder, logOrderEvent } from './order-core'
import type { OrderSide } from './order-rules'
import { issueReceipt } from './receipts'

export type QuoteListItem = {
  id: string
  quoteNo: string
  status: QuoteStatus
  counterparty: { id: string; name: string }
  itemCount: number
  quotedTotalPaisa: number | null
  validUntil: string | null
  expired: boolean
  createdAt: string
}

const quoteSide = (quote: Pick<QuoteRequest, 'retailerOrgId' | 'supplierOrgId'>, orgId: string): OrderSide | null =>
  quote.retailerOrgId === orgId ? 'retailer' : quote.supplierOrgId === orgId ? 'supplier' : null

const isExpired = (quote: Pick<QuoteRequest, 'status' | 'validUntil'>, today: string) =>
  quote.status === 'quoted' && quote.validUntil !== null && quote.validUntil < today

export async function listQuotes(context: AppContext, side: OrderSide): Promise<QuoteListItem[]> {
  assertAllowed(context, { side })
  const counterpartyId = side === 'retailer' ? quoteRequests.supplierOrgId : quoteRequests.retailerOrgId
  const rows = await db
    .select({
      quote: quoteRequests,
      counterpartyName: organizations.name,
      itemCount: sql<number>`(select count(*) from ${quoteItems} where ${quoteItems.quoteId} = ${quoteRequests.id})`.mapWith(
        Number,
      ),
      quotedTotal: sql<
        number | null
      >`(select sum(${quoteItems.quotedQty} * ${quoteItems.quotedPricePaisa}) from ${quoteItems} where ${quoteItems.quoteId} = ${quoteRequests.id})`,
    })
    .from(quoteRequests)
    .innerJoin(organizations, eq(organizations.id, counterpartyId))
    .where(eq(side === 'retailer' ? quoteRequests.retailerOrgId : quoteRequests.supplierOrgId, context.org.id))
    .orderBy(desc(quoteRequests.createdAt))
    .limit(200)

  const today = todayNpt()
  return rows.map(({ quote, counterpartyName, itemCount, quotedTotal }) => ({
    id: quote.id,
    quoteNo: quote.quoteNo,
    status: quote.status,
    counterparty: { id: side === 'retailer' ? quote.supplierOrgId : quote.retailerOrgId, name: counterpartyName },
    itemCount,
    quotedTotalPaisa: quote.status === 'requested' || quotedTotal === null ? null : Number(quotedTotal),
    validUntil: quote.validUntil,
    expired: isExpired(quote, today),
    createdAt: quote.createdAt.toISOString(),
  }))
}

export type QuoteDetail = {
  id: string
  quoteNo: string
  status: QuoteStatus
  viewerSide: OrderSide
  retailer: { id: string; name: string; city: string; phone: string }
  supplier: { id: string; name: string; city: string; phone: string; creditEnabled: boolean; creditDays: number }
  retailerNote: string | null
  supplierNote: string | null
  validUntil: string | null
  expired: boolean
  order: { id: string; orderNo: string } | null
  createdAt: string
  respondedAt: string | null
  decidedAt: string | null
  items: Array<{
    id: string
    productId: string | null
    name: string
    unit: string
    qty: number
    targetPricePaisa: number | null
    quotedQty: number | null
    quotedPricePaisa: number | null
    listPricePaisa: number | null
  }>
  quotedTotalPaisa: number | null
}

export async function getQuoteDetail(context: AppContext, quoteId: string): Promise<QuoteDetail | null> {
  const retailer = alias(organizations, 'retailer')
  const supplier = alias(organizations, 'supplier')
  const [row] = await db
    .select({ quote: quoteRequests, retailer, supplier, settings: supplierSettings, orderNo: orders.orderNo })
    .from(quoteRequests)
    .innerJoin(retailer, eq(retailer.id, quoteRequests.retailerOrgId))
    .innerJoin(supplier, eq(supplier.id, quoteRequests.supplierOrgId))
    .leftJoin(supplierSettings, eq(supplierSettings.orgId, quoteRequests.supplierOrgId))
    .leftJoin(orders, eq(orders.id, quoteRequests.orderId))
    .where(eq(quoteRequests.id, quoteId))
    .limit(1)
  if (!row) return null
  const viewerSide = quoteSide(row.quote, context.org.id)
  if (!viewerSide) return null

  const itemRows = await db
    .select({ item: quoteItems, listPricePaisa: products.pricePaisa })
    .from(quoteItems)
    .leftJoin(products, eq(products.id, quoteItems.productId))
    .where(eq(quoteItems.quoteId, quoteId))
    .orderBy(asc(quoteItems.position))

  const { quote } = row
  const answered = quote.status !== 'requested' && itemRows.some(({ item }) => item.quotedQty !== null)
  return {
    id: quote.id,
    quoteNo: quote.quoteNo,
    status: quote.status,
    viewerSide,
    retailer: { id: row.retailer.id, name: row.retailer.name, city: row.retailer.city, phone: row.retailer.phone },
    supplier: {
      id: row.supplier.id,
      name: row.supplier.name,
      city: row.supplier.city,
      phone: row.supplier.phone,
      creditEnabled: row.settings?.creditEnabled ?? false,
      creditDays: row.settings?.creditDays ?? 15,
    },
    retailerNote: quote.retailerNote,
    supplierNote: quote.supplierNote,
    validUntil: quote.validUntil,
    expired: isExpired(quote, todayNpt()),
    order: quote.orderId && row.orderNo ? { id: quote.orderId, orderNo: row.orderNo } : null,
    createdAt: quote.createdAt.toISOString(),
    respondedAt: quote.respondedAt?.toISOString() ?? null,
    decidedAt: quote.decidedAt?.toISOString() ?? null,
    items: itemRows.map(({ item, listPricePaisa }) => ({
      id: item.id,
      productId: item.productId,
      name: item.name,
      unit: item.unit,
      qty: item.qty,
      targetPricePaisa: item.targetPricePaisa,
      quotedQty: item.quotedQty,
      quotedPricePaisa: item.quotedPricePaisa,
      listPricePaisa,
    })),
    quotedTotalPaisa: answered
      ? itemRows.reduce((sum, { item }) => sum + (item.quotedQty ?? 0) * (item.quotedPricePaisa ?? 0), 0)
      : null,
  }
}

/** A retailer asks a supplier to price custom quantities, bulk deals or items that are not in the catalog. */
export async function createQuoteRequest(context: AppContext, input: QuoteRequestInput): Promise<string> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  if (input.supplierOrgId === context.org.id) throw AppError.invalid('Choose another organization as the supplier.')

  return db.transaction(async (tx) => {
    const [supplier] = await tx
      .select({ role: organizations.role })
      .from(organizations)
      .where(eq(organizations.id, input.supplierOrgId))
      .limit(1)
    if (!supplier || supplier.role === 'retailer') throw AppError.invalid('This supplier is no longer available.')

    const productIds = input.items.map((item) => item.productId).filter((id): id is string => id !== null)
    if (productIds.length > 0) {
      const found = await tx
        .select({ id: products.id })
        .from(products)
        .where(and(inArray(products.id, productIds), eq(products.supplierOrgId, input.supplierOrgId)))
      if (found.length !== new Set(productIds).size) {
        throw AppError.invalid('Some of these products do not belong to this supplier.')
      }
    }

    const [quote] = await tx
      .insert(quoteRequests)
      .values({
        retailerOrgId: context.org.id,
        supplierOrgId: input.supplierOrgId,
        retailerNote: input.note || null,
        requestedBy: context.user.id,
      })
      .returning({ id: quoteRequests.id })
    await tx.insert(quoteItems).values(
      input.items.map((item, position) => ({
        quoteId: quote.id,
        productId: item.productId,
        name: item.name,
        unit: item.unit,
        qty: item.qty,
        targetPricePaisa: item.targetPricePaisa,
        position,
      })),
    )
    return quote.id
  })
}

async function lockQuoteAs(tx: Tx, context: AppContext, quoteId: string, side: OrderSide, allowed: QuoteStatus[]) {
  const [quote] = await tx.select().from(quoteRequests).where(eq(quoteRequests.id, quoteId)).for('update')
  if (!quote || quoteSide(quote, context.org.id) !== side) throw AppError.notFound('Quote request not found.')
  if (!allowed.includes(quote.status)) {
    throw AppError.conflict('This quote has changed since you opened it. Refresh to see its current status.')
  }
  return quote
}

/** The supplier answers with the quantities and prices they can offer. They may revise until the buyer decides. */
export async function respondToQuote(context: AppContext, input: QuoteResponseInput): Promise<void> {
  assertAllowed(context, { capability: 'orders:manage', side: 'supplier' })
  const today = todayNpt()
  if (input.validUntil && input.validUntil < today) throw AppError.invalid('Choose a validity date from today onwards.')

  await db.transaction(async (tx) => {
    const quote = await lockQuoteAs(tx, context, input.quoteId, 'supplier', ['requested', 'quoted'])
    const items = await tx.select().from(quoteItems).where(eq(quoteItems.quoteId, quote.id))
    const offers = new Map(input.items.map((item) => [item.itemId, item]))
    if (offers.size !== items.length || items.some((item) => !offers.has(item.id))) {
      throw AppError.conflict('This quote has changed since you opened it. Refresh and try again.')
    }
    if (items.every((item) => offers.get(item.id)!.quotedQty === 0)) {
      throw AppError.invalid('Offer at least one item, or decline the request instead.')
    }
    for (const item of items) {
      const offer = offers.get(item.id)!
      if (offer.quotedQty > 0 && offer.quotedPricePaisa <= 0) {
        throw AppError.invalid(`Enter a price for ${item.name}.`)
      }
      await tx
        .update(quoteItems)
        .set({ quotedQty: offer.quotedQty, quotedPricePaisa: offer.quotedPricePaisa })
        .where(eq(quoteItems.id, item.id))
    }
    await tx
      .update(quoteRequests)
      .set({
        status: 'quoted',
        supplierNote: input.supplierNote || null,
        validUntil: input.validUntil,
        respondedAt: new Date(),
      })
      .where(eq(quoteRequests.id, quote.id))
  })
}

/** Either side closes the request without an order: the supplier cannot supply, or the buyer turns the offer down. */
export async function declineQuote(context: AppContext, quoteId: string, note: string): Promise<void> {
  await db.transaction(async (tx) => {
    const [peek] = await tx
      .select({ retailerOrgId: quoteRequests.retailerOrgId, supplierOrgId: quoteRequests.supplierOrgId })
      .from(quoteRequests)
      .where(eq(quoteRequests.id, quoteId))
      .limit(1)
    const side = peek ? quoteSide(peek, context.org.id) : null
    if (!side) throw AppError.notFound('Quote request not found.')
    assertAllowed(context, { capability: side === 'retailer' ? 'orders:place' : 'orders:manage' })

    const quote = await lockQuoteAs(tx, context, quoteId, side, ['requested', 'quoted'])
    // A buyer withdrawing a request nobody has answered is a cancellation rather than a decline.
    const status: QuoteStatus = side === 'retailer' && quote.status === 'requested' ? 'cancelled' : 'declined'
    await tx
      .update(quoteRequests)
      .set({
        status,
        decidedAt: new Date(),
        ...(side === 'supplier' && note ? { supplierNote: note } : {}),
      })
      .where(eq(quoteRequests.id, quote.id))
  })
}

/** The buyer accepts the offer, which becomes an order the supplier has already agreed to. */
export async function acceptQuote(
  context: AppContext,
  input: { quoteId: string; requestCredit: boolean },
): Promise<{ orderId: string; orderNo: string }> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  const today = todayNpt()

  return db.transaction(async (tx) => {
    const quote = await lockQuoteAs(tx, context, input.quoteId, 'retailer', ['quoted'])
    if (isExpired(quote, today)) {
      throw AppError.invalid('This quote has expired. Ask the supplier for an updated quote.')
    }
    const rows = await tx
      .select({ item: quoteItems, sku: products.sku })
      .from(quoteItems)
      .leftJoin(products, eq(products.id, quoteItems.productId))
      .where(eq(quoteItems.quoteId, quote.id))
      .orderBy(asc(quoteItems.position))
    const offered = rows.filter(({ item }) => (item.quotedQty ?? 0) > 0)
    if (offered.length === 0) throw AppError.invalid('This quote has no items on offer.')

    if (input.requestCredit) {
      const [settings] = await tx
        .select({ creditEnabled: supplierSettings.creditEnabled })
        .from(supplierSettings)
        .where(eq(supplierSettings.orgId, quote.supplierOrgId))
        .limit(1)
      if (!settings?.creditEnabled) throw AppError.invalid('This supplier does not offer credit.')
    }

    const order = await insertOrder(tx, {
      retailerOrgId: quote.retailerOrgId,
      supplierOrgId: quote.supplierOrgId,
      orderType: 'custom',
      status: 'accepted',
      lines: offered.map(({ item, sku }) => ({
        productId: item.productId,
        sku,
        name: item.name,
        unit: item.unit,
        qty: item.quotedQty as number,
        unitPricePaisa: item.quotedPricePaisa as number,
      })),
      retailerNote: quote.retailerNote,
      supplierNote: quote.supplierNote,
      requestCredit: input.requestCredit,
      placedBy: context.user.id,
      quoteId: quote.id,
    })
    await tx
      .update(quoteRequests)
      .set({ status: 'accepted', decidedAt: new Date(), orderId: order.id })
      .where(eq(quoteRequests.id, quote.id))
    await logOrderEvent(
      tx,
      order.id,
      actorOf(context),
      'status',
      `Order created from accepted quote ${quote.quoteNo}${
        input.requestCredit ? ', with a request to buy on credit (udharo)' : ''
      }.`,
      { status: 'accepted' },
    )
    await issueReceipt(tx, { orderId: order.id, kind: 'order' })
    return { orderId: order.id, orderNo: order.orderNo }
  })
}
