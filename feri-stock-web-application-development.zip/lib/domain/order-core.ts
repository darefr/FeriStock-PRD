import 'server-only'
import { eq, sql } from 'drizzle-orm'
import { LIMITS, type OrderStatus, type OrderType } from '@/lib/constants'
import type { Executor, Tx } from '@/lib/db'
import { orderEvents, orderItems, orders, paymentRecords, type Order, type OrderEventMeta } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import type { AppContext } from '@/lib/context'
import { derivePaymentStatus, orderActions, type OrderAction, type OrderSide } from './order-rules'

/** Who an activity-log entry is attributed to. Scheduled jobs and gateway callbacks act as the system. */
export type Actor = { userId: string | null; orgId: string | null; name: string }

export const SYSTEM_ACTOR: Actor = { userId: null, orgId: null, name: 'FeriStock' }

export const actorOf = (context: AppContext): Actor => ({
  userId: context.user.id,
  orgId: context.org.id,
  name: `${context.user.name} · ${context.org.name}`,
})

/** Appends to the order's activity log. Entries can never be edited or removed (enforced by a trigger). */
export async function logOrderEvent(
  executor: Executor,
  orderId: string,
  actor: Actor,
  type: 'status' | 'payment' | 'credit' | 'shipment' | 'adjustment' | 'stock',
  message: string,
  meta?: OrderEventMeta,
): Promise<void> {
  await executor.insert(orderEvents).values({
    orderId,
    type,
    message,
    meta: meta ?? null,
    actorUserId: actor.userId,
    actorOrgId: actor.orgId,
    actorName: actor.name,
  })
}

export function sideOf(order: Pick<Order, 'retailerOrgId' | 'supplierOrgId'>, orgId: string): OrderSide | null {
  if (order.retailerOrgId === orgId) return 'retailer'
  if (order.supplierOrgId === orgId) return 'supplier'
  return null
}

/** Locks the order row for the rest of the transaction so concurrent state changes run one at a time. */
export async function lockOrder(tx: Tx, orderId: string): Promise<Order> {
  const [order] = await tx.select().from(orders).where(eq(orders.id, orderId)).for('update')
  if (!order) throw AppError.notFound('Order not found.')
  return order
}

/**
 * Locks an order on behalf of one of its two parties and checks the requested action is allowed
 * in its current state. Orders of other organizations are reported as "not found".
 */
export async function lockOrderAs(
  tx: Tx,
  context: AppContext,
  orderId: string,
  side: OrderSide,
  action?: OrderAction,
): Promise<Order> {
  const order = await lockOrder(tx, orderId)
  if (sideOf(order, context.org.id) !== side) throw AppError.notFound('Order not found.')
  if (action && !orderActions(order, side).has(action)) {
    throw AppError.conflict('This order has changed since you opened it. Refresh to see its current status.')
  }
  return order
}

/** Rebuilds the order's paid amount and payment status from its verified payment records. */
export async function recomputeOrderPayment(tx: Tx, orderId: string): Promise<Order> {
  const [totals] = await tx
    .select({
      paid: sql<number>`coalesce(sum(${paymentRecords.amountPaisa}) filter (where ${paymentRecords.status} = 'verified'), 0)`.mapWith(
        Number,
      ),
      pending: sql<number>`count(*) filter (where ${paymentRecords.status} = 'pending_verification')`.mapWith(Number),
    })
    .from(paymentRecords)
    .where(eq(paymentRecords.orderId, orderId))

  const [order] = await tx.select().from(orders).where(eq(orders.id, orderId))
  const paymentStatus = derivePaymentStatus({
    totalPaisa: order.totalPaisa,
    paidPaisa: totals.paid,
    creditState: order.creditState,
    hasPendingProof: totals.pending > 0,
  })
  const [updated] = await tx
    .update(orders)
    .set({ paidPaisa: totals.paid, paymentStatus })
    .where(eq(orders.id, orderId))
    .returning()
  return updated
}

export type OrderLineInput = {
  productId: string | null
  sku: string | null
  name: string
  unit: string
  qty: number
  unitPricePaisa: number
}

/** Creates an order with its line items. Prices are always supplied by the server, never by a client. */
export async function insertOrder(
  tx: Tx,
  params: {
    retailerOrgId: string
    supplierOrgId: string
    orderType: OrderType
    status: Extract<OrderStatus, 'draft' | 'pending' | 'accepted'>
    lines: OrderLineInput[]
    retailerNote?: string | null
    supplierNote?: string | null
    requestCredit?: boolean
    placedBy: string | null
    scheduleId?: string | null
    quoteId?: string | null
  },
): Promise<Order> {
  if (params.lines.length === 0) throw AppError.invalid('An order needs at least one item.')
  if (params.lines.length > LIMITS.maxOrderLines) {
    throw AppError.invalid(`An order can have up to ${LIMITS.maxOrderLines} items.`)
  }
  if (params.retailerOrgId === params.supplierOrgId) throw AppError.invalid('You cannot order from your own organization.')

  const totalPaisa = params.lines.reduce((sum, line) => sum + line.unitPricePaisa * line.qty, 0)
  if (!Number.isSafeInteger(totalPaisa)) throw AppError.invalid('This order is too large to process.')

  const now = new Date()
  const [order] = await tx
    .insert(orders)
    .values({
      retailerOrgId: params.retailerOrgId,
      supplierOrgId: params.supplierOrgId,
      orderType: params.orderType,
      status: params.status,
      totalPaisa,
      creditState: params.requestCredit ? 'requested' : 'none',
      retailerNote: params.retailerNote || null,
      supplierNote: params.supplierNote || null,
      placedBy: params.placedBy,
      scheduleId: params.scheduleId ?? null,
      quoteId: params.quoteId ?? null,
      placedAt: params.status === 'draft' ? null : now,
      acceptedAt: params.status === 'accepted' ? now : null,
    })
    .returning()

  await tx.insert(orderItems).values(
    params.lines.map((line, position) => ({
      orderId: order.id,
      productId: line.productId,
      sku: line.sku,
      name: line.name,
      unit: line.unit,
      requestedQty: line.qty,
      qty: line.qty,
      unitPricePaisa: line.unitPricePaisa,
      lineTotalPaisa: line.unitPricePaisa * line.qty,
      position,
    })),
  )
  return order
}

/** Visibility filter: an organization only ever sees orders it is a party to. */
export const orderVisibleTo = (orgId: string, side: OrderSide) =>
  eq(side === 'retailer' ? orders.retailerOrgId : orders.supplierOrgId, orgId)
