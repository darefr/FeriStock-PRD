export type StockStatus = 'ok' | 'low' | 'out'

export const STOCK_STATUS_LABEL: Record<StockStatus, string> = {
  ok: 'OK',
  low: 'Low stock',
  out: 'Out of stock',
}

/** Out when nothing is left; low when at or below the reorder threshold. */
export function stockStatus(currentQty: number, reorderThreshold: number): StockStatus {
  if (currentQty <= 0) return 'out'
  if (reorderThreshold > 0 && currentQty <= reorderThreshold) return 'low'
  return 'ok'
}

/**
 * How much to put in the cart for a low item: the shop's own restock quantity when set,
 * otherwise enough to bring stock back to twice the threshold. Never below the supplier's MOQ.
 */
export function suggestReorderQty(item: {
  currentQty: number
  reorderThreshold: number
  reorderQty: number | null
  moq: number
}): number {
  const moq = Math.max(1, item.moq)
  if (item.reorderQty && item.reorderQty > 0) return Math.max(item.reorderQty, moq)
  const target = Math.max(item.reorderThreshold * 2, moq)
  return Math.max(moq, target - Math.max(0, item.currentQty))
}
