import 'server-only'
import { and, asc, count, eq, inArray, isNotNull, isNull, sql } from 'drizzle-orm'
import type { DeliveryMode } from '@/lib/constants'
import { db } from '@/lib/db'
import { cartItems, organizations, products, retailerInventory, supplierSettings } from '@/lib/db/schema'
import { AppError } from '@/lib/errors'
import { formatNpr, nextTier, sortTiers, unitPriceForQty, type BulkTier } from '@/lib/money'
import { assertAllowed, type AppContext } from '@/lib/context'
import { stockStatus, suggestReorderQty } from './stock-rules'

export type CartLineDto = {
  productId: string
  sku: string
  name: string
  unit: string
  qty: number
  moq: number
  basePricePaisa: number
  unitPricePaisa: number
  lineTotalPaisa: number
  tiers: BulkTier[]
  nextTier: BulkTier | null
  schemeNote: string | null
  /** Why this line blocks checkout, if it does. */
  issue: string | null
}

export type CartGroupDto = {
  supplier: {
    id: string
    name: string
    city: string
    creditEnabled: boolean
    creditDays: number
    minOrderPaisa: number
    deliveryModes: DeliveryMode[]
    deliveryNote: string
  }
  lines: CartLineDto[]
  subtotalPaisa: number
  issue: string | null
  canPlace: boolean
}

export type CartDto = {
  groups: CartGroupDto[]
  lineCount: number
  totalPaisa: number
}

export async function getCart(context: AppContext): Promise<CartDto> {
  assertAllowed(context, { side: 'retailer' })
  const rows = await db
    .select({ cart: cartItems, product: products, supplier: organizations, settings: supplierSettings })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .innerJoin(organizations, eq(organizations.id, products.supplierOrgId))
    .leftJoin(supplierSettings, eq(supplierSettings.orgId, organizations.id))
    .where(eq(cartItems.retailerOrgId, context.org.id))
    .orderBy(asc(organizations.name), asc(products.name))

  const groups = new Map<string, CartGroupDto>()
  for (const { cart, product, supplier, settings } of rows) {
    const tiers = sortTiers(product.bulkTiersJson ?? [])
    const unitPricePaisa = unitPriceForQty(product.pricePaisa, tiers, cart.qty)
    let issue: string | null = null
    if (!product.isActive) issue = 'No longer available from this supplier.'
    else if (cart.qty < product.moq) issue = `Minimum order is ${product.moq} ${product.unit}.`

    let group = groups.get(supplier.id)
    if (!group) {
      group = {
        supplier: {
          id: supplier.id,
          name: supplier.name,
          city: supplier.city,
          creditEnabled: settings?.creditEnabled ?? false,
          creditDays: settings?.creditDays ?? 0,
          minOrderPaisa: settings?.minOrderPaisa ?? 0,
          deliveryModes: settings?.deliveryModes ?? [],
          deliveryNote: settings?.deliveryNote ?? '',
        },
        lines: [],
        subtotalPaisa: 0,
        issue: null,
        canPlace: true,
      }
      groups.set(supplier.id, group)
    }
    group.lines.push({
      productId: product.id,
      sku: product.sku,
      name: product.name,
      unit: product.unit,
      qty: cart.qty,
      moq: product.moq,
      basePricePaisa: product.pricePaisa,
      unitPricePaisa,
      lineTotalPaisa: unitPricePaisa * cart.qty,
      tiers,
      nextTier: nextTier(tiers, cart.qty),
      schemeNote: product.schemeNote,
      issue,
    })
    group.subtotalPaisa += unitPricePaisa * cart.qty
  }

  const result = [...groups.values()]
  for (const group of result) {
    if (group.supplier.minOrderPaisa > 0 && group.subtotalPaisa < group.supplier.minOrderPaisa) {
      group.issue = `${group.supplier.name} takes orders of ${formatNpr(group.supplier.minOrderPaisa)} or more.`
    }
    group.canPlace = group.issue === null && group.lines.every((line) => line.issue === null)
  }

  return {
    groups: result,
    lineCount: rows.length,
    totalPaisa: result.reduce((sum, group) => sum + group.subtotalPaisa, 0),
  }
}

export async function getCartCount(orgId: string): Promise<number> {
  const [{ value }] = await db.select({ value: count() }).from(cartItems).where(eq(cartItems.retailerOrgId, orgId))
  return value
}

/** Sets the quantity for a product in the cart; zero removes the line. */
export async function setCartQty(context: AppContext, productId: string, qty: number): Promise<void> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  const orgId = context.org.id

  if (qty <= 0) {
    await db.delete(cartItems).where(and(eq(cartItems.retailerOrgId, orgId), eq(cartItems.productId, productId)))
    return
  }

  const [product] = await db
    .select({
      id: products.id,
      isActive: products.isActive,
      supplierOrgId: products.supplierOrgId,
      supplierRole: organizations.role,
    })
    .from(products)
    .innerJoin(organizations, eq(organizations.id, products.supplierOrgId))
    .where(eq(products.id, productId))
    .limit(1)
  if (!product || !product.isActive || product.supplierRole === 'retailer') {
    throw AppError.invalid('This product is no longer available.')
  }
  if (product.supplierOrgId === orgId) throw AppError.invalid('You cannot order from your own catalog.')

  await db
    .insert(cartItems)
    .values({ retailerOrgId: orgId, productId, qty })
    .onConflictDoUpdate({ target: [cartItems.retailerOrgId, cartItems.productId], set: { qty } })
}

/**
 * One-tap reorder: puts inventory items into the cart at their suggested restock quantity.
 * With no ids given it takes every low or out-of-stock item that has auto-reorder switched on.
 * An item already in the cart keeps the larger of the two quantities.
 */
export async function addInventoryToCart(
  context: AppContext,
  inventoryIds: string[] | 'low-stock',
): Promise<{ added: number; skipped: number }> {
  assertAllowed(context, { capability: 'orders:place', side: 'retailer' })
  const orgId = context.org.id
  if (Array.isArray(inventoryIds) && inventoryIds.length === 0) return { added: 0, skipped: 0 }

  const rows = await db
    .select({ item: retailerInventory, product: products, supplierRole: organizations.role })
    .from(retailerInventory)
    .innerJoin(products, eq(products.id, retailerInventory.productId))
    .innerJoin(organizations, eq(organizations.id, products.supplierOrgId))
    .where(
      and(
        eq(retailerInventory.retailerOrgId, orgId),
        isNull(retailerInventory.archivedAt),
        isNotNull(retailerInventory.productId),
        Array.isArray(inventoryIds) ? inArray(retailerInventory.id, inventoryIds) : undefined,
      ),
    )

  const candidates = rows.filter(({ item, product, supplierRole }) => {
    if (!product.isActive || supplierRole === 'retailer' || product.supplierOrgId === orgId) return false
    if (Array.isArray(inventoryIds)) return true
    return item.autoReorder && stockStatus(item.currentQty, item.reorderThreshold) !== 'ok'
  })
  const requested = Array.isArray(inventoryIds) ? inventoryIds.length : candidates.length
  if (candidates.length === 0) return { added: 0, skipped: requested }

  await db
    .insert(cartItems)
    .values(
      candidates.map(({ item, product }) => ({
        retailerOrgId: orgId,
        productId: product.id,
        qty: suggestReorderQty({
          currentQty: item.currentQty,
          reorderThreshold: item.reorderThreshold,
          reorderQty: item.reorderQty,
          moq: product.moq,
        }),
      })),
    )
    .onConflictDoUpdate({
      target: [cartItems.retailerOrgId, cartItems.productId],
      set: { qty: sql`greatest(${cartItems.qty}, excluded.qty)` },
    })

  return { added: candidates.length, skipped: requested - candidates.length }
}
