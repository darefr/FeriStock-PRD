import { z } from 'zod'
import {
  DELIVERY_MODES,
  GATEWAY_ENVS,
  LIMITS,
  MEMBER_ROLES,
  ORG_ROLES,
  SCHEDULE_FREQUENCIES,
  SCHEDULE_MODES,
} from './constants'
import { isDateString, isTimeOfDay } from './dates'

// Schemas are shared by forms (instant feedback) and server actions (the authority).

export const idSchema = z.uuid('Invalid reference.')

const qty = z.number().int('Use a whole number.').min(1, 'Must be at least 1.').max(LIMITS.maxQty, 'Quantity is too large.')
const qtyOrZero = z.number().int('Use a whole number.').min(0).max(LIMITS.maxQty, 'Quantity is too large.')
const amount = z
  .number()
  .int()
  .min(1, 'Enter an amount greater than zero.')
  .max(LIMITS.maxPricePaisa, 'Amount is too large.')
const amountOrZero = z.number().int().min(0).max(LIMITS.maxPricePaisa, 'Amount is too large.')
const optionalText = (max: number) => z.string().trim().max(max, `Keep this under ${max} characters.`).default('')
const dateString = z.string().refine(isDateString, 'Choose a valid date.')

export const phoneSchema = z
  .string()
  .trim()
  .regex(/^(\+977[\s-]?)?\d[\d\s-]{5,12}\d$/, 'Enter a valid phone number.')

export const organizationSchema = z.object({
  name: z.string().trim().min(2, 'Enter your business name.').max(120),
  role: z.enum(ORG_ROLES, 'Choose how your business uses FeriStock.'),
  panVatNo: z
    .string()
    .trim()
    .regex(/^\d{9}$/, 'PAN/VAT number must be exactly 9 digits.'),
  city: z.string().trim().min(2, 'Enter your city.').max(60),
  address: z.string().trim().min(3, 'Enter your street address.').max(200),
  phone: phoneSchema,
  email: z.union([z.literal(''), z.email('Enter a valid email address.')]).default(''),
})
export type OrganizationInput = z.infer<typeof organizationSchema>

export const joinOrganizationSchema = z.object({
  code: z
    .string()
    .trim()
    .transform((value) => value.toUpperCase().replace(/[^A-Z0-9]/g, ''))
    .refine((value) => value.length === 12, 'Invite codes have 12 characters.'),
})

export const inviteSchema = z.object({ role: z.enum(MEMBER_ROLES) })
export const memberRoleSchema = z.object({ membershipId: idSchema, role: z.enum(MEMBER_ROLES) })

export const supplierSettingsSchema = z.object({
  deliveryModes: z.array(z.enum(DELIVERY_MODES)).min(1, 'Offer at least one delivery method.'),
  deliveryNote: optionalText(300),
  creditEnabled: z.boolean(),
  creditDays: z.number().int().min(1, 'At least 1 day.').max(180, 'At most 180 days.'),
  minOrderPaisa: amountOrZero,
})
export type SupplierSettingsInput = z.infer<typeof supplierSettingsSchema>

export const paymentConfigSchema = z.object({
  esewaEnabled: z.boolean(),
  esewaMerchantId: z.string().trim().max(80).default(''),
  // Left blank to keep the secret that is already stored.
  esewaSecret: z.string().max(200).default(''),
  esewaEnv: z.enum(GATEWAY_ENVS),
  khaltiEnabled: z.boolean(),
  khaltiSecret: z.string().trim().max(200).default(''),
  khaltiEnv: z.enum(GATEWAY_ENVS),
  bankName: optionalText(80),
  accountName: optionalText(120),
  accountNumber: optionalText(40),
  branch: optionalText(80),
})
export type PaymentConfigInput = z.infer<typeof paymentConfigSchema>

export const bulkTierSchema = z.object({
  minQty: z.number().int('Use a whole number.').min(2, 'A tier starts at 2 or more.').max(LIMITS.maxQty),
  pricePaisa: amount,
})

export const productSchema = z
  .object({
    sku: z
      .string()
      .trim()
      .min(1, 'Enter a SKU.')
      .max(40)
      .regex(/^[A-Za-z0-9._/-]+$/, 'Use letters, numbers, dot, dash or slash only.'),
    name: z.string().trim().min(2, 'Enter the product name.').max(140),
    unit: z.string().trim().min(1, 'Enter the selling unit.').max(20),
    category: optionalText(60),
    pricePaisa: amount,
    moq: qty,
    schemeNote: optionalText(240),
    bulkTiers: z.array(bulkTierSchema).max(LIMITS.maxBulkTiers, `Up to ${LIMITS.maxBulkTiers} price tiers.`),
    isActive: z.boolean(),
  })
  .superRefine((product, context) => {
    const tiers = [...product.bulkTiers].sort((a, b) => a.minQty - b.minQty)
    let previousPrice = product.pricePaisa
    let previousQty = product.moq
    tiers.forEach((tier, index) => {
      if (tier.minQty <= previousQty) {
        context.addIssue({
          code: 'custom',
          path: ['bulkTiers'],
          message:
            index === 0
              ? 'The first tier must start above the minimum order quantity.'
              : 'Each tier must start at a higher quantity than the one before.',
        })
      }
      if (tier.pricePaisa >= previousPrice) {
        context.addIssue({
          code: 'custom',
          path: ['bulkTiers'],
          message: 'Each tier price must be lower than the price before it.',
        })
      }
      previousPrice = tier.pricePaisa
      previousQty = tier.minQty
    })
  })
export type ProductInput = z.infer<typeof productSchema>

export const addInventorySchema = z
  .object({
    productId: idSchema.nullable(),
    customName: optionalText(140),
    customUnit: optionalText(20),
    currentQty: qtyOrZero,
    reorderThreshold: qtyOrZero,
    reorderQty: qty.nullable(),
  })
  .superRefine((item, context) => {
    if (item.productId) return
    if (item.customName.length < 2) {
      context.addIssue({ code: 'custom', path: ['customName'], message: 'Enter the item name.' })
    }
    if (item.customUnit.length < 1) {
      context.addIssue({ code: 'custom', path: ['customUnit'], message: 'Enter the unit.' })
    }
  })
export type AddInventoryInput = z.infer<typeof addInventorySchema>

export const adjustStockSchema = z.object({
  inventoryId: idSchema,
  delta: z.number().int().min(-LIMITS.maxQty).max(LIMITS.maxQty),
})

export const setStockSchema = z.object({ inventoryId: idSchema, qty: qtyOrZero })

export const inventorySettingsSchema = z.object({
  inventoryId: idSchema,
  reorderThreshold: qtyOrZero,
  reorderQty: qty.nullable(),
  alertsEnabled: z.boolean(),
  autoReorder: z.boolean(),
})

export const cartQtySchema = z.object({ productId: idSchema, qty: qtyOrZero })

export const placeOrderSchema = z.object({
  supplierOrgId: idSchema,
  note: optionalText(500),
  requestCredit: z.boolean(),
})

export const acceptOrderSchema = z.object({
  orderId: idSchema,
  items: z.array(z.object({ itemId: idSchema, qty: qtyOrZero, unitPricePaisa: amountOrZero })).min(1),
  supplierNote: optionalText(500),
  credit: z.object({ approve: z.boolean(), dueDate: dateString.nullable() }).nullable(),
})
export type AcceptOrderInput = z.infer<typeof acceptOrderSchema>

export const reasonSchema = z.object({
  orderId: idSchema,
  reason: z.string().trim().min(3, 'Give a short reason.').max(300),
})

export const dispatchSchema = z
  .object({
    orderId: idSchema,
    deliveryMode: z.enum(DELIVERY_MODES),
    carrierOrVan: optionalText(120),
    driverName: optionalText(80),
    driverPhone: z.union([z.literal(''), phoneSchema]).default(''),
    biltiRef: optionalText(60),
    biltiPhotoFileId: idSchema.nullable(),
    note: optionalText(300),
  })
  .superRefine((shipment, context) => {
    if (shipment.deliveryMode === 'bilti') {
      if (!shipment.carrierOrVan) {
        context.addIssue({ code: 'custom', path: ['carrierOrVan'], message: 'Enter the transport company.' })
      }
      if (!shipment.biltiRef) {
        context.addIssue({ code: 'custom', path: ['biltiRef'], message: 'Enter the bilti number.' })
      }
    }
    if (shipment.deliveryMode === 'own_van' && !shipment.carrierOrVan && !shipment.driverName) {
      context.addIssue({
        code: 'custom',
        path: ['carrierOrVan'],
        message: 'Enter the vehicle number or the driver’s name.',
      })
    }
  })
export type DispatchInput = z.infer<typeof dispatchSchema>

export const confirmDeliverySchema = z.object({
  orderId: idSchema,
  items: z.array(z.object({ itemId: idSchema, receivedQty: qtyOrZero })).min(1),
})

export const creditDecisionSchema = z.object({
  orderId: idSchema,
  approve: z.boolean(),
  dueDate: dateString.nullable(),
})

export const gatewayPaymentSchema = z.object({
  orderId: idSchema,
  method: z.enum(['esewa', 'khalti']),
  amountPaisa: amount,
})

export const paymentProofSchema = z
  .object({
    orderId: idSchema,
    amountPaisa: amount,
    transactionRef: optionalText(80),
    proofFileId: idSchema.nullable(),
    note: optionalText(300),
  })
  .refine((proof) => proof.transactionRef.length > 0 || proof.proofFileId !== null, {
    path: ['transactionRef'],
    message: 'Enter the transaction reference or attach a screenshot.',
  })

export const cashPaymentSchema = z.object({
  orderId: idSchema,
  amountPaisa: amount,
  transactionRef: optionalText(80),
  note: optionalText(300),
})

export const rejectProofSchema = z.object({
  paymentId: idSchema,
  reason: z.string().trim().min(3, 'Give a short reason.').max(300),
})

export const scheduleSchema = z
  .object({
    id: idSchema.nullable(),
    supplierOrgId: idSchema,
    name: z.string().trim().min(2, 'Name this schedule.').max(80),
    frequency: z.enum(SCHEDULE_FREQUENCIES),
    dayOfWeek: z.number().int().min(0).max(6).nullable(),
    dayOfMonth: z.number().int().min(1).max(28).nullable(),
    timeOfDay: z.string().refine(isTimeOfDay, 'Choose a time.'),
    mode: z.enum(SCHEDULE_MODES),
    isActive: z.boolean(),
    items: z
      .array(z.object({ productId: idSchema, qty }))
      .min(1, 'Add at least one product.')
      .max(LIMITS.maxOrderLines),
  })
  .superRefine((schedule, context) => {
    if (schedule.frequency === 'weekly' && schedule.dayOfWeek === null) {
      context.addIssue({ code: 'custom', path: ['dayOfWeek'], message: 'Choose a day of the week.' })
    }
    if (schedule.frequency === 'monthly' && schedule.dayOfMonth === null) {
      context.addIssue({ code: 'custom', path: ['dayOfMonth'], message: 'Choose a day of the month.' })
    }
  })
export type ScheduleInput = z.infer<typeof scheduleSchema>

export const quoteRequestSchema = z.object({
  supplierOrgId: idSchema,
  note: optionalText(600),
  items: z
    .array(
      z.object({
        productId: idSchema.nullable(),
        name: z.string().trim().min(2, 'Enter the item name.').max(140),
        unit: z.string().trim().min(1, 'Enter the unit.').max(20),
        qty,
        targetPricePaisa: amount.nullable(),
      }),
    )
    .min(1, 'Add at least one item.')
    .max(LIMITS.maxOrderLines),
})
export type QuoteRequestInput = z.infer<typeof quoteRequestSchema>

export const quoteResponseSchema = z.object({
  quoteId: idSchema,
  supplierNote: optionalText(600),
  validUntil: dateString.nullable(),
  items: z
    .array(z.object({ itemId: idSchema, quotedQty: qtyOrZero, quotedPricePaisa: amountOrZero }))
    .min(1),
})
export type QuoteResponseInput = z.infer<typeof quoteResponseSchema>

export const quoteDecisionSchema = z.object({
  quoteId: idSchema,
  note: optionalText(300),
})

export const acceptQuoteSchema = z.object({ quoteId: idSchema, requestCredit: z.boolean() })

export const profileSchema = z.object({ name: z.string().trim().min(2, 'Enter your name.').max(80) })

export const credentialsSchema = {
  name: z.string().trim().min(2, 'Enter your full name.').max(80),
  email: z.email('Enter a valid email address.'),
  password: z.string().min(8, 'Use at least 8 characters.').max(128),
}

/** First error message per field path, for showing next to form controls. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const result: Record<string, string> = {}
  for (const issue of error.issues) {
    const key = issue.path.map(String).join('.') || '_form'
    result[key] ??= issue.message
  }
  return result
}
