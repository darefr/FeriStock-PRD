import NepaliDate from 'nepali-date-converter'
import { nptParts } from './dates'

/** The Bikram Sambat date ("miti") for an instant, as written on Nepali bills: "5 Mangsir 2083". */
export function formatBsDate(instant: Date | string): string {
  const { year, month, day } = nptParts(new Date(instant))
  // The converter reads local calendar fields, so it is given a local date built from Nepal's calendar day.
  const bs = new NepaliDate(new Date(year, month - 1, day, 12))
  return `${bs.getDate()} ${bs.format('MMMM')} ${bs.getYear()}`
}
