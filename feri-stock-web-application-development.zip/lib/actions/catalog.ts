'use server'

import { z } from 'zod'
import { createProduct, setProductActive, updateProduct } from '@/lib/domain/catalog'
import { idSchema, productSchema } from '@/lib/validation'
import { runAction } from './safe'
import type { ActionResult } from './types'

const supplierCatalog = { capability: 'catalog:manage', side: 'supplier' } as const

export async function saveProductAction(productId: string | null, raw: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction(productSchema, raw, supplierCatalog, async (input, context) => {
    if (productId) {
      const id = idSchema.parse(productId)
      await updateProduct(context, id, input)
      return { id }
    }
    return { id: await createProduct(context, input) }
  })
}

export async function setProductActiveAction(raw: unknown): Promise<ActionResult> {
  return runAction(
    z.object({ productId: idSchema, isActive: z.boolean() }),
    raw,
    supplierCatalog,
    async (input, context) => {
      await setProductActive(context, input.productId, input.isActive)
    },
  )
}
