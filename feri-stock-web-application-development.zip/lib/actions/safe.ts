import 'server-only'
import { revalidatePath } from 'next/cache'
import { unstable_rethrow } from 'next/navigation'
import type { z } from 'zod'
import { AppError } from '@/lib/errors'
import { authorize, type AppContext, type AuthorizeOptions } from '@/lib/session'
import { fieldErrors } from '@/lib/validation'
import type { ActionResult } from './types'

export function failure(error: unknown): { ok: false; error: string } {
  unstable_rethrow(error)
  if (error instanceof AppError) return { ok: false, error: error.message }
  console.error('[action] unexpected error', error)
  return { ok: false, error: 'Something went wrong on our side. Please try again.' }
}

/**
 * The one path every mutation takes: validate the input, authenticate and authorize the caller,
 * run the domain function, then refresh cached app data. Expected failures come back as messages;
 * anything unexpected is logged and reported generically.
 */
export async function runAction<Schema extends z.ZodType, Result>(
  schema: Schema,
  raw: unknown,
  options: AuthorizeOptions,
  handler: (input: z.output<Schema>, context: AppContext) => Promise<Result>,
  // Rapid-fire actions (stock taps) keep their screen in sync themselves and skip the page refresh.
  { revalidate = true }: { revalidate?: boolean } = {},
): Promise<ActionResult<Result>> {
  try {
    const parsed = schema.safeParse(raw)
    if (!parsed.success) {
      const fields = fieldErrors(parsed.error)
      return { ok: false, error: Object.values(fields)[0] ?? 'Please check the form and try again.', fields }
    }
    const context = await authorize(options)
    const data = await handler(parsed.data, context)
    if (revalidate) revalidatePath('/app', 'layout')
    return { ok: true, data }
  } catch (error) {
    return failure(error)
  }
}
