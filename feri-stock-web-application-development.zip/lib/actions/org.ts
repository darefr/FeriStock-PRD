'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'
import {
  changeMemberRole,
  createInvite,
  createOrganization,
  joinOrganization,
  removeMember,
  removeQrImage,
  revokeInvite,
  updateOrganization,
  updatePaymentConfig,
  updateSupplierSettings,
  type InviteDto,
} from '@/lib/domain/orgs'
import { AppError } from '@/lib/errors'
import { getContext, getSessionUser } from '@/lib/session'
import {
  fieldErrors,
  idSchema,
  inviteSchema,
  joinOrganizationSchema,
  memberRoleSchema,
  organizationSchema,
  paymentConfigSchema,
  supplierSettingsSchema,
} from '@/lib/validation'
import { failure, runAction } from './safe'
import type { ActionResult } from './types'

// Onboarding runs before the user has an organization, so it authenticates by session only.
async function requireNewMember() {
  const user = await getSessionUser()
  if (!user) throw AppError.unauthenticated()
  if (await getContext()) throw AppError.conflict('You already belong to an organization.')
  return user
}

export async function createOrganizationAction(raw: unknown): Promise<ActionResult> {
  try {
    const parsed = organizationSchema.safeParse(raw)
    if (!parsed.success) {
      const fields = fieldErrors(parsed.error)
      return { ok: false, error: Object.values(fields)[0] ?? 'Please check the form.', fields }
    }
    const user = await requireNewMember()
    await createOrganization(user, parsed.data)
    revalidatePath('/', 'layout')
    return { ok: true, data: undefined }
  } catch (error) {
    return failure(error)
  }
}

export async function joinOrganizationAction(raw: unknown): Promise<ActionResult> {
  try {
    const parsed = joinOrganizationSchema.safeParse(raw)
    if (!parsed.success) {
      const fields = fieldErrors(parsed.error)
      return { ok: false, error: Object.values(fields)[0] ?? 'Enter a valid invite code.', fields }
    }
    const user = await requireNewMember()
    await joinOrganization(user, parsed.data.code)
    revalidatePath('/', 'layout')
    return { ok: true, data: undefined }
  } catch (error) {
    return failure(error)
  }
}

export async function updateOrganizationAction(raw: unknown): Promise<ActionResult> {
  return runAction(organizationSchema, raw, { capability: 'org:manage' }, async (input, context) => {
    await updateOrganization(context, input)
  })
}

export async function updateSupplierSettingsAction(raw: unknown): Promise<ActionResult> {
  return runAction(supplierSettingsSchema, raw, { capability: 'org:manage', side: 'supplier' }, async (input, context) => {
    await updateSupplierSettings(context, input)
  })
}

export async function updatePaymentConfigAction(raw: unknown): Promise<ActionResult> {
  return runAction(
    paymentConfigSchema,
    raw,
    { capability: 'payments:configure', side: 'supplier' },
    async (input, context) => {
      await updatePaymentConfig(context, input)
    },
  )
}

export async function removeQrImageAction(): Promise<ActionResult> {
  return runAction(z.object({}), {}, { capability: 'payments:configure', side: 'supplier' }, async (_input, context) => {
    await removeQrImage(context)
  })
}

export async function createInviteAction(raw: unknown): Promise<ActionResult<InviteDto>> {
  return runAction(inviteSchema, raw, { capability: 'team:manage' }, (input, context) => createInvite(context, input.role))
}

export async function revokeInviteAction(raw: unknown): Promise<ActionResult> {
  return runAction(z.object({ inviteId: idSchema }), raw, { capability: 'team:manage' }, async (input, context) => {
    await revokeInvite(context, input.inviteId)
  })
}

export async function changeMemberRoleAction(raw: unknown): Promise<ActionResult> {
  return runAction(memberRoleSchema, raw, { capability: 'team:manage' }, async (input, context) => {
    await changeMemberRole(context, input.membershipId, input.role)
  })
}

export async function removeMemberAction(raw: unknown): Promise<ActionResult> {
  return runAction(z.object({ membershipId: idSchema }), raw, { capability: 'team:manage' }, async (input, context) => {
    await removeMember(context, input.membershipId)
  })
}
