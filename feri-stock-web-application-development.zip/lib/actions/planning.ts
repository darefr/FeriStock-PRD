'use server'

import { z } from 'zod'
import { acceptQuote, createQuoteRequest, declineQuote, respondToQuote } from '@/lib/domain/quotes'
import { deleteSchedule, runScheduleNow, saveSchedule, setScheduleActive } from '@/lib/domain/schedules'
import {
  acceptQuoteSchema,
  idSchema,
  quoteDecisionSchema,
  quoteRequestSchema,
  quoteResponseSchema,
  scheduleSchema,
} from '@/lib/validation'
import { runAction } from './safe'
import type { ActionResult } from './types'

const buyerOrders = { capability: 'orders:place', side: 'retailer' } as const
const sellerOrders = { capability: 'orders:manage', side: 'supplier' } as const
const scheduleIdSchema = z.object({ scheduleId: idSchema })

// --- Recurring restock schedules -------------------------------------------

export async function saveScheduleAction(raw: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction(scheduleSchema, raw, buyerOrders, async (input, context) => ({
    id: await saveSchedule(context, input),
  }))
}

export async function setScheduleActiveAction(raw: unknown): Promise<ActionResult> {
  return runAction(scheduleIdSchema.extend({ isActive: z.boolean() }), raw, buyerOrders, async (input, context) => {
    await setScheduleActive(context, input.scheduleId, input.isActive)
  })
}

export async function deleteScheduleAction(raw: unknown): Promise<ActionResult> {
  return runAction(scheduleIdSchema, raw, buyerOrders, async (input, context) => {
    await deleteSchedule(context, input.scheduleId)
  })
}

export async function runScheduleNowAction(
  raw: unknown,
): Promise<ActionResult<{ orderId: string; orderNo: string; status: 'draft' | 'pending' }>> {
  return runAction(scheduleIdSchema, raw, buyerOrders, async (input, context) => {
    const result = await runScheduleNow(context, input.scheduleId)
    // runScheduleNow throws when nothing could be ordered, so a result is always present here.
    return result as { orderId: string; orderNo: string; status: 'draft' | 'pending' }
  })
}

// --- Custom orders / quote requests ----------------------------------------

export async function createQuoteRequestAction(raw: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction(quoteRequestSchema, raw, buyerOrders, async (input, context) => ({
    id: await createQuoteRequest(context, input),
  }))
}

export async function respondToQuoteAction(raw: unknown): Promise<ActionResult> {
  return runAction(quoteResponseSchema, raw, sellerOrders, async (input, context) => {
    await respondToQuote(context, input)
  })
}

// Either side may close a quote; the acting side's role is checked in the domain layer.
export async function declineQuoteAction(raw: unknown): Promise<ActionResult> {
  return runAction(quoteDecisionSchema, raw, {}, async (input, context) => {
    await declineQuote(context, input.quoteId, input.note)
  })
}

export async function acceptQuoteAction(raw: unknown): Promise<ActionResult<{ orderId: string; orderNo: string }>> {
  return runAction(acceptQuoteSchema, raw, buyerOrders, (input, context) => acceptQuote(context, input))
}
