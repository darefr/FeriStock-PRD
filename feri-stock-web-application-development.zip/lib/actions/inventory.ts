'use server'

import { z } from 'zod'
import { addInventoryToCart, setCartQty } from '@/lib/domain/cart'
import {
  addInventoryItem,
  adjustStock,
  archiveInventoryItem,
  setStock,
  updateInventorySettings,
} from '@/lib/domain/inventory'
import {
  addInventorySchema,
  adjustStockSchema,
  cartQtySchema,
  idSchema,
  inventorySettingsSchema,
  setStockSchema,
} from '@/lib/validation'
import { runAction } from './safe'
import type { ActionResult } from './types'

export async function addInventoryItemAction(raw: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction(
    addInventorySchema,
    raw,
    { capability: 'inventory:manage', side: 'retailer' },
    async (input, context) => ({ id: await addInventoryItem(context, input) }),
  )
}

/** Returns the quantity now on record, so the screen can settle on the server's number. */
export async function adjustStockAction(raw: unknown): Promise<ActionResult<{ qty: number }>> {
  return runAction(
    adjustStockSchema,
    raw,
    { capability: 'stock:update', side: 'retailer' },
    async (input, context) => ({ qty: await adjustStock(context, input.inventoryId, input.delta) }),
    { revalidate: false },
  )
}

export async function setStockAction(raw: unknown): Promise<ActionResult<{ qty: number }>> {
  return runAction(
    setStockSchema,
    raw,
    { capability: 'stock:update', side: 'retailer' },
    async (input, context) => ({ qty: await setStock(context, input.inventoryId, input.qty) }),
    { revalidate: false },
  )
}

export async function updateInventorySettingsAction(raw: unknown): Promise<ActionResult> {
  return runAction(
    inventorySettingsSchema,
    raw,
    { capability: 'inventory:manage', side: 'retailer' },
    async (input, context) => {
      await updateInventorySettings(context, input)
    },
  )
}

export async function archiveInventoryItemAction(raw: unknown): Promise<ActionResult> {
  return runAction(
    z.object({ inventoryId: idSchema }),
    raw,
    { capability: 'inventory:manage', side: 'retailer' },
    async (input, context) => {
      await archiveInventoryItem(context, input.inventoryId)
    },
  )
}

export async function setCartQtyAction(raw: unknown): Promise<ActionResult> {
  return runAction(cartQtySchema, raw, { capability: 'orders:place', side: 'retailer' }, async (input, context) => {
    await setCartQty(context, input.productId, input.qty)
  })
}

/** One-tap reorder: selected items, or every low-stock item when no ids are given. */
export async function reorderToCartAction(raw: unknown): Promise<ActionResult<{ added: number; skipped: number }>> {
  return runAction(
    z.object({ inventoryIds: z.array(idSchema).max(500).nullable() }),
    raw,
    { capability: 'orders:place', side: 'retailer' },
    (input, context) => addInventoryToCart(context, input.inventoryIds ?? 'low-stock'),
  )
}
