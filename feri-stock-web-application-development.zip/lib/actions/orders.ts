'use server'

import { z } from 'zod'
import {
  acceptOrder,
  cancelOrder,
  confirmDelivery,
  dispatchOrder,
  markDelivered,
  markPacked,
  placeOrderFromCart,
  rejectOrder,
  submitDraftOrder,
} from '@/lib/domain/orders'
import {
  acceptOrderSchema,
  confirmDeliverySchema,
  dispatchSchema,
  idSchema,
  placeOrderSchema,
  reasonSchema,
} from '@/lib/validation'
import { runAction } from './safe'
import type { ActionResult } from './types'

const orderIdSchema = z.object({ orderId: idSchema })

export async function placeOrderAction(raw: unknown): Promise<ActionResult<{ orderId: string; orderNo: string }>> {
  return runAction(placeOrderSchema, raw, { capability: 'orders:place', side: 'retailer' }, (input, context) =>
    placeOrderFromCart(context, input),
  )
}

export async function submitDraftOrderAction(raw: unknown): Promise<ActionResult> {
  return runAction(orderIdSchema, raw, { capability: 'orders:place', side: 'retailer' }, async (input, context) => {
    await submitDraftOrder(context, input.orderId)
  })
}

// Either party may cancel, so the role check for the acting side happens in the domain layer.
export async function cancelOrderAction(raw: unknown): Promise<ActionResult> {
  return runAction(reasonSchema, raw, {}, async (input, context) => {
    await cancelOrder(context, input.orderId, input.reason)
  })
}

export async function acceptOrderAction(raw: unknown): Promise<ActionResult> {
  return runAction(acceptOrderSchema, raw, { capability: 'orders:manage', side: 'supplier' }, async (input, context) => {
    await acceptOrder(context, input)
  })
}

export async function rejectOrderAction(raw: unknown): Promise<ActionResult> {
  return runAction(reasonSchema, raw, { capability: 'orders:manage', side: 'supplier' }, async (input, context) => {
    await rejectOrder(context, input.orderId, input.reason)
  })
}

export async function markPackedAction(raw: unknown): Promise<ActionResult> {
  return runAction(orderIdSchema, raw, { capability: 'fulfilment:update', side: 'supplier' }, async (input, context) => {
    await markPacked(context, input.orderId)
  })
}

export async function dispatchOrderAction(raw: unknown): Promise<ActionResult> {
  return runAction(dispatchSchema, raw, { capability: 'fulfilment:update', side: 'supplier' }, async (input, context) => {
    await dispatchOrder(context, input)
  })
}

export async function markDeliveredAction(raw: unknown): Promise<ActionResult> {
  return runAction(orderIdSchema, raw, { capability: 'fulfilment:update', side: 'supplier' }, async (input, context) => {
    await markDelivered(context, input.orderId)
  })
}

export async function confirmDeliveryAction(raw: unknown): Promise<ActionResult> {
  return runAction(
    confirmDeliverySchema,
    raw,
    { capability: 'fulfilment:update', side: 'retailer' },
    async (input, context) => {
      await confirmDelivery(context, input)
    },
  )
}
