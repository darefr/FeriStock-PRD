'use server'

import { z } from 'zod'
import { requestOrigin } from '@/lib/app-url'
import {
  confirmPaymentProof,
  decideCredit,
  recheckGatewayPayment,
  recordReceivedPayment,
  rejectPaymentProof,
  requestCredit,
  startGatewayPayment,
  submitPaymentProof,
  type GatewayStart,
  type VerificationOutcome,
} from '@/lib/domain/payments'
import {
  cashPaymentSchema,
  creditDecisionSchema,
  gatewayPaymentSchema,
  idSchema,
  paymentProofSchema,
  rejectProofSchema,
} from '@/lib/validation'
import { runAction } from './safe'
import type { ActionResult } from './types'

const buyerPayments = { capability: 'payments:manage', side: 'retailer' } as const
const sellerPayments = { capability: 'payments:manage', side: 'supplier' } as const

/** Starts an eSewa or Khalti checkout against the supplier's own merchant account. */
export async function startGatewayPaymentAction(raw: unknown): Promise<ActionResult<GatewayStart>> {
  return runAction(gatewayPaymentSchema, raw, buyerPayments, async (input, context) =>
    startGatewayPayment(context, input, await requestOrigin()),
  )
}

/** Asks the gateway again whether a wallet payment went through. Either party may do this. */
export async function recheckPaymentAction(raw: unknown): Promise<ActionResult<{ outcome: VerificationOutcome }>> {
  return runAction(z.object({ paymentId: idSchema }), raw, {}, async (input, context) => ({
    outcome: await recheckGatewayPayment(context, input.paymentId),
  }))
}

export async function submitPaymentProofAction(raw: unknown): Promise<ActionResult> {
  return runAction(paymentProofSchema, raw, buyerPayments, async (input, context) => {
    await submitPaymentProof(context, input)
  })
}

export async function confirmPaymentProofAction(raw: unknown): Promise<ActionResult> {
  return runAction(z.object({ paymentId: idSchema }), raw, sellerPayments, async (input, context) => {
    await confirmPaymentProof(context, input.paymentId)
  })
}

export async function rejectPaymentProofAction(raw: unknown): Promise<ActionResult> {
  return runAction(rejectProofSchema, raw, sellerPayments, async (input, context) => {
    await rejectPaymentProof(context, input.paymentId, input.reason)
  })
}

export async function recordReceivedPaymentAction(raw: unknown): Promise<ActionResult> {
  return runAction(cashPaymentSchema, raw, sellerPayments, async (input, context) => {
    await recordReceivedPayment(context, input)
  })
}

export async function requestCreditAction(raw: unknown): Promise<ActionResult> {
  return runAction(z.object({ orderId: idSchema }), raw, buyerPayments, async (input, context) => {
    await requestCredit(context, input.orderId)
  })
}

export async function decideCreditAction(raw: unknown): Promise<ActionResult> {
  return runAction(creditDecisionSchema, raw, sellerPayments, async (input, context) => {
    await decideCredit(context, input)
  })
}
