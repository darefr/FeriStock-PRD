/** "K7QW9XMP4RTB" -> "K7QW-9XMP-4RTB" */
export function formatInviteCode(code: string): string {
  return code.replace(/(.{4})(?=.)/g, '$1-')
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function pluralize(count: number, singular: string, plural = `${singular}s`): string {
  return `${count} ${count === 1 ? singular : plural}`
}
