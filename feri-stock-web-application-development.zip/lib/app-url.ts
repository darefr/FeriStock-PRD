import 'server-only'
import { headers } from 'next/headers'
import { AppError } from './errors'

/**
 * The public origin the current request came in on, used to build gateway return URLs
 * so the buyer lands back on the same address they paid from.
 * Server Actions only run for requests whose Origin has already been checked by Next.js.
 */
export async function requestOrigin(): Promise<string> {
  const requestHeaders = await headers()
  const origin = requestHeaders.get('origin')
  if (origin && /^https?:\/\/[^/]+$/.test(origin)) return origin

  const host = requestHeaders.get('x-forwarded-host') ?? requestHeaders.get('host')
  if (!host) throw AppError.config('Could not work out the site address for the payment return link.')
  const protocol =
    requestHeaders.get('x-forwarded-proto')?.split(',')[0] ?? (host.startsWith('localhost') ? 'http' : 'https')
  return `${protocol}://${host}`
}
