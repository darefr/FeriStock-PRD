import 'server-only'
import { createCipheriv, createDecipheriv, createHmac, hkdfSync, randomBytes } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { devDataDir } from './dev-dir'
import { AppError } from './errors'

// Supplier gateway credentials are encrypted with AES-256-GCM before they are stored.
// The key comes from FERISTOCK_ENCRYPTION_KEY when set, otherwise it is derived from
// BETTER_AUTH_SECRET with HKDF so the two purposes never share key material directly.

const FORMAT_VERSION = 'v1'
const HKDF_SALT = 'feristock'
const HKDF_INFO = 'gateway-credentials:v1'

function deriveKey(material: string): Buffer {
  return Buffer.from(hkdfSync('sha256', material, HKDF_SALT, HKDF_INFO, 32))
}

function developmentKeyMaterial(create: boolean): string | null {
  if (process.env.NODE_ENV === 'production') return null
  const file = join(devDataDir(), 'encryption.key')
  if (existsSync(file)) return readFileSync(file, 'utf8').trim()
  if (!create) return null
  const material = randomBytes(48).toString('base64')
  writeFileSync(file, material, { mode: 0o600 })
  return material
}

/** Keys in priority order. The first encrypts; all are tried when decrypting, which keeps key rotation safe. */
function keyRing(forEncryption: boolean): Buffer[] {
  const materials: string[] = []
  if (process.env.FERISTOCK_ENCRYPTION_KEY) materials.push(process.env.FERISTOCK_ENCRYPTION_KEY)
  if (process.env.BETTER_AUTH_SECRET) materials.push(process.env.BETTER_AUTH_SECRET)
  const development = developmentKeyMaterial(forEncryption && materials.length === 0)
  if (development) materials.push(development)
  return materials.map(deriveKey)
}

export function encryptSecret(plaintext: string): string {
  const [key] = keyRing(true)
  if (!key) {
    throw AppError.config(
      'Credential encryption is not configured. Set BETTER_AUTH_SECRET (or FERISTOCK_ENCRYPTION_KEY) and try again.',
    )
  }
  const iv = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, iv)
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  return [FORMAT_VERSION, iv.toString('base64'), cipher.getAuthTag().toString('base64'), ciphertext.toString('base64')].join(
    ':',
  )
}

/** Returns null when the value cannot be decrypted with any configured key. */
export function decryptSecret(encrypted: string): string | null {
  const [version, iv, tag, ciphertext] = encrypted.split(':')
  if (version !== FORMAT_VERSION || !iv || !tag || !ciphertext) return null
  for (const key of keyRing(false)) {
    try {
      const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(iv, 'base64'))
      decipher.setAuthTag(Buffer.from(tag, 'base64'))
      return Buffer.concat([decipher.update(Buffer.from(ciphertext, 'base64')), decipher.final()]).toString('utf8')
    } catch {
      // Wrong key for this value; try the next one.
    }
  }
  return null
}

export function hmacSha256Base64(secret: string, message: string): string {
  return createHmac('sha256', secret).update(message, 'utf8').digest('base64')
}

const INVITE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

/** A single-use 12-character code (60 bits) without look-alike characters; shown as "K7QW-9XMP-4RTB". */
export function generateInviteCode(): string {
  return Array.from(randomBytes(12), (byte) => INVITE_ALPHABET[byte % INVITE_ALPHABET.length]).join('')
}

/** A short random hex suffix that is safe for gateway references (alphanumeric only). */
export function randomToken(bytes = 6): string {
  return randomBytes(bytes).toString('hex')
}
