import type { MemberRole } from './constants'

export type Capability =
  /** Edit the organization profile and supplier terms. */
  | 'org:manage'
  /** Invite, re-role and remove members. */
  | 'team:manage'
  /** View and change gateway credentials, QR and bank details. */
  | 'payments:configure'
  /** Create and edit catalog products and pricing. */
  | 'catalog:manage'
  /** Add and configure tracked inventory items. */
  | 'inventory:manage'
  /** Use the cart, place purchase orders, schedules and quote requests. */
  | 'orders:place'
  /** Accept, adjust, reject or cancel incoming orders; answer quote requests. */
  | 'orders:manage'
  /** Pay suppliers, confirm received payments, approve or settle credit. */
  | 'payments:manage'
  /** Count stock up and down. */
  | 'stock:update'
  /** Pack and dispatch orders; confirm deliveries. */
  | 'fulfilment:update'

const OPERATIONS: Capability[] = [
  'catalog:manage',
  'inventory:manage',
  'orders:place',
  'orders:manage',
  'payments:manage',
  'stock:update',
  'fulfilment:update',
]

const MATRIX: Record<MemberRole, ReadonlySet<Capability>> = {
  owner: new Set<Capability>(['org:manage', 'team:manage', 'payments:configure', ...OPERATIONS]),
  manager: new Set<Capability>(OPERATIONS),
  staff: new Set<Capability>(['stock:update', 'fulfilment:update']),
}

export function can(role: MemberRole, capability: Capability): boolean {
  return MATRIX[role].has(capability)
}

export function capabilitiesFor(role: MemberRole): Capability[] {
  return [...MATRIX[role]]
}
