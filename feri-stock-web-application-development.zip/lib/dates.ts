// Nepal Time is UTC+05:45 year-round (no daylight saving), so a fixed offset is exact.
// Formatting is done by hand so server and browser output always match.

const NPT_OFFSET_MS = (5 * 60 + 45) * 60 * 1000
const DAY_MS = 24 * 60 * 60 * 1000
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

export type NptParts = {
  year: number
  month: number
  day: number
  hour: number
  minute: number
  weekday: number
}

export function nptParts(instant: Date): NptParts {
  const shifted = new Date(instant.getTime() + NPT_OFFSET_MS)
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    weekday: shifted.getUTCDay(),
  }
}

/** The UTC instant for a wall-clock time in Nepal. */
export function nptToInstant(year: number, month: number, day: number, hour = 0, minute = 0): Date {
  return new Date(Date.UTC(year, month - 1, day, hour, minute) - NPT_OFFSET_MS)
}

const pad = (value: number) => String(value).padStart(2, '0')

/** Today's calendar date in Nepal as YYYY-MM-DD. */
export function todayNpt(now: Date = new Date()): string {
  const { year, month, day } = nptParts(now)
  return `${year}-${pad(month)}-${pad(day)}`
}

export function isDateString(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const [year, month, day] = value.split('-').map(Number)
  const date = new Date(Date.UTC(year, month - 1, day))
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day
}

export function addDays(dateString: string, days: number): string {
  const [year, month, day] = dateString.split('-').map(Number)
  const date = new Date(Date.UTC(year, month - 1, day) + days * DAY_MS)
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())}`
}

/** Whole days from `from` to `to` (positive when `to` is later). */
export function daysBetween(from: string, to: string): number {
  const parse = (value: string) => {
    const [year, month, day] = value.split('-').map(Number)
    return Date.UTC(year, month - 1, day)
  }
  return Math.round((parse(to) - parse(from)) / DAY_MS)
}

/** "21 Nov 2026" for a YYYY-MM-DD calendar date. */
export function formatDateString(dateString: string): string {
  const [year, month, day] = dateString.split('-').map(Number)
  return `${day} ${MONTHS[month - 1]} ${year}`
}

/** "21 Nov 2026" for an instant, in Nepal time. */
export function formatDate(instant: Date | string): string {
  const { year, month, day } = nptParts(new Date(instant))
  return `${day} ${MONTHS[month - 1]} ${year}`
}

/** "3:45 PM" for an instant, in Nepal time. */
export function formatTime(instant: Date | string): string {
  const { hour, minute } = nptParts(new Date(instant))
  const period = hour >= 12 ? 'PM' : 'AM'
  return `${hour % 12 === 0 ? 12 : hour % 12}:${pad(minute)} ${period}`
}

/** "21 Nov 2026, 3:45 PM" for an instant, in Nepal time. */
export function formatDateTime(instant: Date | string): string {
  return `${formatDate(instant)}, ${formatTime(instant)}`
}

/** "21 Nov, 3:45 PM" — compact form for lists. */
export function formatShortDateTime(instant: Date | string): string {
  const { month, day } = nptParts(new Date(instant))
  return `${day} ${MONTHS[month - 1]}, ${formatTime(instant)}`
}

/** "3:45 PM" from a stored "HH:MM" 24-hour value. */
export function formatTimeOfDay(value: string): string {
  const [hour, minute] = value.split(':').map(Number)
  const period = hour >= 12 ? 'PM' : 'AM'
  return `${hour % 12 === 0 ? 12 : hour % 12}:${pad(minute)} ${period}`
}

export function isTimeOfDay(value: string): boolean {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(value)
}
