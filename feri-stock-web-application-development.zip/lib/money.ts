export type BulkTier = { minQty: number; pricePaisa: number }

/** Nepali/Indian digit grouping: 1250000 -> "12,50,000". */
export function groupIndian(digits: string): string {
  if (digits.length <= 3) return digits
  const head = digits.slice(0, -3)
  const tail = digits.slice(-3)
  return `${head.replace(/\B(?=(\d{2})+(?!\d))/g, ',')},${tail}`
}

export function formatAmount(paisa: number, options: { decimals?: 'auto' | 'always' } = {}): string {
  const rounded = Math.round(paisa)
  const abs = Math.abs(rounded)
  const rupees = Math.floor(abs / 100)
  const fraction = abs % 100
  const showFraction = options.decimals === 'always' || fraction !== 0
  const body = groupIndian(String(rupees)) + (showFraction ? `.${String(fraction).padStart(2, '0')}` : '')
  return rounded < 0 ? `-${body}` : body
}

export function formatNpr(paisa: number, options: { decimals?: 'auto' | 'always' } = {}): string {
  return `Rs. ${formatAmount(paisa, options)}`
}

/** Parses a rupee amount typed by a user ("1,250.50") into paisa. Returns null when invalid. */
export function parseRupees(input: string): number | null {
  const cleaned = input.replace(/[,\s]/g, '')
  if (!/^\d{1,11}(\.\d{1,2})?$/.test(cleaned)) return null
  const [rupees, fraction = ''] = cleaned.split('.')
  return Number(rupees) * 100 + Number(fraction.padEnd(2, '0'))
}

/** Plain decimal string for form inputs and gateway payloads: 125050 -> "1250.50", 125000 -> "1250". */
export function paisaToRupeeString(paisa: number): string {
  const rupees = Math.floor(paisa / 100)
  const fraction = paisa % 100
  return fraction === 0 ? String(rupees) : `${rupees}.${String(fraction).padStart(2, '0')}`
}

export function sortTiers(tiers: BulkTier[]): BulkTier[] {
  return [...tiers].sort((a, b) => a.minQty - b.minQty)
}

/** Unit price for a quantity: the highest tier whose minimum is met, otherwise the base price. */
export function unitPriceForQty(basePaisa: number, tiers: BulkTier[] | null | undefined, qty: number): number {
  let price = basePaisa
  for (const tier of sortTiers(tiers ?? [])) {
    if (qty >= tier.minQty) price = tier.pricePaisa
  }
  return price
}

/** The next tier a buyer could unlock by ordering more, if any. */
export function nextTier(tiers: BulkTier[] | null | undefined, qty: number): BulkTier | null {
  return sortTiers(tiers ?? []).find((tier) => tier.minQty > qty) ?? null
}

export function lineTotal(unitPricePaisa: number, qty: number): number {
  return unitPricePaisa * qty
}
