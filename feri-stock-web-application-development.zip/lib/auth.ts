import 'server-only'
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { db } from '@/lib/db'
import { account, rateLimit, session, user, verification } from '@/lib/db/schema'

const isDevelopment = process.env.NODE_ENV === 'development'

const configuredOrigins = [
  ...(isDevelopment
    ? [
        'http://localhost:3000',
        ...(process.env.V0_RUNTIME_URL ? [process.env.V0_RUNTIME_URL] : []),
        ...(process.env.V0_DEV_APP_URL ? [process.env.V0_DEV_APP_URL] : []),
        ...(process.env.V0_BUILD_URL ? [process.env.V0_BUILD_URL] : []),
        ...(process.env.V0_SANDBOX_URL ? [process.env.V0_SANDBOX_URL] : []),
      ]
    : []),
  ...(process.env.NODE_ENV === 'production'
    ? [
        ...(process.env.VERCEL_URL ? [`https://${process.env.VERCEL_URL}`] : []),
        ...(process.env.VERCEL_PROJECT_PRODUCTION_URL
          ? [`https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`]
          : []),
      ]
    : []),
]

const PREVIEW_HOST = /^[a-z0-9-]+(\.[a-z0-9-]+)*\.(vercel\.run|vusercontent\.net|v0\.build)$/

/**
 * The v0 preview is served from its own hostnames, which are not always provided as V0_* variables.
 * In development, the exact address a request was sent to is therefore trusted as well. It comes
 * from the proxy's host headers, never from the Origin header, and only when it is a v0 preview
 * hostname, so a page on any other origin (including another preview) still fails the origin check.
 */
function previewOrigin(request: Request | undefined): string | null {
  if (!isDevelopment || !request) return null
  const forwarded = request.headers.get('x-forwarded-host') ?? request.headers.get('host') ?? ''
  const host = forwarded.split(',')[0].trim().toLowerCase()
  return PREVIEW_HOST.test(host) ? `https://${host}` : null
}

export const auth = betterAuth({
  database: drizzleAdapter(db, {
    provider: 'pg',
    schema: { user, session, account, verification, rateLimit },
  }),
  baseURL:
    process.env.BETTER_AUTH_URL ??
    (process.env.VERCEL_PROJECT_PRODUCTION_URL
      ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
      : process.env.VERCEL_URL
        ? `https://${process.env.VERCEL_URL}`
        : process.env.V0_RUNTIME_URL),
  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
    minPasswordLength: 8,
    maxPasswordLength: 128,
  },
  trustedOrigins: (request) => {
    const preview = previewOrigin(request)
    return preview ? [...configuredOrigins, preview] : configuredOrigins
  },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // 1 day
  },
  // Stored in Postgres so sign-in throttling holds across serverless instances.
  rateLimit: {
    storage: 'database',
  },
  ...(isDevelopment
    ? {
        advanced: {
          // Required by the cross-site v0 preview iframe. Without these
          // attributes, login succeeds but the next request appears signed out.
          defaultCookieAttributes: {
            sameSite: 'none' as const,
            secure: true,
          },
        },
      }
    : {}),
})
