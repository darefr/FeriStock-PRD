export type AppErrorCode = 'unauthenticated' | 'forbidden' | 'not_found' | 'invalid' | 'conflict' | 'config' | 'gateway'

/**
 * An expected failure whose message is safe to show to the user.
 * Anything else thrown on the server is logged and replaced with a generic message.
 */
export class AppError extends Error {
  readonly code: AppErrorCode

  constructor(code: AppErrorCode, message: string) {
    super(message)
    this.name = 'AppError'
    this.code = code
  }

  get status(): number {
    switch (this.code) {
      case 'unauthenticated':
        return 401
      case 'forbidden':
        return 403
      case 'not_found':
        return 404
      case 'conflict':
        return 409
      case 'config':
        return 503
      case 'gateway':
        return 502
      default:
        return 400
    }
  }

  static unauthenticated(message = 'Please log in to continue.') {
    return new AppError('unauthenticated', message)
  }
  static forbidden(message = 'You do not have permission to do that.') {
    return new AppError('forbidden', message)
  }
  static notFound(message = 'Not found.') {
    return new AppError('not_found', message)
  }
  static invalid(message: string) {
    return new AppError('invalid', message)
  }
  static conflict(message: string) {
    return new AppError('conflict', message)
  }
  static config(message: string) {
    return new AppError('config', message)
  }
  static gateway(message: string) {
    return new AppError('gateway', message)
  }
}

/** Postgres SQLSTATE of a driver error, looking through Drizzle's query-error wrapper. */
export function pgErrorCode(error: unknown): string | undefined {
  let current: unknown = error
  for (let depth = 0; depth < 4 && current && typeof current === 'object'; depth++) {
    const code = (current as { code?: unknown }).code
    if (typeof code === 'string' && /^[0-9A-Z]{5}$/.test(code)) return code
    current = (current as { cause?: unknown }).cause
  }
  return undefined
}

export const isUniqueViolation = (error: unknown) => pgErrorCode(error) === '23505'
