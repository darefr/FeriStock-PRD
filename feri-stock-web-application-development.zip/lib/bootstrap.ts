import 'server-only'
import { databaseReady } from './db'

const globalStore = globalThis as unknown as { __feristockBoot?: Promise<void> }

async function boot(): Promise<void> {
  await databaseReady()
}

/** Resolves once the app can serve requests. Cheap to await: the work happens once per server process. */
export function appReady(): Promise<void> {
  globalStore.__feristockBoot ??= boot().catch((error) => {
    globalStore.__feristockBoot = undefined
    throw error
  })
  return globalStore.__feristockBoot
}
