import 'server-only'
import { AppError } from './errors'

const NO_STORE = { 'Cache-Control': 'private, no-store' }

/** JSON for authenticated reads; never cached by browsers or proxies. */
export function json(data: unknown, init: { status?: number } = {}): Response {
  return Response.json(data, { status: init.status ?? 200, headers: NO_STORE })
}

export function apiError(error: unknown): Response {
  if (error instanceof AppError) {
    return Response.json({ error: error.message }, { status: error.status, headers: NO_STORE })
  }
  console.error('[api] unexpected error', error)
  return Response.json({ error: 'Something went wrong. Please try again.' }, { status: 500, headers: NO_STORE })
}

/** A relative redirect, so the browser stays on whichever public address it used to reach the app. */
export function redirectTo(path: string): Response {
  return new Response(null, { status: 303, headers: { Location: path, ...NO_STORE } })
}
