import { sql } from 'drizzle-orm'
import {
  bigint,
  boolean,
  check,
  customType,
  date,
  index,
  integer,
  jsonb,
  pgEnum,
  pgSequence,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from 'drizzle-orm/pg-core'
import {
  CREDIT_STATES,
  DELIVERY_MODES,
  type DeliveryMode,
  FILE_KINDS,
  GATEWAY_ENVS,
  MEMBER_ROLES,
  ORDER_STATUSES,
  ORDER_TYPES,
  ORG_ROLES,
  PAYMENT_METHODS,
  PAYMENT_RECORD_STATUSES,
  PAYMENT_STATUSES,
  QUOTE_STATUSES,
  RECEIPT_KINDS,
  SCHEDULE_FREQUENCIES,
  SCHEDULE_MODES,
  STOCK_REASONS,
} from '../../constants'
import type { BulkTier } from '../../money'
import { user } from './auth'

const timestamptz = (name: string) => timestamp(name, { withTimezone: true, mode: 'date' })
const paisa = (name: string) => bigint(name, { mode: 'number' })
const createdAt = () => timestamptz('created_at').notNull().defaultNow()
const updatedAt = () =>
  timestamptz('updated_at')
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date())

const bytea = customType<{ data: Buffer; driverData: Uint8Array }>({
  dataType: () => 'bytea',
  toDriver: (value) => value,
  fromDriver: (value) => Buffer.from(value),
})

export const orgRoleEnum = pgEnum('org_role', ORG_ROLES)
export const memberRoleEnum = pgEnum('member_role', MEMBER_ROLES)
export const orderTypeEnum = pgEnum('order_type', ORDER_TYPES)
export const orderStatusEnum = pgEnum('order_status', ORDER_STATUSES)
export const paymentStatusEnum = pgEnum('payment_status', PAYMENT_STATUSES)
export const creditStateEnum = pgEnum('credit_state', CREDIT_STATES)
export const deliveryModeEnum = pgEnum('delivery_mode', DELIVERY_MODES)
export const paymentMethodEnum = pgEnum('payment_method', PAYMENT_METHODS)
export const paymentRecordStatusEnum = pgEnum('payment_record_status', PAYMENT_RECORD_STATUSES)
export const gatewayEnvEnum = pgEnum('gateway_env', GATEWAY_ENVS)
export const stockReasonEnum = pgEnum('stock_reason', STOCK_REASONS)
export const scheduleFrequencyEnum = pgEnum('schedule_frequency', SCHEDULE_FREQUENCIES)
export const scheduleModeEnum = pgEnum('schedule_mode', SCHEDULE_MODES)
export const quoteStatusEnum = pgEnum('quote_status', QUOTE_STATUSES)
export const fileKindEnum = pgEnum('file_kind', FILE_KINDS)
export const receiptKindEnum = pgEnum('receipt_kind', RECEIPT_KINDS)

export const orderNoSeq = pgSequence('order_no_seq', { startWith: 1001 })
export const receiptNoSeq = pgSequence('receipt_no_seq', { startWith: 1001 })
export const quoteNoSeq = pgSequence('quote_no_seq', { startWith: 1001 })

// ---------------------------------------------------------------------------
// Organizations & access
// ---------------------------------------------------------------------------

export const organizations = pgTable('organizations', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  role: orgRoleEnum('role').notNull(),
  panVatNo: text('pan_vat_no').notNull(),
  city: text('city').notNull(),
  address: text('address').notNull(),
  phone: text('phone').notNull(),
  email: text('email'),
  createdAt: createdAt(),
  updatedAt: updatedAt(),
})

export const memberships = pgTable(
  'memberships',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orgId: uuid('org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    userId: text('user_id')
      .notNull()
      .references(() => user.id, { onDelete: 'cascade' }),
    role: memberRoleEnum('role').notNull(),
    createdAt: createdAt(),
  },
  (table) => [
    // A user belongs to exactly one organization; a dual-role organization covers buying and selling.
    uniqueIndex('memberships_user_id_key').on(table.userId),
    index('memberships_org_id_idx').on(table.orgId),
  ],
)

export const invites = pgTable(
  'invites',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orgId: uuid('org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    code: text('code').notNull(),
    role: memberRoleEnum('role').notNull(),
    createdBy: text('created_by')
      .notNull()
      .references(() => user.id),
    expiresAt: timestamptz('expires_at').notNull(),
    usedBy: text('used_by').references(() => user.id),
    usedAt: timestamptz('used_at'),
    revokedAt: timestamptz('revoked_at'),
    createdAt: createdAt(),
  },
  (table) => [uniqueIndex('invites_code_key').on(table.code), index('invites_org_id_idx').on(table.orgId)],
)

// ---------------------------------------------------------------------------
// Supplier configuration
// ---------------------------------------------------------------------------

export const supplierSettings = pgTable(
  'supplier_settings',
  {
    orgId: uuid('org_id')
      .primaryKey()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    deliveryModes: jsonb('delivery_modes').$type<DeliveryMode[]>().notNull().default(['own_van', 'bilti', 'pickup']),
    deliveryNote: text('delivery_note').notNull().default(''),
    creditEnabled: boolean('credit_enabled').notNull().default(false),
    creditDays: integer('credit_days').notNull().default(15),
    minOrderPaisa: paisa('min_order_paisa').notNull().default(0),
    updatedAt: updatedAt(),
  },
  (table) => [
    check('supplier_settings_credit_days_range', sql`${table.creditDays} between 1 and 180`),
    check('supplier_settings_min_order_nonneg', sql`${table.minOrderPaisa} >= 0`),
  ],
)

export type BankDetails = {
  bankName: string
  accountName: string
  accountNumber: string
  branch: string
}

export const supplierPaymentConfigs = pgTable('supplier_payment_configs', {
  orgId: uuid('org_id')
    .primaryKey()
    .references(() => organizations.id, { onDelete: 'cascade' }),
  esewaEnabled: boolean('esewa_enabled').notNull().default(false),
  esewaMerchantId: text('esewa_merchant_id'),
  // Gateway secrets are AES-256-GCM encrypted before they reach the database.
  esewaSecretEnc: text('esewa_secret_enc'),
  esewaEnv: gatewayEnvEnum('esewa_env').notNull().default('test'),
  khaltiEnabled: boolean('khalti_enabled').notNull().default(false),
  khaltiSecretEnc: text('khalti_secret_enc'),
  khaltiEnv: gatewayEnvEnum('khalti_env').notNull().default('test'),
  qrFileId: uuid('qr_file_id'),
  bankDetailsJson: jsonb('bank_details_json').$type<BankDetails>(),
  updatedAt: updatedAt(),
})

export const products = pgTable(
  'products',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    supplierOrgId: uuid('supplier_org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    sku: text('sku').notNull(),
    name: text('name').notNull(),
    unit: text('unit').notNull(),
    category: text('category'),
    pricePaisa: paisa('price_paisa').notNull(),
    bulkTiersJson: jsonb('bulk_tiers_json').$type<BulkTier[]>().notNull().default([]),
    schemeNote: text('scheme_note'),
    moq: integer('moq').notNull().default(1),
    isActive: boolean('is_active').notNull().default(true),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex('products_supplier_sku_key').on(table.supplierOrgId, table.sku),
    index('products_supplier_idx').on(table.supplierOrgId),
    check('products_price_nonneg', sql`${table.pricePaisa} >= 0`),
    check('products_moq_positive', sql`${table.moq} >= 1`),
  ],
)

// ---------------------------------------------------------------------------
// Retailer inventory
// ---------------------------------------------------------------------------

export const retailerInventory = pgTable(
  'retailer_inventory',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    // Null for items the shop tracks that no supplier lists yet; those are restocked through quote requests.
    productId: uuid('product_id').references(() => products.id),
    customName: text('custom_name'),
    customUnit: text('custom_unit'),
    currentQty: integer('current_qty').notNull().default(0),
    reorderThreshold: integer('reorder_threshold').notNull().default(0),
    reorderQty: integer('reorder_qty'),
    autoReorder: boolean('auto_reorder').notNull().default(true),
    alertsEnabled: boolean('alerts_enabled').notNull().default(true),
    preferredSupplierId: uuid('preferred_supplier_id').references(() => organizations.id),
    archivedAt: timestamptz('archived_at'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex('retailer_inventory_org_product_key').on(table.retailerOrgId, table.productId),
    index('retailer_inventory_org_idx').on(table.retailerOrgId),
    check('retailer_inventory_qty_nonneg', sql`${table.currentQty} >= 0`),
    check('retailer_inventory_threshold_nonneg', sql`${table.reorderThreshold} >= 0`),
    check('retailer_inventory_identity', sql`${table.productId} is not null or ${table.customName} is not null`),
  ],
)

export const stockMovements = pgTable(
  'stock_movements',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    inventoryId: uuid('inventory_id')
      .notNull()
      .references(() => retailerInventory.id),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id),
    delta: integer('delta').notNull(),
    qtyAfter: integer('qty_after').notNull(),
    reason: stockReasonEnum('reason').notNull(),
    orderId: uuid('order_id'),
    userId: text('user_id').references(() => user.id),
    createdAt: createdAt(),
  },
  (table) => [index('stock_movements_inventory_idx').on(table.inventoryId, table.createdAt)],
)

export const cartItems = pgTable(
  'cart_items',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    productId: uuid('product_id')
      .notNull()
      .references(() => products.id, { onDelete: 'cascade' }),
    qty: integer('qty').notNull(),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex('cart_items_org_product_key').on(table.retailerOrgId, table.productId),
    check('cart_items_qty_positive', sql`${table.qty} >= 1`),
  ],
)

// ---------------------------------------------------------------------------
// Orders, fulfilment & payments
// ---------------------------------------------------------------------------

export const orders = pgTable(
  'orders',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orderNo: text('order_no')
      .notNull()
      .default(sql`'PO-' || lpad(nextval('order_no_seq')::text, 6, '0')`),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id),
    supplierOrgId: uuid('supplier_org_id')
      .notNull()
      .references(() => organizations.id),
    orderType: orderTypeEnum('order_type').notNull(),
    status: orderStatusEnum('status').notNull(),
    totalPaisa: paisa('total_paisa').notNull(),
    paidPaisa: paisa('paid_paisa').notNull().default(0),
    paymentStatus: paymentStatusEnum('payment_status').notNull().default('unpaid'),
    creditState: creditStateEnum('credit_state').notNull().default('none'),
    dueDate: date('due_date', { mode: 'string' }),
    retailerNote: text('retailer_note'),
    supplierNote: text('supplier_note'),
    cancelReason: text('cancel_reason'),
    scheduleId: uuid('schedule_id'),
    quoteId: uuid('quote_id'),
    placedBy: text('placed_by').references(() => user.id),
    placedAt: timestamptz('placed_at'),
    acceptedAt: timestamptz('accepted_at'),
    packedAt: timestamptz('packed_at'),
    dispatchedAt: timestamptz('dispatched_at'),
    deliveredAt: timestamptz('delivered_at'),
    stockSyncedAt: timestamptz('stock_synced_at'),
    closedAt: timestamptz('closed_at'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex('orders_order_no_key').on(table.orderNo),
    index('orders_retailer_idx').on(table.retailerOrgId, table.createdAt),
    index('orders_supplier_idx').on(table.supplierOrgId, table.status),
    check('orders_total_nonneg', sql`${table.totalPaisa} >= 0`),
    check('orders_paid_nonneg', sql`${table.paidPaisa} >= 0`),
    check('orders_distinct_parties', sql`${table.retailerOrgId} <> ${table.supplierOrgId}`),
  ],
)

export const orderItems = pgTable(
  'order_items',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orderId: uuid('order_id')
      .notNull()
      .references(() => orders.id, { onDelete: 'cascade' }),
    productId: uuid('product_id').references(() => products.id),
    // Name, unit and price are copied at order time so later catalog edits never rewrite history.
    sku: text('sku'),
    name: text('name').notNull(),
    unit: text('unit').notNull(),
    requestedQty: integer('requested_qty').notNull(),
    qty: integer('qty').notNull(),
    unitPricePaisa: paisa('unit_price_paisa').notNull(),
    lineTotalPaisa: paisa('line_total_paisa').notNull(),
    receivedQty: integer('received_qty'),
    position: integer('position').notNull().default(0),
  },
  (table) => [
    index('order_items_order_idx').on(table.orderId),
    check('order_items_qty_nonneg', sql`${table.qty} >= 0`),
    check('order_items_price_nonneg', sql`${table.unitPricePaisa} >= 0`),
  ],
)

export type OrderEventMeta = Record<string, string | number | boolean | null>

export const orderEvents = pgTable(
  'order_events',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orderId: uuid('order_id')
      .notNull()
      .references(() => orders.id),
    type: text('type').notNull(),
    message: text('message').notNull(),
    meta: jsonb('meta').$type<OrderEventMeta>(),
    actorUserId: text('actor_user_id').references(() => user.id),
    actorOrgId: uuid('actor_org_id').references(() => organizations.id),
    actorName: text('actor_name'),
    createdAt: createdAt(),
  },
  (table) => [index('order_events_order_idx').on(table.orderId, table.createdAt)],
)

export const shipments = pgTable(
  'shipments',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orderId: uuid('order_id')
      .notNull()
      .references(() => orders.id),
    deliveryMode: deliveryModeEnum('delivery_mode').notNull(),
    carrierOrVan: text('carrier_or_van'),
    driverName: text('driver_name'),
    driverPhone: text('driver_phone'),
    biltiRef: text('bilti_ref'),
    biltiPhotoFileId: uuid('bilti_photo_file_id'),
    note: text('note'),
    dispatchedAt: timestamptz('dispatched_at').notNull(),
    deliveredAt: timestamptz('delivered_at'),
    createdAt: createdAt(),
  },
  (table) => [uniqueIndex('shipments_order_key').on(table.orderId)],
)

export const paymentRecords = pgTable(
  'payment_records',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orderId: uuid('order_id')
      .notNull()
      .references(() => orders.id),
    method: paymentMethodEnum('method').notNull(),
    // Our reference sent to the gateway: eSewa transaction_uuid or Khalti pidx.
    gatewayTxnId: text('gateway_txn_id'),
    gatewayEnv: gatewayEnvEnum('gateway_env'),
    // The reference the money can be traced by: gateway transaction code, bank reference or cheque number.
    transactionRef: text('transaction_ref'),
    amountPaisa: paisa('amount_paisa').notNull(),
    status: paymentRecordStatusEnum('status').notNull(),
    proofFileId: uuid('proof_file_id'),
    note: text('note'),
    rejectReason: text('reject_reason'),
    rawResponse: jsonb('raw_response').$type<Record<string, unknown>>(),
    receiptUrl: text('receipt_url'),
    createdBy: text('created_by').references(() => user.id),
    verifiedBy: text('verified_by').references(() => user.id),
    paidAt: timestamptz('paid_at'),
    verifiedAt: timestamptz('verified_at'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    index('payment_records_order_idx').on(table.orderId),
    uniqueIndex('payment_records_gateway_txn_key').on(table.method, table.gatewayTxnId),
    check('payment_records_amount_positive', sql`${table.amountPaisa} > 0`),
  ],
)

export type ReceiptParty = {
  name: string
  panVatNo: string
  address: string
  city: string
  phone: string
}

export type ReceiptSnapshot = {
  version: 1
  kind: 'order' | 'payment'
  order: {
    orderNo: string
    orderType: string
    placedAt: string | null
    acceptedAt: string | null
    dueDate: string | null
    creditApproved: boolean
  }
  supplier: ReceiptParty
  buyer: ReceiptParty
  items: Array<{
    sku: string | null
    name: string
    unit: string
    qty: number
    unitPricePaisa: number
    lineTotalPaisa: number
  }>
  totals: {
    totalPaisa: number
    paidToDatePaisa: number
    balancePaisa: number
  }
  payment: null | {
    method: string
    transactionRef: string | null
    gatewayTxnId: string | null
    gatewayEnv: string | null
    amountPaisa: number
    paidAt: string
  }
}

export const receipts = pgTable(
  'receipts',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    receiptNo: text('receipt_no')
      .notNull()
      .default(sql`'RC-' || lpad(nextval('receipt_no_seq')::text, 6, '0')`),
    orderId: uuid('order_id')
      .notNull()
      .references(() => orders.id),
    paymentRecordId: uuid('payment_record_id').references(() => paymentRecords.id),
    kind: receiptKindEnum('kind').notNull(),
    // A frozen copy of everything printed on the receipt, so it never changes after issue.
    snapshot: jsonb('snapshot').$type<ReceiptSnapshot>().notNull(),
    issuedAt: timestamptz('issued_at').notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex('receipts_receipt_no_key').on(table.receiptNo),
    uniqueIndex('receipts_payment_record_key').on(table.paymentRecordId),
    uniqueIndex('receipts_order_confirmation_key')
      .on(table.orderId)
      .where(sql`${table.kind} = 'order'`),
    index('receipts_order_idx').on(table.orderId),
  ],
)

// ---------------------------------------------------------------------------
// Recurring restock schedules
// ---------------------------------------------------------------------------

export const recurringSchedules = pgTable(
  'recurring_schedules',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    supplierOrgId: uuid('supplier_org_id')
      .notNull()
      .references(() => organizations.id),
    name: text('name').notNull(),
    frequency: scheduleFrequencyEnum('frequency').notNull(),
    dayOfWeek: integer('day_of_week'),
    dayOfMonth: integer('day_of_month'),
    timeOfDay: text('time_of_day').notNull(),
    mode: scheduleModeEnum('mode').notNull().default('draft'),
    isActive: boolean('is_active').notNull().default(true),
    nextRunAt: timestamptz('next_run_at').notNull(),
    lastRunAt: timestamptz('last_run_at'),
    lastOrderId: uuid('last_order_id'),
    createdBy: text('created_by').references(() => user.id),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    index('recurring_schedules_org_idx').on(table.retailerOrgId),
    index('recurring_schedules_due_idx').on(table.nextRunAt),
    check('recurring_schedules_dow_range', sql`${table.dayOfWeek} is null or ${table.dayOfWeek} between 0 and 6`),
    check('recurring_schedules_dom_range', sql`${table.dayOfMonth} is null or ${table.dayOfMonth} between 1 and 28`),
  ],
)

export const recurringScheduleItems = pgTable(
  'recurring_schedule_items',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    scheduleId: uuid('schedule_id')
      .notNull()
      .references(() => recurringSchedules.id, { onDelete: 'cascade' }),
    productId: uuid('product_id')
      .notNull()
      .references(() => products.id),
    qty: integer('qty').notNull(),
  },
  (table) => [
    uniqueIndex('recurring_schedule_items_key').on(table.scheduleId, table.productId),
    check('recurring_schedule_items_qty_positive', sql`${table.qty} >= 1`),
  ],
)

// ---------------------------------------------------------------------------
// Custom orders / quote requests
// ---------------------------------------------------------------------------

export const quoteRequests = pgTable(
  'quote_requests',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    quoteNo: text('quote_no')
      .notNull()
      .default(sql`'QT-' || lpad(nextval('quote_no_seq')::text, 6, '0')`),
    retailerOrgId: uuid('retailer_org_id')
      .notNull()
      .references(() => organizations.id),
    supplierOrgId: uuid('supplier_org_id')
      .notNull()
      .references(() => organizations.id),
    status: quoteStatusEnum('status').notNull().default('requested'),
    retailerNote: text('retailer_note'),
    supplierNote: text('supplier_note'),
    validUntil: date('valid_until', { mode: 'string' }),
    orderId: uuid('order_id'),
    requestedBy: text('requested_by').references(() => user.id),
    respondedAt: timestamptz('responded_at'),
    decidedAt: timestamptz('decided_at'),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    uniqueIndex('quote_requests_quote_no_key').on(table.quoteNo),
    index('quote_requests_retailer_idx').on(table.retailerOrgId, table.createdAt),
    index('quote_requests_supplier_idx').on(table.supplierOrgId, table.status),
    check('quote_requests_distinct_parties', sql`${table.retailerOrgId} <> ${table.supplierOrgId}`),
  ],
)

export const quoteItems = pgTable(
  'quote_items',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    quoteId: uuid('quote_id')
      .notNull()
      .references(() => quoteRequests.id, { onDelete: 'cascade' }),
    productId: uuid('product_id').references(() => products.id),
    name: text('name').notNull(),
    unit: text('unit').notNull(),
    qty: integer('qty').notNull(),
    targetPricePaisa: paisa('target_price_paisa'),
    quotedQty: integer('quoted_qty'),
    quotedPricePaisa: paisa('quoted_price_paisa'),
    position: integer('position').notNull().default(0),
  },
  (table) => [index('quote_items_quote_idx').on(table.quoteId), check('quote_items_qty_positive', sql`${table.qty} >= 1`)],
)

// ---------------------------------------------------------------------------
// Private uploads (bilti photos, payment proofs, QR images)
// ---------------------------------------------------------------------------

export const files = pgTable(
  'files',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    orgId: uuid('org_id')
      .notNull()
      .references(() => organizations.id, { onDelete: 'cascade' }),
    kind: fileKindEnum('kind').notNull(),
    orderId: uuid('order_id').references(() => orders.id),
    contentType: text('content_type').notNull(),
    sizeBytes: integer('size_bytes').notNull(),
    data: bytea('data').notNull(),
    createdBy: text('created_by').references(() => user.id),
    createdAt: createdAt(),
  },
  (table) => [index('files_org_idx').on(table.orgId), index('files_order_idx').on(table.orderId)],
)

export type Organization = typeof organizations.$inferSelect
export type Membership = typeof memberships.$inferSelect
export type Invite = typeof invites.$inferSelect
export type SupplierSettings = typeof supplierSettings.$inferSelect
export type SupplierPaymentConfig = typeof supplierPaymentConfigs.$inferSelect
export type Product = typeof products.$inferSelect
export type InventoryItem = typeof retailerInventory.$inferSelect
export type Order = typeof orders.$inferSelect
export type OrderItem = typeof orderItems.$inferSelect
export type OrderEvent = typeof orderEvents.$inferSelect
export type Shipment = typeof shipments.$inferSelect
export type PaymentRecord = typeof paymentRecords.$inferSelect
export type Receipt = typeof receipts.$inferSelect
export type RecurringSchedule = typeof recurringSchedules.$inferSelect
export type QuoteRequest = typeof quoteRequests.$inferSelect
export type QuoteItem = typeof quoteItems.$inferSelect
