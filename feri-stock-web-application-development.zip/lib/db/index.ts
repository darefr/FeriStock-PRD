import 'server-only'
import { join } from 'node:path'
import { drizzle, type NodePgDatabase } from 'drizzle-orm/node-postgres'
import { migrate } from 'drizzle-orm/node-postgres/migrator'
import { Pool } from 'pg'
import * as schema from './schema'

export type Db = NodePgDatabase<typeof schema>
export type Tx = Parameters<Parameters<Db['transaction']>[0]>[0]
/** Either the shared client or an open transaction. Code running inside a transaction must use the Tx it was given. */
export type Executor = Db | Tx

export type DatabaseMode = 'postgres' | 'embedded' | 'unconfigured'

type DatabaseHandle = {
  db: Db
  mode: DatabaseMode
  migrate: () => Promise<void>
  ready?: Promise<void>
}

const MIGRATIONS_FOLDER = join(process.cwd(), 'drizzle')

function connectionString(): string | undefined {
  return process.env.DATABASE_URL || process.env.POSTGRES_URL || undefined
}

function createPostgres(url: string): DatabaseHandle {
  const pool = new Pool({ connectionString: url, max: 10, idleTimeoutMillis: 30_000 })
  pool.on('error', (error) => console.error('[db] idle client error', error))
  const db = drizzle(pool, { schema })
  return {
    db,
    mode: 'postgres',
    // Production deployments migrate during the build (scripts/migrate.mjs); development migrates on boot.
    migrate: async () => {
      if (process.env.NODE_ENV === 'production') return
      try {
        await migrate(db, { migrationsFolder: MIGRATIONS_FOLDER })
      } catch {
        // Another process may have been applying the same migration; a second pass is a no-op when it has finished.
        await new Promise((resolve) => setTimeout(resolve, 2000))
        await migrate(db, { migrationsFolder: MIGRATIONS_FOLDER })
      }
    },
  }
}

function createUnconfigured(): DatabaseHandle {
  const fail = () =>
    Promise.reject(
      new Error('Database is not configured. Set DATABASE_URL to a PostgreSQL connection string and redeploy.'),
    )
  const pool = Object.assign(new Pool({ max: 1 }), { connect: fail, query: fail }) as unknown as Pool
  return { db: drizzle(pool, { schema }), mode: 'unconfigured', migrate: async () => {} }
}

async function createHandle(): Promise<DatabaseHandle> {
  const url = connectionString()
  if (url) return createPostgres(url)

  if (process.env.NODE_ENV !== 'production') {
    // Imported on demand so the embedded engine is left out of production bundles.
    const { createEmbeddedDatabase } = await import('./embedded')
    const embedded = await createEmbeddedDatabase(MIGRATIONS_FOLDER)
    return { db: embedded.db as unknown as Db, mode: 'embedded', migrate: embedded.migrate }
  }

  return createUnconfigured()
}

// The pending handle is cached on globalThis synchronously, so hot reloads and parallel first
// requests in development share one connection (the embedded engine allows only one).
const globalStore = globalThis as unknown as { __feristockDatabaseHandle?: Promise<DatabaseHandle> }
globalStore.__feristockDatabaseHandle ??= createHandle()
const handle = await globalStore.__feristockDatabaseHandle

export const db: Db = handle.db
export const databaseMode: DatabaseMode = handle.mode

/** Resolves once the schema is in place. Safe to await on every request. */
export function databaseReady(): Promise<void> {
  handle.ready ??= handle.migrate().catch((error) => {
    console.error('[db] failed to prepare the database', error)
    handle.ready = undefined
    throw error
  })
  return handle.ready
}

export { schema }
