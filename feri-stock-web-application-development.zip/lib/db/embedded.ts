// Development-only: an in-process PostgreSQL (PGlite) so the app runs with zero setup
// when no DATABASE_URL is configured. This module is never loaded in production builds.
//
// The engine keeps its data in memory and saves it as a single snapshot file that is replaced
// atomically. A dev server or sandbox that is stopped mid-write can therefore never leave a
// half-written database behind; at worst the last second or two of changes are not saved.
import { closeSync, existsSync, fsyncSync, openSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PGlite } from '@electric-sql/pglite'
import { drizzle } from 'drizzle-orm/pglite'
import { migrate } from 'drizzle-orm/pglite/migrator'
import { devDataDir } from '../dev-dir'
import * as schema from './schema'

const POLL_MS = 1000
/** Under a steady stream of writes, save at least this often instead of waiting for a quiet moment. */
const MAX_UNSAVED_MS = 10_000

async function currentLsn(client: PGlite): Promise<string> {
  const { rows } = await client.query<{ lsn: string }>('select pg_current_wal_lsn()::text as lsn')
  return rows[0].lsn
}

async function open(snapshotFile: string): Promise<{ client: PGlite; savedLsn: string | null }> {
  if (existsSync(snapshotFile)) {
    try {
      const client = new PGlite({ loadDataDir: new Blob([new Uint8Array(readFileSync(snapshotFile))]) })
      await client.waitReady
      return { client, savedLsn: await currentLsn(client) }
    } catch (error) {
      const aside = `${snapshotFile}.unreadable-${Date.now()}`
      renameSync(snapshotFile, aside)
      console.error(
        `[db] The development database could not be restored and was set aside as ${aside}. Starting with an empty one.`,
        error,
      )
    }
  }
  const client = new PGlite()
  await client.waitReady
  return { client, savedLsn: null }
}

function writeAtomically(file: string, bytes: Uint8Array): void {
  const temp = `${file}.tmp`
  const descriptor = openSync(temp, 'w', 0o600)
  try {
    writeFileSync(descriptor, bytes)
    fsyncSync(descriptor)
  } finally {
    closeSync(descriptor)
  }
  renameSync(temp, file)
}

/** Saves a snapshot shortly after the data stops changing. The write-ahead log position tells us when it has. */
function keepSaved(client: PGlite, snapshotFile: string, initialLsn: string | null): void {
  let savedLsn = initialLsn
  let seenLsn = initialLsn
  let lastSavedAt = Date.now()
  let busy = false

  const timer = setInterval(async () => {
    if (busy || client.closed) return
    busy = true
    try {
      const lsn = await currentLsn(client)
      if (lsn === savedLsn) return
      const settled = lsn === seenLsn
      seenLsn = lsn
      if (!settled && Date.now() - lastSavedAt < MAX_UNSAVED_MS) return

      const snapshot = await client.dumpDataDir('gzip')
      writeAtomically(snapshotFile, new Uint8Array(await snapshot.arrayBuffer()))
      savedLsn = lsn
      lastSavedAt = Date.now()
    } catch (error) {
      console.error('[db] could not save the development database', error)
    } finally {
      busy = false
    }
  }, POLL_MS)
  timer.unref()
}

export async function createEmbeddedDatabase(migrationsFolder: string) {
  // Test suites use a throwaway database and never need it written to disk.
  const persist = process.env.NODE_ENV !== 'test'
  const snapshotFile = join(devDataDir(), 'database.tar.gz')

  const { client, savedLsn } = persist ? await open(snapshotFile) : { client: new PGlite(), savedLsn: null }
  if (persist) keepSaved(client, snapshotFile, savedLsn)

  const db = drizzle(client, { schema })
  return {
    db,
    migrate: () => migrate(db, { migrationsFolder }),
  }
}
