export const ORG_ROLES = ['retailer', 'supplier', 'both'] as const
export type OrgRole = (typeof ORG_ROLES)[number]

export const MEMBER_ROLES = ['owner', 'manager', 'staff'] as const
export type MemberRole = (typeof MEMBER_ROLES)[number]

export const ORDER_TYPES = ['reorder', 'scheduled', 'custom'] as const
export type OrderType = (typeof ORDER_TYPES)[number]

export const ORDER_STATUSES = [
  'draft',
  'pending',
  'accepted',
  'packed',
  'dispatched',
  'delivered',
  'cancelled',
  'rejected',
] as const
export type OrderStatus = (typeof ORDER_STATUSES)[number]

export const PAYMENT_STATUSES = ['unpaid', 'pending', 'credit', 'partial', 'paid'] as const
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number]

export const CREDIT_STATES = ['none', 'requested', 'approved', 'declined'] as const
export type CreditState = (typeof CREDIT_STATES)[number]

export const DELIVERY_MODES = ['own_van', 'bilti', 'pickup'] as const
export type DeliveryMode = (typeof DELIVERY_MODES)[number]

export const PAYMENT_METHODS = ['esewa', 'khalti', 'qr_bank', 'cash'] as const
export type PaymentMethod = (typeof PAYMENT_METHODS)[number]

export const PAYMENT_RECORD_STATUSES = [
  'initiated',
  'pending_verification',
  'verified',
  'failed',
  'rejected',
] as const
export type PaymentRecordStatus = (typeof PAYMENT_RECORD_STATUSES)[number]

export const GATEWAY_ENVS = ['test', 'live'] as const
export type GatewayEnv = (typeof GATEWAY_ENVS)[number]

export const STOCK_REASONS = ['initial', 'manual', 'correction', 'delivery'] as const
export type StockReason = (typeof STOCK_REASONS)[number]

export const SCHEDULE_FREQUENCIES = ['weekly', 'monthly'] as const
export type ScheduleFrequency = (typeof SCHEDULE_FREQUENCIES)[number]

export const SCHEDULE_MODES = ['draft', 'auto'] as const
export type ScheduleMode = (typeof SCHEDULE_MODES)[number]

export const QUOTE_STATUSES = ['requested', 'quoted', 'accepted', 'declined', 'cancelled'] as const
export type QuoteStatus = (typeof QUOTE_STATUSES)[number]

export const FILE_KINDS = ['bilti_photo', 'payment_proof', 'qr_image'] as const
export type FileKind = (typeof FILE_KINDS)[number]

export const RECEIPT_KINDS = ['order', 'payment'] as const
export type ReceiptKind = (typeof RECEIPT_KINDS)[number]

export const ORG_ROLE_LABEL: Record<OrgRole, string> = {
  retailer: 'Retail shop',
  supplier: 'Wholesaler / Distributor',
  both: 'Retail + Wholesale',
}

export const MEMBER_ROLE_LABEL: Record<MemberRole, string> = {
  owner: 'Owner',
  manager: 'Manager',
  staff: 'Staff',
}

export const ORDER_TYPE_LABEL: Record<OrderType, string> = {
  reorder: 'Reorder',
  scheduled: 'Scheduled',
  custom: 'Custom quote',
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  draft: 'Draft',
  pending: 'Pending',
  accepted: 'Accepted',
  packed: 'Packed',
  dispatched: 'Dispatched',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
  rejected: 'Rejected',
}

export const FULFILMENT_STAGES = ['pending', 'accepted', 'packed', 'dispatched', 'delivered'] as const

export const DELIVERY_MODE_LABEL: Record<DeliveryMode, string> = {
  own_van: 'Own van',
  bilti: 'Transport (bilti)',
  pickup: 'Pickup',
}

export const PAYMENT_METHOD_LABEL: Record<PaymentMethod, string> = {
  esewa: 'eSewa',
  khalti: 'Khalti',
  qr_bank: 'QR / Bank transfer',
  cash: 'Cash / Cheque',
}

export const PAYMENT_STATUS_LABEL: Record<PaymentStatus, string> = {
  unpaid: 'Unpaid',
  pending: 'Awaiting confirmation',
  credit: 'Udharo',
  partial: 'Part paid',
  paid: 'Paid',
}

export const QUOTE_STATUS_LABEL: Record<QuoteStatus, string> = {
  requested: 'Awaiting quote',
  quoted: 'Quoted',
  accepted: 'Accepted',
  declined: 'Declined',
  cancelled: 'Cancelled',
}

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const

export const COMMON_UNITS = ['pcs', 'pkt', 'box', 'carton', 'kg', 'sack', 'litre', 'bottle', 'jar', 'dozen', 'crate'] as const

export const NEPAL_CITIES = [
  'Kathmandu',
  'Lalitpur',
  'Bhaktapur',
  'Pokhara',
  'Biratnagar',
  'Birgunj',
  'Butwal',
  'Bharatpur',
  'Dharan',
  'Itahari',
  'Hetauda',
  'Janakpur',
  'Nepalgunj',
  'Dhangadhi',
  'Damak',
  'Birtamod',
] as const

export const LIMITS = {
  maxUploadBytes: 2 * 1024 * 1024,
  maxBulkTiers: 6,
  maxOrderLines: 100,
  maxQty: 1_000_000,
  maxPricePaisa: 100_000_000_00,
  inviteTtlDays: 7,
  khaltiMinPaisa: 1000,
} as const
