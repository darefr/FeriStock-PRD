import type { MemberRole } from './constants'
import type { Organization } from './db/schema'
import { AppError } from './errors'
import { can, type Capability } from './permissions'

// Framework-free on purpose: the business logic depends on this module, never on Next.js.

export type SessionUser = { id: string; name: string; email: string }

/** Who is acting, for which organization, with which role. Every data access is scoped by this. */
export type AppContext = {
  user: SessionUser
  org: Organization
  role: MemberRole
  isRetailer: boolean
  isSupplier: boolean
}

export type AuthorizeOptions = {
  capability?: Capability
  side?: 'retailer' | 'supplier'
}

export function buildContext(user: SessionUser, org: Organization, role: MemberRole): AppContext {
  return {
    user,
    org,
    role,
    isRetailer: org.role !== 'supplier',
    isSupplier: org.role !== 'retailer',
  }
}

/** Throws unless the acting member's organization type and role allow the operation. */
export function assertAllowed(context: AppContext, options: AuthorizeOptions): void {
  if (options.side === 'retailer' && !context.isRetailer) {
    throw AppError.forbidden('This is only available to retail organizations.')
  }
  if (options.side === 'supplier' && !context.isSupplier) {
    throw AppError.forbidden('This is only available to supplier organizations.')
  }
  if (options.capability && !can(context.role, options.capability)) {
    throw AppError.forbidden('Your role does not allow this. Ask an owner or manager of your organization.')
  }
}
