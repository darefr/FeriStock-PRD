import 'server-only'
import { cache } from 'react'
import { eq } from 'drizzle-orm'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { auth } from './auth'
import { appReady } from './bootstrap'
import { assertAllowed, buildContext, type AppContext, type AuthorizeOptions, type SessionUser } from './context'
import { db } from './db'
import { memberships, organizations } from './db/schema'
import { AppError } from './errors'

export type { AppContext, AuthorizeOptions, SessionUser } from './context'

export const getSessionUser = cache(async (): Promise<SessionUser | null> => {
  await appReady()
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return null
  return { id: session.user.id, name: session.user.name, email: session.user.email }
})

export const getContext = cache(async (): Promise<AppContext | null> => {
  const user = await getSessionUser()
  if (!user) return null
  const [row] = await db
    .select({ org: organizations, role: memberships.role })
    .from(memberships)
    .innerJoin(organizations, eq(organizations.id, memberships.orgId))
    .where(eq(memberships.userId, user.id))
    .limit(1)
  return row ? buildContext(user, row.org, row.role) : null
})

/** Page guard: sends signed-out visitors to the login page. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser()
  if (!user) redirect('/login')
  return user
}

/** Page guard: requires a signed-in member of an organization. */
export async function requireContext(): Promise<AppContext> {
  await requireUser()
  const context = await getContext()
  if (!context) redirect('/onboarding')
  return context
}

/** Guard for server actions and route handlers: throws instead of redirecting. */
export async function authorize(options: AuthorizeOptions = {}): Promise<AppContext> {
  const user = await getSessionUser()
  if (!user) throw AppError.unauthenticated()
  const context = await getContext()
  if (!context) throw AppError.forbidden('Set up your organization before continuing.')
  assertAllowed(context, options)
  return context
}
