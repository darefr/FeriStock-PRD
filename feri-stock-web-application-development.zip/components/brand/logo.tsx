import { cn } from '@/lib/utils'

type Tone = 'default' | 'inverse'

/** Three stacked cartons; the top one, in amber, is the restock arriving. */
export function LogoMark({ className, tone = 'default' }: { className?: string; tone?: Tone }) {
  const tile = tone === 'inverse' ? 'var(--primary-foreground)' : 'var(--primary)'
  const carton = tone === 'inverse' ? 'var(--primary)' : 'var(--primary-foreground)'
  return (
    <svg viewBox="0 0 32 32" className={cn('size-8 shrink-0', className)} aria-hidden="true" focusable="false">
      <rect width="32" height="32" rx="7" fill={tile} />
      <rect x="6" y="17.5" width="9" height="8.5" rx="1.5" fill={carton} />
      <rect x="17" y="17.5" width="9" height="8.5" rx="1.5" fill={carton} />
      <rect x="11.5" y="6.5" width="9" height="8.5" rx="1.5" fill="var(--warning)" />
    </svg>
  )
}

export function Logo({
  className,
  markClassName,
  tone = 'default',
}: {
  className?: string
  markClassName?: string
  tone?: Tone
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2',
        tone === 'inverse' ? 'text-primary-foreground' : 'text-foreground',
        className,
      )}
    >
      <LogoMark className={markClassName} tone={tone} />
      <span className="text-lg font-semibold tracking-tight">
        Feri<span className={tone === 'inverse' ? 'text-warning' : 'text-primary'}>Stock</span>
      </span>
    </span>
  )
}
