'use client'

import { FormField } from '@/components/app/form-field'
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
  FieldTitle,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { NEPAL_CITIES, type OrgRole } from '@/lib/constants'

export type OrganizationDraft = {
  name: string
  role: OrgRole
  panVatNo: string
  city: string
  address: string
  phone: string
  email: string
}

export const EMPTY_ORGANIZATION: OrganizationDraft = {
  name: '',
  role: 'retailer',
  panVatNo: '',
  city: '',
  address: '',
  phone: '',
  email: '',
}

const ROLE_CHOICES: Array<{ value: OrgRole; title: string; description: string }> = [
  {
    value: 'retailer',
    title: 'Retail shop',
    description: 'Track shop stock and order restocks from wholesalers.',
  },
  {
    value: 'supplier',
    title: 'Wholesaler or distributor',
    description: 'Publish a catalog, receive orders, dispatch and collect payment.',
  },
  {
    value: 'both',
    title: 'Both',
    description: 'Buy stock from suppliers and also supply other shops.',
  },
]

export function OrganizationFields({
  value,
  onChange,
  errors,
  idPrefix = 'org',
}: {
  value: OrganizationDraft
  onChange: (next: OrganizationDraft) => void
  errors: Record<string, string>
  idPrefix?: string
}) {
  const set = <Key extends keyof OrganizationDraft>(key: Key, next: OrganizationDraft[Key]) =>
    onChange({ ...value, [key]: next })
  const id = (name: string) => `${idPrefix}-${name}`

  return (
    <FieldGroup>
      <FieldSet>
        <FieldLegend variant="label">How will you use FeriStock?</FieldLegend>
        <RadioGroup value={value.role} onValueChange={(next) => set('role', next as OrgRole)}>
          {ROLE_CHOICES.map((choice) => (
            <FieldLabel key={choice.value} htmlFor={id(`role-${choice.value}`)}>
              <Field orientation="horizontal">
                <FieldContent>
                  <FieldTitle>{choice.title}</FieldTitle>
                  <FieldDescription>{choice.description}</FieldDescription>
                </FieldContent>
                <RadioGroupItem value={choice.value} id={id(`role-${choice.value}`)} />
              </Field>
            </FieldLabel>
          ))}
        </RadioGroup>
        {errors.role ? <FieldError>{errors.role}</FieldError> : null}
      </FieldSet>

      <FormField label="Business name" htmlFor={id('name')} error={errors.name}>
        <Input
          id={id('name')}
          autoComplete="organization"
          placeholder="e.g. Himal Kirana Pasal"
          aria-invalid={errors.name ? true : undefined}
          value={value.name}
          onChange={(event) => set('name', event.target.value)}
        />
      </FormField>

      <div className="grid gap-5 sm:grid-cols-2">
        <FormField
          label="PAN / VAT number"
          htmlFor={id('pan')}
          error={errors.panVatNo}
          hint="9 digits. Printed on every receipt."
        >
          <Input
            id={id('pan')}
            inputMode="numeric"
            autoComplete="off"
            maxLength={9}
            className="figures"
            aria-invalid={errors.panVatNo ? true : undefined}
            value={value.panVatNo}
            onChange={(event) => set('panVatNo', event.target.value.replace(/\D/g, '').slice(0, 9))}
          />
        </FormField>
        <FormField label="Phone" htmlFor={id('phone')} error={errors.phone}>
          <Input
            id={id('phone')}
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            placeholder="98XXXXXXXX"
            aria-invalid={errors.phone ? true : undefined}
            value={value.phone}
            onChange={(event) => set('phone', event.target.value)}
          />
        </FormField>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <FormField label="City" htmlFor={id('city')} error={errors.city}>
          <Input
            id={id('city')}
            list={id('cities')}
            autoComplete="address-level2"
            aria-invalid={errors.city ? true : undefined}
            value={value.city}
            onChange={(event) => set('city', event.target.value)}
          />
          <datalist id={id('cities')}>
            {NEPAL_CITIES.map((city) => (
              <option key={city} value={city} />
            ))}
          </datalist>
        </FormField>
        <FormField label="Address" htmlFor={id('address')} error={errors.address}>
          <Input
            id={id('address')}
            autoComplete="street-address"
            placeholder="Tole, ward"
            aria-invalid={errors.address ? true : undefined}
            value={value.address}
            onChange={(event) => set('address', event.target.value)}
          />
        </FormField>
      </div>

      <FormField label="Business email" htmlFor={id('email')} error={errors.email} optional>
        <Input
          id={id('email')}
          type="email"
          inputMode="email"
          autoComplete="email"
          autoCapitalize="none"
          aria-invalid={errors.email ? true : undefined}
          value={value.email}
          onChange={(event) => set('email', event.target.value)}
        />
      </FormField>
    </FieldGroup>
  )
}
