'use client'

import { useRouter } from 'next/navigation'
import { useState, type FormEvent } from 'react'
import { FormField } from '@/components/app/form-field'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useAction } from '@/hooks/use-action'
import { createOrganizationAction, joinOrganizationAction } from '@/lib/actions/org'
import { fieldErrors, organizationSchema } from '@/lib/validation'
import { EMPTY_ORGANIZATION, OrganizationFields, type OrganizationDraft } from './organization-fields'

export function OnboardingForms() {
  const router = useRouter()
  const [draft, setDraft] = useState<OrganizationDraft>(EMPTY_ORGANIZATION)
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})
  const [code, setCode] = useState('')

  const enterApp = () => {
    router.replace('/app')
    router.refresh()
  }
  const create = useAction(createOrganizationAction, { onSuccess: enterApp })
  const join = useAction(joinOrganizationAction, { onSuccess: enterApp })

  function handleCreate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const parsed = organizationSchema.safeParse(draft)
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void create.run(parsed.data)
  }

  function handleJoin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    void join.run({ code })
  }

  return (
    <Tabs defaultValue="create">
      <TabsList className="w-full">
        <TabsTrigger value="create">Register a business</TabsTrigger>
        <TabsTrigger value="join">Join with a code</TabsTrigger>
      </TabsList>

      <TabsContent value="create">
        <Card>
          <CardHeader>
            <CardTitle>Your business</CardTitle>
            <CardDescription>
              These details appear on purchase orders and receipts, so enter them as registered.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} noValidate className="flex flex-col gap-6">
              <OrganizationFields
                value={draft}
                onChange={setDraft}
                errors={{ ...create.fields, ...localErrors }}
              />
              <Button type="submit" size="lg" disabled={create.pending}>
                {create.pending ? <Spinner data-icon="inline-start" /> : null}
                {create.pending ? 'Setting up…' : 'Create workspace'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="join">
        <Card>
          <CardHeader>
            <CardTitle>Join your team</CardTitle>
            <CardDescription>
              Ask the owner of your shop or wholesale business for an invite code. They can create one under Settings
              → Team.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleJoin} noValidate>
              <FieldGroup>
                <FormField label="Invite code" htmlFor="invite-code" error={join.fields.code} hint="12 characters, for example K7QW-9XMP-4RTB.">
                  <Input
                    id="invite-code"
                    autoComplete="off"
                    autoCapitalize="characters"
                    spellCheck={false}
                    className="figures uppercase"
                    placeholder="XXXX-XXXX-XXXX"
                    aria-invalid={join.fields.code ? true : undefined}
                    value={code}
                    onChange={(event) => setCode(event.target.value.slice(0, 20))}
                  />
                </FormField>
                <Button type="submit" size="lg" disabled={join.pending || code.trim().length < 12}>
                  {join.pending ? <Spinner data-icon="inline-start" /> : null}
                  {join.pending ? 'Joining…' : 'Join organization'}
                </Button>
              </FieldGroup>
            </form>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
