import type { ComponentProps } from 'react'
import { Badge } from '@/components/ui/badge'
import {
  ORDER_STATUS_LABEL,
  PAYMENT_STATUS_LABEL,
  QUOTE_STATUS_LABEL,
  type OrderStatus,
  type PaymentStatus,
  type QuoteStatus,
} from '@/lib/constants'
import { STOCK_STATUS_LABEL, type StockStatus } from '@/lib/domain/stock-rules'

type Variant = ComponentProps<typeof Badge>['variant']

const ORDER_VARIANT: Record<OrderStatus, Variant> = {
  draft: 'outline',
  pending: 'warning',
  accepted: 'secondary',
  packed: 'secondary',
  dispatched: 'default',
  delivered: 'success',
  cancelled: 'outline',
  rejected: 'destructive',
}

export function OrderStatusBadge({ status, className }: { status: OrderStatus; className?: string }) {
  return (
    <Badge variant={ORDER_VARIANT[status]} className={className}>
      {ORDER_STATUS_LABEL[status]}
    </Badge>
  )
}

const PAYMENT_VARIANT: Record<PaymentStatus, Variant> = {
  unpaid: 'outline',
  pending: 'warning',
  credit: 'warning',
  partial: 'secondary',
  paid: 'success',
}

export function PaymentStatusBadge({
  status,
  overdue = false,
  className,
}: {
  status: PaymentStatus
  overdue?: boolean
  className?: string
}) {
  if (overdue) {
    return (
      <Badge variant="destructive" className={className}>
        Overdue
      </Badge>
    )
  }
  return (
    <Badge variant={PAYMENT_VARIANT[status]} className={className}>
      {PAYMENT_STATUS_LABEL[status]}
    </Badge>
  )
}

const STOCK_VARIANT: Record<StockStatus, Variant> = { ok: 'success', low: 'warning', out: 'destructive' }

export function StockStatusBadge({ status, className }: { status: StockStatus; className?: string }) {
  return (
    <Badge variant={STOCK_VARIANT[status]} className={className}>
      {STOCK_STATUS_LABEL[status]}
    </Badge>
  )
}

const QUOTE_VARIANT: Record<QuoteStatus, Variant> = {
  requested: 'warning',
  quoted: 'default',
  accepted: 'success',
  declined: 'outline',
  cancelled: 'outline',
}

export function QuoteStatusBadge({
  status,
  expired = false,
  className,
}: {
  status: QuoteStatus
  expired?: boolean
  className?: string
}) {
  if (expired) {
    return (
      <Badge variant="outline" className={className}>
        Expired
      </Badge>
    )
  }
  return (
    <Badge variant={QUOTE_VARIANT[status]} className={className}>
      {QUOTE_STATUS_LABEL[status]}
    </Badge>
  )
}
