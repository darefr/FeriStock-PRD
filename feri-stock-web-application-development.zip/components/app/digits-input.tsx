'use client'

import type { ComponentProps } from 'react'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'

/** A whole-number field that opens the numeric keypad on phones and never accepts anything but digits. */
export function DigitsInput({
  value,
  onValueChange,
  maxLength = 7,
  className,
  ...props
}: Omit<ComponentProps<typeof Input>, 'value' | 'onChange' | 'type' | 'maxLength'> & {
  value: string
  onValueChange: (value: string) => void
  maxLength?: number
}) {
  return (
    <Input
      type="text"
      inputMode="numeric"
      pattern="[0-9]*"
      autoComplete="off"
      className={cn('figures', className)}
      value={value}
      onChange={(event) => onValueChange(event.target.value.replace(/\D/g, '').slice(0, maxLength))}
      {...props}
    />
  )
}

/** Reads a digits-only field; an empty field counts as the fallback. */
export function toInt(value: string, fallback = 0): number {
  return value === '' ? fallback : Number.parseInt(value, 10)
}
