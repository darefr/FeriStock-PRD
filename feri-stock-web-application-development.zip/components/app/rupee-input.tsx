'use client'

import type { ComponentProps } from 'react'
import { InputGroup, InputGroupAddon, InputGroupInput, InputGroupText } from '@/components/ui/input-group'

/**
 * A rupee amount field. Holds the text exactly as typed; convert with `parseRupees` on submit
 * so a half-typed value such as "12." is never rewritten under the user's fingers.
 */
export function RupeeInput({
  value,
  onValueChange,
  ...props
}: Omit<ComponentProps<typeof InputGroupInput>, 'value' | 'onChange' | 'type'> & {
  value: string
  onValueChange: (value: string) => void
}) {
  return (
    <InputGroup>
      <InputGroupAddon>
        <InputGroupText>Rs.</InputGroupText>
      </InputGroupAddon>
      <InputGroupInput
        type="text"
        inputMode="decimal"
        autoComplete="off"
        className="figures"
        value={value}
        onChange={(event) => onValueChange(event.target.value.replace(/[^\d.,]/g, '').slice(0, 14))}
        {...props}
      />
    </InputGroup>
  )
}
