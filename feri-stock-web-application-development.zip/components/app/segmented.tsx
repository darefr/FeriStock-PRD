'use client'

import type { ReactNode } from 'react'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'

/** Pick exactly one of a few options. Tapping the selected option again keeps it selected. */
export function Segmented<Value extends string>({
  value,
  onChange,
  options,
  label,
  disabled = false,
  className,
}: {
  value: Value
  onChange: (value: Value) => void
  options: ReadonlyArray<{ value: Value; label: ReactNode }>
  /** What is being chosen, for screen readers. */
  label: string
  disabled?: boolean
  className?: string
}) {
  return (
    <ToggleGroup
      variant="outline"
      aria-label={label}
      disabled={disabled}
      className={className}
      value={[value]}
      onValueChange={(next) => {
        const picked = next[0] as Value | undefined
        if (picked) onChange(picked)
      }}
    >
      {options.map((option) => (
        <ToggleGroupItem key={option.value} value={option.value}>
          {option.label}
        </ToggleGroupItem>
      ))}
    </ToggleGroup>
  )
}
