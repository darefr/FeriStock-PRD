import { formatAmount } from '@/lib/money'
import { cn } from '@/lib/utils'

/** An NPR amount set in fixed-width figures so columns of money line up. */
export function Money({
  paisa,
  className,
  decimals = 'auto',
  symbol = true,
}: {
  paisa: number
  className?: string
  decimals?: 'auto' | 'always'
  symbol?: boolean
}) {
  return (
    <span className={cn('figures whitespace-nowrap', className)}>
      {symbol ? 'Rs. ' : null}
      {formatAmount(paisa, { decimals })}
    </span>
  )
}
