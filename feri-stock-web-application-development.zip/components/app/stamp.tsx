import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

const TONES = {
  paid: 'text-success',
  credit: 'text-warning-foreground',
  due: 'text-destructive',
  neutral: 'text-muted-foreground',
} as const

/**
 * The rubber stamp every Nepali bill ends with. It states the payment position of an order
 * or receipt — PAID, UDHARO, UNPAID — so it carries meaning, not decoration.
 */
export function Stamp({
  tone,
  children,
  detail,
  className,
}: {
  tone: keyof typeof TONES
  children: ReactNode
  detail?: ReactNode
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex -rotate-6 select-none flex-col items-center rounded-md border-2 border-current px-3 py-1.5 font-mono leading-none outline outline-1 outline-offset-2 outline-current',
        TONES[tone],
        className,
      )}
    >
      <span className="text-base font-semibold uppercase tracking-[0.22em]">{children}</span>
      {detail ? <span className="mt-1 text-[0.65rem] font-medium uppercase tracking-[0.12em]">{detail}</span> : null}
    </span>
  )
}
