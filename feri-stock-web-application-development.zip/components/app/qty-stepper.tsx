'use client'

import { MinusIcon, PlusIcon } from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

/**
 * A quantity control built for a thumb at a shop counter: large minus and plus targets
 * with a number in the middle that can also be typed. Typed values are committed on blur or Enter.
 */
export function QtyStepper({
  value,
  onChange,
  min = 0,
  max = 1_000_000,
  step = 1,
  label,
  disabled = false,
  size = 'default',
  className,
}: {
  value: number
  onChange: (next: number) => void
  min?: number
  max?: number
  step?: number
  /** What is being counted, for screen readers — for example the product name. */
  label: string
  disabled?: boolean
  size?: 'default' | 'lg'
  className?: string
}) {
  const [draft, setDraft] = useState(String(value))
  const [syncedValue, setSyncedValue] = useState(value)

  // Follow the value when it changes from outside (a tap on plus/minus, or fresh data from the server).
  if (syncedValue !== value) {
    setSyncedValue(value)
    setDraft(String(value))
  }

  const clamp = (next: number) => Math.min(max, Math.max(min, next))

  function commit() {
    const parsed = Number.parseInt(draft, 10)
    const next = Number.isFinite(parsed) ? clamp(parsed) : value
    setDraft(String(next))
    if (next !== value) onChange(next)
  }

  const buttonSize = size === 'lg' ? 'icon-lg' : 'icon'

  return (
    <div className={cn('inline-flex items-center gap-1', className)} role="group" aria-label={`Quantity of ${label}`}>
      <Button
        type="button"
        variant="outline"
        size={buttonSize}
        disabled={disabled || value <= min}
        onClick={() => onChange(clamp(value - step))}
        aria-label={`Decrease ${label}`}
      >
        <MinusIcon />
      </Button>
      <input
        type="text"
        inputMode="numeric"
        pattern="[0-9]*"
        autoComplete="off"
        disabled={disabled}
        value={draft}
        onChange={(event) => setDraft(event.target.value.replace(/\D/g, '').slice(0, 7))}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Enter' && !event.nativeEvent.isComposing) event.currentTarget.blur()
        }}
        onFocus={(event) => event.currentTarget.select()}
        aria-label={`Quantity of ${label}`}
        className={cn(
          'figures rounded-lg border border-input bg-card text-center text-base font-medium outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-50',
          size === 'lg' ? 'h-9 w-16 pointer-coarse:h-11' : 'h-8 w-14 pointer-coarse:h-10',
        )}
      />
      <Button
        type="button"
        variant="outline"
        size={buttonSize}
        disabled={disabled || value >= max}
        onClick={() => onChange(clamp(value + step))}
        aria-label={`Increase ${label}`}
      >
        <PlusIcon />
      </Button>
    </div>
  )
}
