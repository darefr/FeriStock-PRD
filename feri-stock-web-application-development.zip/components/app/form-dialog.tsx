'use client'

import type { ComponentProps, ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Spinner } from '@/components/ui/spinner'
import { cn } from '@/lib/utils'

/**
 * A dialog that holds one form. It scrolls on short phone screens while keeping the submit
 * button in reach, and it cannot be dismissed while the submission is in flight.
 */
export function FormDialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  onSubmit,
  submitLabel,
  submitVariant = 'default',
  submitDisabled = false,
  pending = false,
  size = 'md',
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description?: ReactNode
  children: ReactNode
  onSubmit: () => void
  submitLabel: string
  submitVariant?: ComponentProps<typeof Button>['variant']
  submitDisabled?: boolean
  pending?: boolean
  size?: 'md' | 'lg'
}) {
  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!pending) onOpenChange(next)
      }}
    >
      <DialogContent
        className={cn('max-h-[calc(100dvh-2rem)] overflow-y-auto', size === 'lg' ? 'sm:max-w-2xl' : 'sm:max-w-lg')}
      >
        <form
          noValidate
          className="grid gap-4"
          onSubmit={(event) => {
            event.preventDefault()
            event.stopPropagation()
            onSubmit()
          }}
        >
          <DialogHeader className="pr-8">
            <DialogTitle className="leading-snug">{title}</DialogTitle>
            {description ? <DialogDescription>{description}</DialogDescription> : null}
          </DialogHeader>
          {children}
          <DialogFooter className="sticky -bottom-4 bg-muted">
            <Button type="button" variant="outline" disabled={pending} onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant={submitVariant} disabled={pending || submitDisabled}>
              {pending ? <Spinner data-icon="inline-start" /> : null}
              {submitLabel}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
