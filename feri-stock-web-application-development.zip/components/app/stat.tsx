import Link from 'next/link'
import type { ReactNode } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

const TONES = {
  default: 'text-foreground',
  muted: 'text-muted-foreground',
  warning: 'text-warning-foreground',
  danger: 'text-destructive',
  success: 'text-success',
} as const

/** One figure with its label. Links to the screen where that figure can be acted on. */
export function Stat({
  label,
  value,
  hint,
  tone = 'default',
  href,
}: {
  label: string
  value: ReactNode
  hint?: ReactNode
  tone?: keyof typeof TONES
  href?: string
}) {
  const tile = (
    <Card size="sm" className={cn('h-full', href && 'transition-colors group-hover/stat:bg-accent/60')}>
      <CardContent className="flex flex-col gap-1.5">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className={cn('figures text-2xl font-semibold leading-tight', TONES[tone])}>{value}</span>
        {hint ? <span className="text-xs leading-relaxed text-muted-foreground">{hint}</span> : null}
      </CardContent>
    </Card>
  )
  if (!href) return tile
  return (
    <Link
      href={href}
      className="group/stat rounded-xl outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
    >
      {tile}
    </Link>
  )
}
