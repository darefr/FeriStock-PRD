'use client'

import { Segmented } from './segmented'

/** A row of mutually exclusive filters with counts. Scrolls sideways on narrow phones instead of wrapping. */
export function FilterBar<Value extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: Value
  onChange: (value: Value) => void
  options: ReadonlyArray<{ value: Value; label: string; count?: number }>
  label: string
}) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
      <Segmented
        label={label}
        value={value}
        onChange={onChange}
        className="w-max"
        options={options.map((option) => ({
          value: option.value,
          label: (
            <>
              {option.label}
              {option.count !== undefined ? <span className="figures text-muted-foreground">{option.count}</span> : null}
            </>
          ),
        }))}
      />
    </div>
  )
}
