'use client'

import { SearchIcon } from 'lucide-react'
import { InputGroup, InputGroupAddon, InputGroupInput } from '@/components/ui/input-group'

export function SearchInput({
  value,
  onValueChange,
  label,
  placeholder,
  className,
}: {
  value: string
  onValueChange: (value: string) => void
  /** Accessible name, for example "Search products". */
  label: string
  placeholder?: string
  className?: string
}) {
  return (
    <InputGroup className={className}>
      <InputGroupAddon>
        <SearchIcon />
      </InputGroupAddon>
      <InputGroupInput
        type="search"
        inputMode="search"
        autoComplete="off"
        spellCheck={false}
        aria-label={label}
        placeholder={placeholder ?? label}
        value={value}
        onChange={(event) => onValueChange(event.target.value)}
      />
    </InputGroup>
  )
}
