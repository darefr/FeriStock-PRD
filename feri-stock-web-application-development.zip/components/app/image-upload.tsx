'use client'

import { CameraIcon, XIcon } from 'lucide-react'
import { useId, useRef, useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Spinner } from '@/components/ui/spinner'
import type { FileKind } from '@/lib/constants'
import { LIMITS } from '@/lib/constants'

const MAX_EDGE = 1600

/** Scales a phone photo down and re-encodes it as JPEG so uploads stay small on a mobile connection. */
async function compressImage(file: File): Promise<Blob> {
  const url = URL.createObjectURL(file)
  try {
    const image = new Image()
    image.crossOrigin = 'anonymous'
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve()
      image.onerror = () => reject(new Error('This file is not an image we can read.'))
      image.src = url
    })
    const scale = Math.min(1, MAX_EDGE / Math.max(image.naturalWidth, image.naturalHeight))
    const canvas = document.createElement('canvas')
    canvas.width = Math.round(image.naturalWidth * scale)
    canvas.height = Math.round(image.naturalHeight * scale)
    const context = canvas.getContext('2d')
    if (!context) throw new Error('Your browser could not process this image.')
    // JPEG has no transparency; without a white base, transparent QR backgrounds would turn black.
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    context.drawImage(image, 0, 0, canvas.width, canvas.height)
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.82))
    if (!blob) throw new Error('Your browser could not process this image.')
    return blob
  } finally {
    URL.revokeObjectURL(url)
  }
}

/**
 * Picks a photo (camera or gallery), compresses it and uploads it privately.
 * Calls `onChange` with the stored file id, or null when the photo is removed.
 */
export function ImageUpload({
  kind,
  value,
  onChange,
  label,
  capture = false,
  disabled = false,
}: {
  kind: FileKind
  value: string | null
  onChange: (fileId: string | null) => void
  label: string
  /** Open the rear camera first on phones — useful for a bilti slip on the counter. */
  capture?: boolean
  disabled?: boolean
}) {
  const inputId = useId()
  const inputRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)

  async function handleFile(file: File | undefined) {
    if (!file) return
    setUploading(true)
    try {
      const blob = await compressImage(file)
      if (blob.size > LIMITS.maxUploadBytes) throw new Error('This image is too large. Try a smaller photo.')
      const body = new FormData()
      body.set('kind', kind)
      body.set('file', blob, 'upload.jpg')
      const response = await fetch('/api/files', { method: 'POST', body, credentials: 'same-origin' })
      const result = (await response.json().catch(() => null)) as { id?: string; error?: string } | null
      if (!response.ok || !result?.id) throw new Error(result?.error ?? 'The upload did not go through. Please try again.')
      onChange(result.id)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'The upload did not go through. Please try again.')
    } finally {
      setUploading(false)
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  return (
    <div className="flex items-center gap-3">
      <input
        ref={inputRef}
        id={inputId}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        capture={capture ? 'environment' : undefined}
        className="sr-only"
        tabIndex={-1}
        disabled={disabled || uploading}
        onChange={(event) => handleFile(event.target.files?.[0])}
      />
      {value ? (
        <>
          <a
            href={`/api/files/${value}`}
            target="_blank"
            rel="noreferrer"
            className="block shrink-0 overflow-hidden rounded-lg border bg-muted outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
          >
            <img src={`/api/files/${value}`} alt={`Uploaded ${label.toLowerCase()}`} className="size-16 object-cover" />
          </a>
          <div className="flex flex-col items-start gap-1">
            <span className="text-sm font-medium">{label} attached</span>
            <Button type="button" variant="ghost" size="sm" disabled={disabled} onClick={() => onChange(null)}>
              <XIcon data-icon="inline-start" />
              Remove
            </Button>
          </div>
        </>
      ) : (
        <Button
          type="button"
          variant="outline"
          disabled={disabled || uploading}
          onClick={() => inputRef.current?.click()}
          aria-controls={inputId}
        >
          {uploading ? <Spinner data-icon="inline-start" /> : <CameraIcon data-icon="inline-start" />}
          {uploading ? 'Uploading…' : `Add ${label.toLowerCase()}`}
        </Button>
      )}
    </div>
  )
}
