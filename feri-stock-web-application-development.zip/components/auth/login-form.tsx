'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState, type FormEvent } from 'react'
import { FormField } from '@/components/app/form-field'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { authClient } from '@/lib/auth-client'
import { PasswordInput } from './password-input'

export function LoginForm({ next }: { next: string }) {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [pending, setPending] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError(null)
    setPending(true)
    const result = await authClient.signIn.email({ email: email.trim(), password }).catch(() => null)
    if (!result || result.error) {
      setPending(false)
      // Deliberately the same message for an unknown email and a wrong password.
      setError(
        !result
          ? 'Could not reach FeriStock. Check your connection and try again.'
          : result.error.status === 429
            ? 'Too many attempts. Wait a minute and try again.'
            : 'That email and password do not match. Check them and try again.',
      )
      return
    }
    router.replace(next)
    router.refresh()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1.5">
        <h1 className="text-2xl font-semibold tracking-tight">Log in</h1>
        <p className="text-sm leading-relaxed text-muted-foreground">Welcome back. Enter your details to open your workspace.</p>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <FieldGroup>
          {error ? (
            <Alert variant="destructive" role="alert">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : null}
          <FormField label="Email" htmlFor="email">
            <Input
              id="email"
              name="email"
              type="email"
              inputMode="email"
              autoComplete="email"
              autoCapitalize="none"
              spellCheck={false}
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </FormField>
          <FormField label="Password" htmlFor="password">
            <PasswordInput
              id="password"
              name="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </FormField>
          <Button type="submit" size="lg" disabled={pending || !email || !password}>
            {pending ? <Spinner data-icon="inline-start" /> : null}
            {pending ? 'Logging in…' : 'Log in'}
          </Button>
        </FieldGroup>
      </form>

      <p className="text-sm text-muted-foreground">
        New to FeriStock?{' '}
        <Link href="/signup" className="font-medium text-primary underline-offset-4 hover:underline">
          Create an account
        </Link>
      </p>
    </div>
  )
}
