'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState, type FormEvent } from 'react'
import { z } from 'zod'
import { FormField } from '@/components/app/form-field'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { authClient } from '@/lib/auth-client'
import { credentialsSchema, fieldErrors } from '@/lib/validation'
import { PasswordInput } from './password-input'

const signupSchema = z.object(credentialsSchema)

export function SignupForm() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formError, setFormError] = useState<string | null>(null)
  const [pending, setPending] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFormError(null)
    const parsed = signupSchema.safeParse({ name, email: email.trim(), password })
    if (!parsed.success) {
      setErrors(fieldErrors(parsed.error))
      return
    }
    setErrors({})
    setPending(true)
    const result = await authClient.signUp.email(parsed.data).catch(() => null)
    if (!result || result.error) {
      setPending(false)
      // Does not say whether the email is already registered.
      setFormError(
        !result
          ? 'Could not reach FeriStock. Check your connection and try again.'
          : result.error.status === 429
            ? 'Too many attempts. Wait a minute and try again.'
            : 'We could not create an account with these details. If you already have one, log in instead.',
      )
      return
    }
    router.replace('/onboarding')
    router.refresh()
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1.5">
        <h1 className="text-2xl font-semibold tracking-tight">Create your account</h1>
        <p className="text-sm leading-relaxed text-muted-foreground">
          First your own login, then your shop or wholesale business on the next step.
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <FieldGroup>
          {formError ? (
            <Alert variant="destructive" role="alert">
              <AlertDescription>{formError}</AlertDescription>
            </Alert>
          ) : null}
          <FormField label="Your name" htmlFor="name" error={errors.name}>
            <Input
              id="name"
              name="name"
              autoComplete="name"
              required
              aria-invalid={errors.name ? true : undefined}
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </FormField>
          <FormField label="Email" htmlFor="email" error={errors.email}>
            <Input
              id="email"
              name="email"
              type="email"
              inputMode="email"
              autoComplete="email"
              autoCapitalize="none"
              spellCheck={false}
              required
              aria-invalid={errors.email ? true : undefined}
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </FormField>
          <FormField label="Password" htmlFor="password" error={errors.password} hint="At least 8 characters.">
            <PasswordInput
              id="password"
              name="password"
              autoComplete="new-password"
              required
              aria-invalid={errors.password ? true : undefined}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </FormField>
          <Button type="submit" size="lg" disabled={pending}>
            {pending ? <Spinner data-icon="inline-start" /> : null}
            {pending ? 'Creating account…' : 'Create account'}
          </Button>
        </FieldGroup>
      </form>

      <p className="text-sm text-muted-foreground">
        Already have an account?{' '}
        <Link href="/login" className="font-medium text-primary underline-offset-4 hover:underline">
          Log in
        </Link>
      </p>
    </div>
  )
}
