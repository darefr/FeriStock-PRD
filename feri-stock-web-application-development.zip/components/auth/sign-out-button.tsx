'use client'

import { LogOutIcon } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useState, type ComponentProps } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { authClient } from '@/lib/auth-client'

export function useSignOut() {
  const router = useRouter()
  const [pending, setPending] = useState(false)

  async function signOut() {
    setPending(true)
    const result = await authClient.signOut().catch(() => null)
    if (!result || result.error) {
      setPending(false)
      toast.error('Could not log out. Check your connection and try again.')
      return
    }
    router.replace('/login')
    router.refresh()
  }

  return { signOut, pending }
}

export function SignOutButton(props: Omit<ComponentProps<typeof Button>, 'onClick'>) {
  const { signOut, pending } = useSignOut()
  return (
    <Button type="button" variant="ghost" disabled={pending} onClick={signOut} {...props}>
      <LogOutIcon data-icon="inline-start" />
      Log out
    </Button>
  )
}
