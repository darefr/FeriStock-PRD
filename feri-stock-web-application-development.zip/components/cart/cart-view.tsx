'use client'

import { SendIcon, ShoppingCartIcon, Trash2Icon } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { EmptyState } from '@/components/app/empty-state'
import { Money } from '@/components/app/money'
import { QtyStepper } from '@/components/app/qty-stepper'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Spinner } from '@/components/ui/spinner'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { useCartQuantities } from '@/hooks/use-cart-qty'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import { placeOrderAction } from '@/lib/actions/orders'
import { DELIVERY_MODE_LABEL } from '@/lib/constants'
import type { CartDto, CartGroupDto } from '@/lib/domain/cart'
import { formatNpr, nextTier, unitPriceForQty } from '@/lib/money'

type CartEditor = ReturnType<typeof useCartQuantities>

function SupplierOrder({ group, cart, canOrder }: { group: CartGroupDto; cart: CartEditor; canOrder: boolean }) {
  const router = useRouter()
  const [note, setNote] = useState('')
  const [requestCredit, setRequestCredit] = useState(false)
  const place = useAction(placeOrderAction, {
    onSuccess: ({ orderId }) => {
      void refreshNavBadges()
      router.push(`/app/orders/${orderId}`)
    },
    success: ({ orderNo }) => `Purchase order ${orderNo} sent to ${group.supplier.name}.`,
  })

  // Totals follow the quantities on screen, priced with the same bulk rates the server applies.
  const lines = group.lines
    .map((line) => {
      const qty = cart.qtyOf(line.productId, line.qty)
      const unitPricePaisa = unitPriceForQty(line.basePricePaisa, line.tiers, qty)
      const editing = cart.isSaving(line.productId)
      const issue = editing ? (qty < line.moq ? `Minimum order is ${line.moq} ${line.unit}.` : null) : line.issue
      return { ...line, qty, unitPricePaisa, lineTotalPaisa: unitPricePaisa * qty, upgrade: nextTier(line.tiers, qty), issue }
    })
    .filter((line) => line.qty > 0)

  const subtotal = lines.reduce((sum, line) => sum + line.lineTotalPaisa, 0)
  const { supplier } = group
  const belowMinimum = supplier.minOrderPaisa > 0 && subtotal < supplier.minOrderPaisa
  const saving = group.lines.some((line) => cart.isSaving(line.productId))
  const blocked = belowMinimum || lines.some((line) => line.issue !== null)

  if (lines.length === 0) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <Link
            href={`/app/suppliers/${supplier.id}`}
            className="rounded-sm underline-offset-4 outline-none hover:underline focus-visible:ring-3 focus-visible:ring-ring/50"
          >
            {supplier.name}
          </Link>
        </CardTitle>
        <CardDescription>
          {supplier.city}
          {supplier.deliveryModes.length > 0
            ? ` · ${supplier.deliveryModes.map((mode) => DELIVERY_MODE_LABEL[mode]).join(', ')}`
            : ''}
        </CardDescription>
      </CardHeader>

      <CardContent className="flex flex-col gap-5">
        <ul className="flex flex-col divide-y">
          {lines.map((line) => (
            <li key={line.productId} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 flex-col gap-0.5">
                  <span className="text-pretty text-sm font-medium">{line.name}</span>
                  <span className="text-xs text-muted-foreground">
                    <span className="figures">{line.sku}</span> · <Money paisa={line.unitPricePaisa} /> / {line.unit}
                    {line.unitPricePaisa < line.basePricePaisa ? (
                      <>
                        {' '}
                        <s className="figures">{formatNpr(line.basePricePaisa)}</s>
                      </>
                    ) : null}
                  </span>
                </div>
                <Money paisa={line.lineTotalPaisa} className="text-sm font-medium" />
              </div>

              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <QtyStepper
                    label={line.name}
                    value={line.qty}
                    disabled={!canOrder}
                    onChange={(next) => cart.setQty(line.productId, next)}
                  />
                  <span className="text-sm text-muted-foreground">{line.unit}</span>
                </div>
                {canOrder ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label={`Remove ${line.name} from the cart`}
                    onClick={() => cart.setQty(line.productId, 0)}
                  >
                    <Trash2Icon />
                  </Button>
                ) : null}
              </div>

              {line.issue ? (
                <p className="text-xs text-destructive" role="status">
                  {line.issue}
                </p>
              ) : line.upgrade ? (
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Order <span className="figures">{line.upgrade.minQty - line.qty}</span> more for{' '}
                  <Money paisa={line.upgrade.pricePaisa} /> each.
                </p>
              ) : null}
              {line.schemeNote ? (
                <p className="text-xs leading-relaxed text-warning-foreground">{line.schemeNote}</p>
              ) : null}
            </li>
          ))}
        </ul>

        {supplier.deliveryNote ? (
          <p className="rounded-lg bg-muted px-3 py-2 text-sm leading-relaxed text-muted-foreground">
            {supplier.deliveryNote}
          </p>
        ) : null}

        {canOrder ? (
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor={`note-${supplier.id}`}>
                Note to supplier <span className="font-normal text-muted-foreground">(optional)</span>
              </FieldLabel>
              <Textarea
                id={`note-${supplier.id}`}
                rows={2}
                maxLength={500}
                placeholder="e.g. Deliver before Friday, call on arrival."
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </Field>
            {supplier.creditEnabled ? (
              <Field orientation="horizontal">
                <Checkbox
                  id={`credit-${supplier.id}`}
                  checked={requestCredit}
                  onCheckedChange={(checked) => setRequestCredit(checked === true)}
                />
                <FieldContent>
                  <FieldLabel htmlFor={`credit-${supplier.id}`}>Ask to buy on udharo</FieldLabel>
                  <FieldDescription>
                    {supplier.name} usually gives {supplier.creditDays} days. They approve the request and set the due
                    date when they accept the order.
                  </FieldDescription>
                </FieldContent>
              </Field>
            ) : null}
          </FieldGroup>
        ) : null}
      </CardContent>

      <CardFooter className="flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-col">
          <span className="text-sm text-muted-foreground">Order total</span>
          <Money paisa={subtotal} className="text-lg font-semibold" />
          {belowMinimum ? (
            <span className="text-xs text-destructive" role="status">
              {supplier.name} takes orders of {formatNpr(supplier.minOrderPaisa)} or more.
            </span>
          ) : null}
        </div>
        {canOrder ? (
          <Button
            type="button"
            size="lg"
            disabled={blocked || saving || place.pending}
            onClick={() => void place.run({ supplierOrgId: supplier.id, note, requestCredit })}
          >
            {place.pending || saving ? <Spinner data-icon="inline-start" /> : <SendIcon data-icon="inline-start" />}
            Send purchase order
          </Button>
        ) : null}
      </CardFooter>
    </Card>
  )
}

export function CartView({ cart: data, canOrder }: { cart: CartDto; canOrder: boolean }) {
  const cart = useCartQuantities()
  const hasLines = data.groups.some((group) => group.lines.some((line) => cart.qtyOf(line.productId, line.qty) > 0))

  if (!hasLines) {
    return (
      <EmptyState
        icon={ShoppingCartIcon}
        title="Your cart is empty"
        description="Add low-stock items from your inventory in one tap, or pick products from a supplier's catalog."
      >
        <div className="flex flex-wrap justify-center gap-2">
          <Button nativeButton={false} render={<Link href="/app/inventory?filter=attention" />}>
            Items to restock
          </Button>
          <Button variant="outline" nativeButton={false} render={<Link href="/app/suppliers" />}>
            Browse suppliers
          </Button>
        </div>
      </EmptyState>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      {data.groups.map((group) => (
        <SupplierOrder key={group.supplier.id} group={group} cart={cart} canOrder={canOrder} />
      ))}
    </div>
  )
}
