import { ChevronRightIcon, NotebookTextIcon } from 'lucide-react'
import Link from 'next/link'
import { EmptyState } from '@/components/app/empty-state'
import { Money } from '@/components/app/money'
import { Stat } from '@/components/app/stat'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatDateString } from '@/lib/dates'
import type { Ledger, LedgerRow } from '@/lib/domain/dashboard'
import type { OrderSide } from '@/lib/domain/order-rules'
import { pluralize } from '@/lib/format'

function DueBadge({ row }: { row: LedgerRow }) {
  if (row.creditState === 'requested') return <Badge variant="warning">Udharo requested</Badge>
  if (row.daysUntilDue === null || !row.dueDate) return <Badge variant="outline">Due now</Badge>
  if (row.overdue) return <Badge variant="destructive">{pluralize(-row.daysUntilDue, 'day')} overdue</Badge>
  if (row.daysUntilDue === 0) return <Badge variant="warning">Due today</Badge>
  return <Badge variant="secondary">Due in {pluralize(row.daysUntilDue, 'day')}</Badge>
}

/** Money owed on accepted orders, from one side: what the shop owes, or what the supplier is owed. */
export function LedgerSection({ ledger, side }: { ledger: Ledger; side: OrderSide }) {
  const owing = side === 'retailer'

  if (ledger.rows.length === 0) {
    return (
      <EmptyState
        icon={NotebookTextIcon}
        title={owing ? 'You owe nothing' : 'Nothing is owed to you'}
        description={
          owing
            ? 'Every accepted order is paid in full. Unpaid balances and udharo due dates appear here.'
            : 'Every accepted order is paid in full. Unpaid balances and udharo you have approved appear here.'
        }
      />
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
        <Stat
          label={owing ? 'Total to pay' : 'Total to collect'}
          value={<Money paisa={ledger.totals.balancePaisa} />}
          hint={pluralize(ledger.rows.length, 'order')}
        />
        <Stat
          label="On udharo"
          value={<Money paisa={ledger.totals.onCreditPaisa} />}
          hint="Approved credit with a due date"
        />
        <Stat
          label="Overdue"
          value={<Money paisa={ledger.totals.overduePaisa} />}
          hint={ledger.totals.overdueCount > 0 ? pluralize(ledger.totals.overdueCount, 'order') : 'Nothing overdue'}
          tone={ledger.totals.overdueCount > 0 ? 'danger' : 'default'}
        />
      </div>

      {ledger.parties.length > 1 ? (
        <Card>
          <CardHeader>
            <CardTitle>{owing ? 'By supplier' : 'By shop'}</CardTitle>
            <CardDescription>Largest balance first.</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="flex flex-col divide-y">
              {ledger.parties.map((party) => (
                <li key={party.id} className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
                  <div className="flex min-w-0 flex-col">
                    <span className="truncate text-sm font-medium">{party.name}</span>
                    <span className="text-xs text-muted-foreground">{pluralize(party.orders, 'order')}</span>
                  </div>
                  <div className="flex shrink-0 flex-col items-end">
                    <Money paisa={party.balancePaisa} className="text-sm font-medium" />
                    {party.overduePaisa > 0 ? (
                      <span className="text-xs text-destructive">
                        <Money paisa={party.overduePaisa} /> overdue
                      </span>
                    ) : null}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}

      <ul className="flex flex-col gap-2">
        {ledger.rows.map((row) => (
          <li key={row.orderId}>
            <Link
              href={`/app/orders/${row.orderId}`}
              className="flex items-center gap-3 rounded-lg border bg-card px-3 py-2.5 outline-none transition-colors hover:bg-accent/50 focus-visible:ring-3 focus-visible:ring-ring/50"
            >
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <span className="flex flex-wrap items-center gap-2">
                  <span className="figures text-sm font-medium">{row.orderNo}</span>
                  <DueBadge row={row} />
                </span>
                <span className="truncate text-xs text-muted-foreground">
                  {row.counterparty.name}
                  {row.dueDate ? ` · due ${formatDateString(row.dueDate)}` : ''}
                  {row.paidPaisa > 0 ? ' · part paid' : ''}
                </span>
              </div>
              <div className="flex shrink-0 flex-col items-end">
                <Money paisa={row.balancePaisa} className="text-sm font-medium" />
                <span className="text-xs text-muted-foreground">
                  of <Money paisa={row.totalPaisa} />
                </span>
              </div>
              <ChevronRightIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
