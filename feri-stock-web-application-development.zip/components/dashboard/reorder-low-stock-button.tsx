'use client'

import { ShoppingCartIcon } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { ComponentProps } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import { reorderToCartAction } from '@/lib/actions/inventory'
import { pluralize } from '@/lib/format'

/** One tap: every low or out-of-stock item goes into the cart at its restock quantity, grouped by supplier. */
export function ReorderLowStockButton({
  label = 'Reorder low stock',
  ...props
}: { label?: string } & Omit<ComponentProps<typeof Button>, 'onClick' | 'children'>) {
  const router = useRouter()
  const reorder = useAction(reorderToCartAction, {
    onSuccess: ({ added }) => {
      void refreshNavBadges()
      if (added === 0) {
        toast.info('Nothing to add. Low items need a supplier product and auto-reorder switched on.')
        return
      }
      toast.success(`${pluralize(added, 'item')} added to your cart.`)
      router.push('/app/cart')
    },
  })

  return (
    <Button
      type="button"
      {...props}
      disabled={reorder.pending || props.disabled}
      onClick={() => void reorder.run({ inventoryIds: null })}
    >
      {reorder.pending ? <Spinner data-icon="inline-start" /> : <ShoppingCartIcon data-icon="inline-start" />}
      {label}
    </Button>
  )
}
