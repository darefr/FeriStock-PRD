import { ArrowRightIcon, ChevronRightIcon, CircleCheckIcon } from 'lucide-react'
import Link from 'next/link'
import { Money } from '@/components/app/money'
import { Stat } from '@/components/app/stat'
import { OrderList } from '@/components/orders/order-list'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatDateString } from '@/lib/dates'
import type { SupplierOverview } from '@/lib/domain/dashboard'
import { GettingStarted } from './getting-started'
import { SalesChart } from './sales-chart'

export function SupplierOverviewSection({ data }: { data: SupplierOverview }) {
  const inbox = [
    { label: 'New orders to review', count: data.pipeline.pending, href: '/app/sales?status=new' },
    { label: 'Payments to confirm', count: data.proofsToConfirm, href: '/app/sales?status=payments' },
    { label: 'Udharo requests to decide', count: data.creditRequests, href: '/app/sales?status=credit' },
    { label: 'Quote requests to answer', count: data.quotesToAnswer, href: '/app/quotes' },
  ].filter((row) => row.count > 0)

  const salesTotal = data.sales.reduce((sum, day) => sum + day.totalPaisa, 0)
  const isNew = data.catalog.active + data.catalog.inactive === 0

  return (
    <div className="flex flex-col gap-4">
      {isNew ? (
        <GettingStarted
          title="Open for orders"
          description="Shops can order from you as soon as your catalog and terms are in place."
          steps={[
            {
              title: 'Add your products',
              description: 'SKU, unit, wholesale price, bulk rates, schemes and minimum order quantity.',
              href: '/app/catalog',
              done: false,
            },
            {
              title: 'Set delivery and credit terms',
              description: 'Own van, transport bilti or pickup, and whether you sell on udharo.',
              href: '/app/settings/selling',
              done: false,
            },
            {
              title: 'Add how you get paid',
              description: 'Your own eSewa or Khalti merchant account, bank details or a payment QR.',
              href: '/app/settings/payments',
              done: false,
            },
          ]}
        />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Waiting on you</CardTitle>
            <CardDescription>Work that buyers are waiting for.</CardDescription>
          </CardHeader>
          <CardContent>
            {inbox.length > 0 ? (
              <ul className="flex flex-col gap-2">
                {inbox.map((row) => (
                  <li key={row.label}>
                    <Link
                      href={row.href}
                      className="flex items-center gap-3 rounded-lg border bg-background px-3 py-2.5 outline-none transition-colors hover:bg-accent/60 focus-visible:ring-3 focus-visible:ring-ring/50"
                    >
                      <Badge variant="warning" className="figures">
                        {row.count}
                      </Badge>
                      <span className="flex-1 text-sm font-medium">{row.label}</span>
                      <ChevronRightIcon className="size-4 text-muted-foreground" aria-hidden="true" />
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="flex items-center gap-2 text-sm leading-relaxed text-muted-foreground">
                <CircleCheckIcon className="size-4 text-success" aria-hidden="true" />
                You are all caught up.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="To pack" value={data.pipeline.accepted} hint="Accepted orders" href="/app/sales?status=pack" />
        <Stat label="To dispatch" value={data.pipeline.packed} hint="Packed and waiting" href="/app/sales?status=dispatch" />
        <Stat label="On the way" value={data.pipeline.dispatched} hint="With van or transport" href="/app/sales?status=transit" />
        <Stat
          label="Owed to you"
          value={<Money paisa={data.receivables.balancePaisa} />}
          hint={
            data.receivables.overdueCount > 0 ? (
              <>
                <Money paisa={data.receivables.overduePaisa} /> overdue
              </>
            ) : (
              'Nothing overdue'
            )
          }
          tone={data.receivables.overdueCount > 0 ? 'danger' : 'default'}
          href="/app/udharo"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Accepted orders</CardTitle>
            <CardDescription>
              Last 14 days · <Money paisa={salesTotal} className="font-medium text-foreground" />
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SalesChart
              data={data.sales.map((day) => ({
                label: formatDateString(day.date).replace(/ \d{4}$/, ''),
                rupees: Math.round(day.totalPaisa / 100),
                orders: day.orders,
              }))}
            />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Top products</CardTitle>
            <CardDescription>By order value, last 30 days.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topProducts.length > 0 ? (
              <ul className="flex flex-col divide-y">
                {data.topProducts.map((product) => (
                  <li
                    key={`${product.name}-${product.unit}`}
                    className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0"
                  >
                    <div className="flex min-w-0 flex-col">
                      <span className="truncate text-sm font-medium">{product.name}</span>
                      <span className="figures text-xs text-muted-foreground">
                        {product.qty} {product.unit}
                      </span>
                    </div>
                    <Money paisa={product.totalPaisa} className="text-sm" />
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm leading-relaxed text-muted-foreground">
                Your best sellers appear here once orders are accepted.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {data.newOrders.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>New orders</CardTitle>
            <CardDescription>Review and accept to confirm quantities and prices to the buyer.</CardDescription>
            <CardAction>
              <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/app/sales?status=new" />}>
                View all
                <ArrowRightIcon data-icon="inline-end" />
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent>
            <OrderList orders={data.newOrders} />
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
