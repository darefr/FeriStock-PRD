import { ArrowRightIcon, CalendarClockIcon, CircleCheckIcon, TriangleAlertIcon } from 'lucide-react'
import Link from 'next/link'
import { Money } from '@/components/app/money'
import { Stat } from '@/components/app/stat'
import { StockStatusBadge } from '@/components/app/status-badges'
import { OrderList } from '@/components/orders/order-list'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { formatShortDateTime } from '@/lib/dates'
import type { RetailerOverview } from '@/lib/domain/dashboard'
import { pluralize } from '@/lib/format'
import { GettingStarted } from './getting-started'
import { ReorderLowStockButton } from './reorder-low-stock-button'

export function RetailerOverviewSection({ data, canOrder }: { data: RetailerOverview; canOrder: boolean }) {
  const attention = data.stock.low + data.stock.out

  return (
    <div className="flex flex-col gap-4">
      {data.stock.tracked === 0 ? (
        <GettingStarted
          title="Set up your shop"
          description="Three steps and your restocking runs from here instead of phone calls and notebooks."
          steps={[
            {
              title: 'Find your wholesalers',
              description: 'Browse suppliers, their prices, bulk rates and delivery terms.',
              href: '/app/suppliers',
              done: false,
            },
            {
              title: 'Add the items you stock',
              description: 'Set a reorder level for each item and count stock up and down as you sell.',
              href: '/app/inventory',
              done: false,
            },
            {
              title: 'Send your first purchase order',
              description: 'Low items go into a cart grouped by supplier, ready to send in one tap.',
              href: '/app/cart',
              done: false,
            },
          ]}
        />
      ) : attention > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TriangleAlertIcon className="size-4 text-warning-foreground" aria-hidden="true" />
              {pluralize(attention, 'item')} to restock
            </CardTitle>
            <CardDescription>
              {data.stock.out > 0 ? `${data.stock.out} out of stock` : null}
              {data.stock.out > 0 && data.stock.low > 0 ? ', ' : null}
              {data.stock.low > 0 ? `${data.stock.low} running low` : null}
            </CardDescription>
            <CardAction>
              <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/app/inventory?filter=attention" />}>
                View all
                <ArrowRightIcon data-icon="inline-end" />
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent>
            <ul className="flex flex-col divide-y">
              {data.needsRestock.map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
                  <div className="flex min-w-0 flex-col">
                    <span className="truncate text-sm font-medium">{item.name}</span>
                    <span className="truncate text-xs text-muted-foreground">
                      {item.supplier?.name ?? 'No supplier linked'}
                    </span>
                  </div>
                  <div className="flex shrink-0 items-center gap-3">
                    <span className="figures text-sm">
                      {item.currentQty}{' '}
                      <span className="text-muted-foreground">
                        {item.unit} left
                      </span>
                    </span>
                    <StockStatusBadge status={item.status} />
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
          {canOrder ? (
            <CardFooter className="justify-end">
              <ReorderLowStockButton label="Add low stock to cart" />
            </CardFooter>
          ) : null}
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CircleCheckIcon className="size-4 text-success" aria-hidden="true" />
              Stock is healthy
            </CardTitle>
            <CardDescription>
              All {pluralize(data.stock.tracked, 'tracked item')} are above their reorder level.
            </CardDescription>
            <CardAction>
              <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/app/inventory" />}>
                Open inventory
                <ArrowRightIcon data-icon="inline-end" />
              </Button>
            </CardAction>
          </CardHeader>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Awaiting supplier"
          value={data.orders.awaitingSupplier}
          hint="Sent, not yet accepted"
          href="/app/purchases?status=open"
        />
        <Stat
          label="Being prepared"
          value={data.orders.beingPrepared}
          hint="Accepted or packed"
          href="/app/purchases?status=open"
        />
        <Stat
          label="On the way"
          value={data.orders.inTransit}
          hint="Confirm delivery on arrival"
          tone={data.orders.inTransit > 0 ? 'success' : 'default'}
          href="/app/purchases?status=transit"
        />
        <Stat
          label="To pay suppliers"
          value={<Money paisa={data.dues.balancePaisa} />}
          hint={
            data.dues.overdueCount > 0 ? (
              <>
                <Money paisa={data.dues.overduePaisa} /> overdue
              </>
            ) : (
              'Nothing overdue'
            )
          }
          tone={data.dues.overdueCount > 0 ? 'danger' : 'default'}
          href="/app/udharo"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Arriving</CardTitle>
            <CardDescription>Dispatched orders. Confirm delivery to add the goods to your stock.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.incoming.length > 0 ? (
              <OrderList orders={data.incoming} />
            ) : (
              <p className="text-sm leading-relaxed text-muted-foreground">Nothing is on the way right now.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Scheduled restocks</CardTitle>
            <CardDescription>Repeat orders that create a draft or send automatically.</CardDescription>
            <CardAction>
              <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/app/schedules" />}>
                Manage
                <ArrowRightIcon data-icon="inline-end" />
              </Button>
            </CardAction>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {data.nextSchedule ? (
              <div className="flex items-start gap-3">
                <CalendarClockIcon className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                <div className="flex min-w-0 flex-col">
                  <span className="text-sm font-medium">{data.nextSchedule.name}</span>
                  <span className="text-sm leading-relaxed text-muted-foreground">
                    {data.nextSchedule.supplierName} · next on {formatShortDateTime(data.nextSchedule.nextRunAt)}
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-sm leading-relaxed text-muted-foreground">
                No schedule yet. Set one up for items you buy every week or month.
              </p>
            )}
            {data.orders.drafts > 0 ? (
              <Button variant="outline" size="sm" className="w-fit" nativeButton={false} render={<Link href="/app/purchases?status=draft" />}>
                Review {pluralize(data.orders.drafts, 'draft order')}
                <ArrowRightIcon data-icon="inline-end" />
              </Button>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
