'use client'

import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts'
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart'
import { formatAmount } from '@/lib/money'
import { pluralize } from '@/lib/format'

export type SalesPoint = { label: string; rupees: number; orders: number }

const config = {
  rupees: { label: 'Accepted orders', color: 'var(--chart-1)' },
} satisfies ChartConfig

/** Rupee axis in the units traders speak in: thousands and lakhs. */
function compactRupees(value: number): string {
  if (value >= 100_000) return `${Number((value / 100_000).toFixed(1))}L`
  if (value >= 1000) return `${Number((value / 1000).toFixed(1))}k`
  return String(value)
}

export function SalesChart({ data }: { data: SalesPoint[] }) {
  return (
    <ChartContainer config={config} className="aspect-auto h-52 w-full">
      <BarChart accessibilityLayer data={data} margin={{ top: 8, right: 4, bottom: 0, left: 0 }}>
        <CartesianGrid vertical={false} />
        <XAxis dataKey="label" tickLine={false} axisLine={false} tickMargin={8} minTickGap={18} />
        <YAxis tickLine={false} axisLine={false} width={40} tickFormatter={compactRupees} allowDecimals={false} />
        <ChartTooltip
          cursor={false}
          content={
            <ChartTooltipContent
              formatter={(value, _name, item) => (
                <div className="flex w-full flex-col gap-0.5">
                  <span className="figures font-medium text-foreground">Rs. {formatAmount(Number(value) * 100)}</span>
                  <span className="text-muted-foreground">
                    {pluralize((item.payload as SalesPoint).orders, 'order')} accepted
                  </span>
                </div>
              )}
            />
          }
        />
        <Bar dataKey="rupees" fill="var(--color-rupees)" radius={[3, 3, 0, 0]} maxBarSize={28} />
      </BarChart>
    </ChartContainer>
  )
}
