import { ArrowRightIcon, CheckIcon } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'

export type SetupStep = { title: string; description: string; href: string; done: boolean }

/** First-run checklist. The steps are a real sequence: each one makes the next possible. */
export function GettingStarted({ title, description, steps }: { title: string; description: string; steps: SetupStep[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <ol className="flex flex-col gap-2">
          {steps.map((step, index) => (
            <li key={step.href}>
              <Link
                href={step.href}
                className="flex items-center gap-3 rounded-lg border bg-background p-3 outline-none transition-colors hover:bg-accent/60 focus-visible:ring-3 focus-visible:ring-ring/50"
              >
                <span
                  className={cn(
                    'figures flex size-7 shrink-0 items-center justify-center rounded-full text-sm font-semibold',
                    step.done ? 'bg-success/12 text-success' : 'bg-primary text-primary-foreground',
                  )}
                >
                  {step.done ? <CheckIcon className="size-4" aria-label="Done" /> : index + 1}
                </span>
                <span className="flex min-w-0 flex-1 flex-col">
                  <span className="text-sm font-medium">{step.title}</span>
                  <span className="text-sm leading-relaxed text-muted-foreground">{step.description}</span>
                </span>
                <ArrowRightIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              </Link>
            </li>
          ))}
        </ol>
      </CardContent>
    </Card>
  )
}
