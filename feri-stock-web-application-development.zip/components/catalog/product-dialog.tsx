'use client'

import { PlusIcon, Trash2Icon } from 'lucide-react'
import { useRef, useState } from 'react'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { RupeeInput } from '@/components/app/rupee-input'
import { Button } from '@/components/ui/button'
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSet,
} from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { saveProductAction } from '@/lib/actions/catalog'
import { COMMON_UNITS, LIMITS } from '@/lib/constants'
import type { ProductDto } from '@/lib/domain/catalog'
import { paisaToRupeeString, parseRupees } from '@/lib/money'
import { fieldErrors, productSchema, type ProductInput } from '@/lib/validation'

type TierDraft = { key: number; minQty: string; price: string }

/** Create a product, or edit one when `product` is given. Mount it fresh for each product (use a `key`). */
export function ProductDialog({ product, onClose }: { product: ProductDto | null; onClose: () => void }) {
  const [sku, setSku] = useState(product?.sku ?? '')
  const [name, setName] = useState(product?.name ?? '')
  const [unit, setUnit] = useState(product?.unit ?? '')
  const [category, setCategory] = useState(product?.category ?? '')
  const [price, setPrice] = useState(product ? paisaToRupeeString(product.pricePaisa) : '')
  const [moq, setMoq] = useState(String(product?.moq ?? 1))
  const [schemeNote, setSchemeNote] = useState(product?.schemeNote ?? '')
  const [isActive, setIsActive] = useState(product?.isActive ?? true)
  const [tiers, setTiers] = useState<TierDraft[]>(() =>
    (product?.bulkTiers ?? []).map((tier, index) => ({
      key: index,
      minQty: String(tier.minQty),
      price: paisaToRupeeString(tier.pricePaisa),
    })),
  )
  const nextTierKey = useRef(tiers.length)
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})

  const save = useAction((input: ProductInput) => saveProductAction(product?.id ?? null, input), {
    success: product ? 'Product updated.' : 'Product added to your catalog.',
    onSuccess: onClose,
  })
  const errors = { ...save.fields, ...localErrors }
  const tierError = Object.entries(errors).find(([key]) => key.startsWith('bulkTiers'))?.[1]

  function handleSubmit() {
    const parsed = productSchema.safeParse({
      sku,
      name,
      unit,
      category,
      pricePaisa: parseRupees(price) ?? 0,
      moq: toInt(moq),
      schemeNote,
      bulkTiers: tiers.map((tier) => ({ minQty: toInt(tier.minQty), pricePaisa: parseRupees(tier.price) ?? 0 })),
      isActive,
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  const updateTier = (key: number, patch: Partial<TierDraft>) =>
    setTiers((current) => current.map((tier) => (tier.key === key ? { ...tier, ...patch } : tier)))

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={product ? 'Edit product' : 'Add a product'}
      description="Shops see this in your catalog and order at these prices."
      onSubmit={handleSubmit}
      submitLabel={product ? 'Save product' : 'Add product'}
      pending={save.pending}
    >
      <FieldGroup>
        <FormField label="Product name" htmlFor="product-name" error={errors.name}>
          <Input
            id="product-name"
            autoComplete="off"
            placeholder="e.g. Wai Wai Chicken Noodles 75g"
            aria-invalid={errors.name ? true : undefined}
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </FormField>

        <div className="grid gap-5 sm:grid-cols-2">
          <FormField label="SKU" htmlFor="product-sku" error={errors.sku} hint="Your own code for this item.">
            <Input
              id="product-sku"
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              className="figures uppercase"
              placeholder="WW-CHK-75"
              aria-invalid={errors.sku ? true : undefined}
              value={sku}
              onChange={(event) => setSku(event.target.value.slice(0, 40))}
            />
          </FormField>
          <FormField label="Category" htmlFor="product-category" optional error={errors.category}>
            <Input
              id="product-category"
              autoComplete="off"
              placeholder="e.g. Noodles"
              value={category}
              onChange={(event) => setCategory(event.target.value)}
            />
          </FormField>
        </div>

        <div className="grid gap-5 sm:grid-cols-3">
          <FormField label="Selling unit" htmlFor="product-unit" error={errors.unit}>
            <Input
              id="product-unit"
              list="product-units"
              autoComplete="off"
              placeholder="carton"
              aria-invalid={errors.unit ? true : undefined}
              value={unit}
              onChange={(event) => setUnit(event.target.value.slice(0, 20))}
            />
            <datalist id="product-units">
              {COMMON_UNITS.map((option) => (
                <option key={option} value={option} />
              ))}
            </datalist>
          </FormField>
          <FormField label="Price per unit" htmlFor="product-price" error={errors.pricePaisa}>
            <RupeeInput
              id="product-price"
              aria-invalid={errors.pricePaisa ? true : undefined}
              value={price}
              onValueChange={setPrice}
            />
          </FormField>
          <FormField label="Minimum order" htmlFor="product-moq" error={errors.moq}>
            <DigitsInput
              id="product-moq"
              aria-invalid={errors.moq ? true : undefined}
              value={moq}
              onValueChange={setMoq}
            />
          </FormField>
        </div>

        <FieldSet>
          <FieldLegend variant="label">Bulk rates</FieldLegend>
          <FieldDescription>
            A lower price per unit once an order reaches a quantity. Applied automatically in the buyer&apos;s cart.
          </FieldDescription>
          {tiers.length > 0 ? (
            <ul className="flex flex-col gap-2">
              {tiers.map((tier, index) => (
                <li key={tier.key} className="grid grid-cols-[1fr_1fr_auto] items-end gap-2">
                  <Field>
                    <FieldLabel htmlFor={`tier-qty-${tier.key}`} className={index > 0 ? 'sr-only' : undefined}>
                      From quantity
                    </FieldLabel>
                    <DigitsInput
                      id={`tier-qty-${tier.key}`}
                      placeholder="50"
                      value={tier.minQty}
                      onValueChange={(minQty) => updateTier(tier.key, { minQty })}
                    />
                  </Field>
                  <Field>
                    <FieldLabel htmlFor={`tier-price-${tier.key}`} className={index > 0 ? 'sr-only' : undefined}>
                      Price per unit
                    </FieldLabel>
                    <RupeeInput
                      id={`tier-price-${tier.key}`}
                      value={tier.price}
                      onValueChange={(next) => updateTier(tier.key, { price: next })}
                    />
                  </Field>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label={`Remove bulk rate ${index + 1}`}
                    onClick={() => setTiers((current) => current.filter((row) => row.key !== tier.key))}
                  >
                    <Trash2Icon />
                  </Button>
                </li>
              ))}
            </ul>
          ) : null}
          {tierError ? <FieldError>{tierError}</FieldError> : null}
          {tiers.length < LIMITS.maxBulkTiers ? (
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="w-fit"
              onClick={() => {
                nextTierKey.current += 1
                setTiers((current) => [...current, { key: nextTierKey.current, minQty: '', price: '' }])
              }}
            >
              <PlusIcon data-icon="inline-start" />
              Add bulk rate
            </Button>
          ) : null}
        </FieldSet>

        <FormField
          label="Scheme or offer"
          htmlFor="product-scheme"
          optional
          error={errors.schemeNote}
          hint="Shown to buyers next to the product."
        >
          <Textarea
            id="product-scheme"
            rows={2}
            maxLength={240}
            placeholder="e.g. Buy 10 cartons, get 1 free until Dashain"
            value={schemeNote}
            onChange={(event) => setSchemeNote(event.target.value)}
          />
        </FormField>

        <Field orientation="horizontal">
          <FieldContent>
            <FieldLabel htmlFor="product-active">Available to order</FieldLabel>
            <FieldDescription>Switch off to hide it from shops without deleting it.</FieldDescription>
          </FieldContent>
          <Switch id="product-active" checked={isActive} onCheckedChange={setIsActive} />
        </Field>
      </FieldGroup>
    </FormDialog>
  )
}
