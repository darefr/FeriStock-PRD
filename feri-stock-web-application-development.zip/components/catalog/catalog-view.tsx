'use client'

import { PencilIcon, PlusIcon, TagsIcon } from 'lucide-react'
import { useState } from 'react'
import { EmptyState } from '@/components/app/empty-state'
import { FilterBar } from '@/components/app/filter-bar'
import { Money } from '@/components/app/money'
import { PageHeader } from '@/components/app/page-header'
import { SearchInput } from '@/components/app/search-input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { useAction } from '@/hooks/use-action'
import { setProductActiveAction } from '@/lib/actions/catalog'
import type { ProductDto } from '@/lib/domain/catalog'
import { pluralize } from '@/lib/format'
import { ProductDialog } from './product-dialog'

type Filter = 'all' | 'active' | 'hidden'

export function CatalogView({ products, canManage }: { products: ProductDto[]; canManage: boolean }) {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [editing, setEditing] = useState<ProductDto | 'new' | null>(null)
  const setActive = useAction(setProductActiveAction)

  const term = query.trim().toLowerCase()
  const visible = products.filter((product) => {
    if (filter === 'active' && !product.isActive) return false
    if (filter === 'hidden' && product.isActive) return false
    if (!term) return true
    return [product.name, product.sku, product.category ?? ''].some((value) => value.toLowerCase().includes(term))
  })
  const activeCount = products.filter((product) => product.isActive).length

  return (
    <>
      <PageHeader
        title="Catalog"
        description="The products, prices and bulk rates shops order from."
        actions={
          canManage ? (
            <Button onClick={() => setEditing('new')}>
              <PlusIcon data-icon="inline-start" />
              Add product
            </Button>
          ) : null
        }
      />

      {products.length === 0 ? (
        <EmptyState
          icon={TagsIcon}
          title="Your catalog is empty"
          description="Add the products you sell with their wholesale price. Shops can order as soon as the first one is in."
        >
          {canManage ? (
            <Button onClick={() => setEditing('new')}>
              <PlusIcon data-icon="inline-start" />
              Add your first product
            </Button>
          ) : null}
        </EmptyState>
      ) : (
        <>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <SearchInput
              label="Search products"
              placeholder="Search by name, SKU or category"
              value={query}
              onValueChange={setQuery}
              className="sm:max-w-xs"
            />
            <FilterBar
              label="Filter products"
              value={filter}
              onChange={setFilter}
              options={[
                { value: 'all', label: 'All', count: products.length },
                { value: 'active', label: 'Available', count: activeCount },
                { value: 'hidden', label: 'Hidden', count: products.length - activeCount },
              ]}
            />
          </div>

          {visible.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">No products match this search.</p>
          ) : (
            <ul className="flex flex-col gap-2">
              {visible.map((product) => {
                const lowestTier = product.bulkTiers.at(-1)
                return (
                  <li
                    key={product.id}
                    className="flex flex-col gap-3 rounded-lg border bg-card p-3 sm:flex-row sm:items-center sm:gap-4"
                  >
                    <div className="flex min-w-0 flex-1 flex-col gap-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-medium">{product.name}</span>
                        {product.isActive ? null : <Badge variant="outline">Hidden</Badge>}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        <span className="figures">{product.sku}</span>
                        {product.category ? ` · ${product.category}` : ''} · Minimum {product.moq} {product.unit}
                      </span>
                      {product.schemeNote ? (
                        <span className="text-xs leading-relaxed text-warning-foreground">{product.schemeNote}</span>
                      ) : null}
                    </div>
                    <div className="flex items-center justify-between gap-4 sm:justify-end">
                      <div className="flex flex-col sm:items-end">
                        <span className="text-sm">
                          <Money paisa={product.pricePaisa} className="font-medium" />{' '}
                          <span className="text-muted-foreground">/ {product.unit}</span>
                        </span>
                        {lowestTier ? (
                          <span className="text-xs text-muted-foreground">
                            {pluralize(product.bulkTiers.length, 'bulk rate')}, down to <Money paisa={lowestTier.pricePaisa} />
                          </span>
                        ) : null}
                      </div>
                      {canManage ? (
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={product.isActive}
                            disabled={setActive.pending}
                            aria-label={`${product.name} available to order`}
                            onCheckedChange={(isActive) => void setActive.run({ productId: product.id, isActive })}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            aria-label={`Edit ${product.name}`}
                            onClick={() => setEditing(product)}
                          >
                            <PencilIcon />
                          </Button>
                        </div>
                      ) : null}
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </>
      )}

      {editing ? (
        <ProductDialog
          key={editing === 'new' ? 'new' : editing.id}
          product={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
        />
      ) : null}
    </>
  )
}
