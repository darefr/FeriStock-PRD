'use client'

import { ChevronLeftIcon, CircleAlertIcon, CircleCheckIcon, PhoneIcon, ReceiptTextIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'
import useSWR from 'swr'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { Money } from '@/components/app/money'
import { Stamp } from '@/components/app/stamp'
import { OrderStatusBadge } from '@/components/app/status-badges'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import {
  cancelOrderAction,
  markDeliveredAction,
  markPackedAction,
  rejectOrderAction,
  submitDraftOrderAction,
} from '@/lib/actions/orders'
import { DELIVERY_MODE_LABEL, ORDER_TYPE_LABEL } from '@/lib/constants'
import { formatDateTime, formatShortDateTime } from '@/lib/dates'
import type { OrderAction } from '@/lib/domain/order-rules'
import type { OrderDetail } from '@/lib/domain/orders'
import { fetcher } from '@/lib/fetcher'
import { AcceptOrderDialog } from './accept-order-dialog'
import { ConfirmDeliveryDialog } from './confirm-delivery-dialog'
import { DispatchDialog } from './dispatch-dialog'
import { paymentStamp } from './order-labels'
import { OrderProgress } from './order-progress'
import { PayDialog } from './pay-dialog'
import { CreditDecisionDialog, RecordPaymentDialog } from './payment-dialogs'
import { PaymentsCard } from './payments-card'
import { ReasonDialog } from './reason-dialog'

export type OrderPermissions = { place: boolean; manage: boolean; fulfil: boolean; pay: boolean }

type DialogName =
  | 'accept'
  | 'reject'
  | 'cancel'
  | 'dispatch'
  | 'mark-delivered'
  | 'confirm-delivery'
  | 'pay'
  | 'record-payment'
  | 'credit'

const PAYMENT_NOTICE: Record<string, { tone: 'success' | 'info' | 'error'; title: string; body: string }> = {
  verified: {
    tone: 'success',
    title: 'Payment verified',
    body: 'The gateway confirmed the payment and the receipt has been issued.',
  },
  pending: {
    tone: 'info',
    title: 'Payment not completed yet',
    body: 'The gateway has not confirmed this payment. If you paid, use “Check with” on the payment below in a minute.',
  },
  failed: {
    tone: 'error',
    title: 'Payment did not go through',
    body: 'The gateway reports that the payment was cancelled or failed. Nothing was charged to this order.',
  },
  mismatch: {
    tone: 'error',
    title: 'Payment amount did not match',
    body: 'The amount reported by the gateway differs from this payment, so it was not accepted. Contact the supplier.',
  },
  unavailable: {
    tone: 'error',
    title: 'Could not reach the gateway',
    body: 'We could not check the payment just now. Use “Check with” on the payment below to try again.',
  },
}

function describeStep(order: OrderDetail): { title: string; body: string } {
  const synced = order.timestamps.stockSyncedAt !== null
  if (order.status === 'cancelled') return { title: 'Order cancelled', body: order.cancelReason ?? '' }
  if (order.status === 'rejected') return { title: 'Order rejected by the supplier', body: order.cancelReason ?? '' }

  if (order.viewerSide === 'retailer') {
    const supplier = order.supplier.name
    switch (order.status) {
      case 'draft':
        return {
          title: 'Draft from your restock schedule',
          body: 'Check the items, then send it. Prices are refreshed to today’s catalog when you send.',
        }
      case 'pending':
        return {
          title: `Waiting for ${supplier}`,
          body: 'They confirm the quantities and prices. You can withdraw the order until they accept it.',
        }
      case 'accepted':
        return { title: 'Accepted', body: `${supplier} is preparing your order.` }
      case 'packed':
        return { title: 'Packed', body: `${supplier} has packed your order and will dispatch it next.` }
      case 'dispatched':
        return { title: 'On the way', body: 'When the goods arrive, confirm delivery to add them to your stock.' }
      default:
        return synced
          ? { title: 'Delivered', body: 'Received and counted into your stock.' }
          : { title: 'Marked delivered by the supplier', body: 'Count the goods in to update your stock.' }
    }
  }

  const buyer = order.retailer.name
  switch (order.status) {
    case 'pending':
      return { title: 'New order to review', body: `Check the quantities and prices, then accept. ${buyer} is waiting.` }
    case 'accepted':
      return { title: 'Accepted', body: 'Pack the goods, then mark the order as packed.' }
    case 'packed':
      return { title: 'Packed', body: 'Record how it is going out: your van, a transport bilti or pickup.' }
    case 'dispatched':
      return {
        title: 'Dispatched',
        body: `${buyer} confirms delivery when the goods arrive. You can also close the delivery yourself.`,
      }
    default:
      return synced
        ? { title: 'Delivered', body: 'The shop received the goods and counted them into stock.' }
        : { title: 'Delivered', body: 'Waiting for the shop to count the goods into their stock.' }
  }
}

export function OrderView({
  initialOrder,
  permissions,
  paymentOutcome,
}: {
  initialOrder: OrderDetail
  permissions: OrderPermissions
  paymentOutcome: string | null
}) {
  // Polled so both parties see acceptance, dispatch and payments as they happen.
  const { data, mutate } = useSWR<{ order: OrderDetail }>(`/api/orders/${initialOrder.id}`, fetcher, {
    fallbackData: { order: initialOrder },
    refreshInterval: 15_000,
  })
  const order = data?.order ?? initialOrder
  const [dialog, setDialog] = useState<DialogName | null>(null)
  const close = () => setDialog(null)
  const refresh = () => {
    void mutate()
    void refreshNavBadges()
  }
  const settle = { onSuccess: refresh }

  const submitDraft = useAction(submitDraftOrderAction, { ...settle, success: 'Order sent to the supplier.' })
  const pack = useAction(markPackedAction, { ...settle, success: 'Marked as packed.' })
  const markDelivered = useAction(markDeliveredAction, {
    success: 'Marked as delivered.',
    onSuccess: () => {
      close()
      refresh()
    },
  })
  const reject = useAction(rejectOrderAction, {
    success: 'Order rejected.',
    onSuccess: () => {
      close()
      refresh()
    },
  })
  const cancel = useAction(cancelOrderAction, {
    success: 'Order cancelled.',
    onSuccess: () => {
      close()
      refresh()
    },
  })

  const isRetailer = order.viewerSide === 'retailer'
  const allowed: Record<OrderAction, boolean> = {
    submit_draft: permissions.place,
    cancel: isRetailer ? permissions.place : permissions.manage,
    accept: permissions.manage,
    reject: permissions.manage,
    pack: permissions.fulfil,
    dispatch: permissions.fulfil,
    mark_delivered: permissions.fulfil,
    confirm_delivery: permissions.fulfil,
    pay: permissions.pay,
    request_credit: permissions.pay,
    decide_credit: permissions.pay,
    record_payment: permissions.pay,
  }
  const can = (action: OrderAction) => order.actions.includes(action) && allowed[action]
  const fulfilmentActions: OrderAction[] = [
    'submit_draft',
    'accept',
    'reject',
    'pack',
    'dispatch',
    'mark_delivered',
    'confirm_delivery',
    'cancel',
  ]
  const stepBlocked = fulfilmentActions.some((action) => order.actions.includes(action) && !allowed[action])
  const hasStepButtons = fulfilmentActions.some(can)

  const step = describeStep(order)
  const closed = order.status === 'cancelled' || order.status === 'rejected'
  const stamp = paymentStamp(order)
  const notice = paymentOutcome ? PAYMENT_NOTICE[paymentOutcome] : undefined
  const back = isRetailer ? { href: '/app/purchases', label: 'Purchases' } : { href: '/app/sales', label: 'Sales orders' }
  const cancelCopy = isRetailer
    ? order.status === 'draft'
      ? { button: 'Discard draft', title: 'Discard this draft?', label: 'Why are you discarding it?' }
      : { button: 'Withdraw order', title: 'Withdraw this order?', label: 'Why are you withdrawing it?' }
    : { button: 'Cancel order', title: 'Cancel this order?', label: 'Why are you cancelling it?' }

  return (
    <>
      <header className="flex items-start justify-between gap-4">
        <div className="flex min-w-0 flex-col gap-1.5">
          <Link
            href={back.href}
            className="inline-flex w-fit items-center gap-1 rounded-sm text-sm text-muted-foreground outline-none hover:text-foreground focus-visible:ring-3 focus-visible:ring-ring/50"
          >
            <ChevronLeftIcon className="size-4" aria-hidden="true" />
            {back.label}
          </Link>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="figures text-2xl font-semibold tracking-tight">{order.orderNo}</h1>
            <OrderStatusBadge status={order.status} />
          </div>
          <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
            {isRetailer ? `To ${order.supplier.name}` : `From ${order.retailer.name}`} · {ORDER_TYPE_LABEL[order.orderType]} ·{' '}
            {formatDateTime(order.timestamps.placedAt ?? order.timestamps.createdAt)}
          </p>
        </div>
        {stamp ? (
          <Stamp tone={stamp.tone} detail={stamp.detail} className="mt-3 mr-1 shrink-0">
            {stamp.label}
          </Stamp>
        ) : null}
      </header>

      {notice ? (
        <Alert variant={notice.tone === 'error' ? 'destructive' : 'default'}>
          {notice.tone === 'success' ? <CircleCheckIcon className="text-success" /> : <CircleAlertIcon />}
          <AlertTitle>{notice.title}</AlertTitle>
          <AlertDescription>{notice.body}</AlertDescription>
        </Alert>
      ) : null}

      {order.status === 'draft' ? null : (
        <Card size="sm">
          <CardContent>
            <OrderProgress status={order.status} timestamps={order.timestamps} />
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="flex flex-col gap-4 lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>{step.title}</CardTitle>
              {step.body ? <CardDescription>{closed ? `Reason: ${step.body}` : step.body}</CardDescription> : null}
            </CardHeader>
            {hasStepButtons || stepBlocked ? (
              <CardFooter className="flex-wrap gap-2">
                {can('submit_draft') ? (
                  <Button type="button" disabled={submitDraft.pending} onClick={() => void submitDraft.run({ orderId: order.id })}>
                    {submitDraft.pending ? <Spinner data-icon="inline-start" /> : null}
                    Send to supplier
                  </Button>
                ) : null}
                {can('accept') ? (
                  <Button type="button" onClick={() => setDialog('accept')}>
                    Review and accept
                  </Button>
                ) : null}
                {can('pack') ? (
                  <Button type="button" disabled={pack.pending} onClick={() => void pack.run({ orderId: order.id })}>
                    {pack.pending ? <Spinner data-icon="inline-start" /> : null}
                    Mark as packed
                  </Button>
                ) : null}
                {can('dispatch') ? (
                  <Button type="button" onClick={() => setDialog('dispatch')}>
                    Record dispatch
                  </Button>
                ) : null}
                {can('confirm_delivery') ? (
                  <Button type="button" onClick={() => setDialog('confirm-delivery')}>
                    Confirm delivery
                  </Button>
                ) : null}
                {can('mark_delivered') ? (
                  <Button type="button" variant="outline" onClick={() => setDialog('mark-delivered')}>
                    Mark delivered
                  </Button>
                ) : null}
                {can('reject') ? (
                  <Button type="button" variant="destructive" onClick={() => setDialog('reject')}>
                    Reject
                  </Button>
                ) : null}
                {can('cancel') ? (
                  <Button type="button" variant="ghost" onClick={() => setDialog('cancel')}>
                    {cancelCopy.button}
                  </Button>
                ) : null}
                {stepBlocked && !hasStepButtons ? (
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Your role cannot take this step. Ask an owner or manager of your organization.
                  </p>
                ) : null}
              </CardFooter>
            ) : null}
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Items</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="flex flex-col divide-y">
                {order.items.map((item) => {
                  const dropped = item.qty === 0
                  return (
                    <li key={item.id} className="flex items-start justify-between gap-3 py-2.5 first:pt-0 last:pb-0">
                      <div className="flex min-w-0 flex-col gap-0.5">
                        <span className={dropped ? 'text-sm font-medium text-muted-foreground line-through' : 'text-pretty text-sm font-medium'}>
                          {item.name}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          <span className="figures">{item.qty}</span> {item.unit} × <Money paisa={item.unitPricePaisa} />
                          {item.sku ? (
                            <>
                              {' · '}
                              <span className="figures">{item.sku}</span>
                            </>
                          ) : null}
                        </span>
                        {dropped ? (
                          <span className="text-xs text-warning-foreground">
                            Not supplied. {item.requestedQty} {item.unit} were ordered.
                          </span>
                        ) : item.qty !== item.requestedQty ? (
                          <span className="text-xs text-warning-foreground">
                            {item.requestedQty} {item.unit} ordered, {item.qty} supplied.
                          </span>
                        ) : null}
                        {item.receivedQty !== null && item.receivedQty !== item.qty ? (
                          <span className="text-xs text-warning-foreground">
                            {item.receivedQty} {item.unit} received.
                          </span>
                        ) : null}
                      </div>
                      <Money paisa={item.lineTotalPaisa} className="text-sm font-medium" />
                    </li>
                  )
                })}
              </ul>
            </CardContent>
            <CardFooter className="justify-between">
              <span className="text-sm font-medium">Total</span>
              <Money paisa={order.totalPaisa} className="text-base font-semibold" />
            </CardFooter>
          </Card>

          {order.shipment ? (
            <Card>
              <CardHeader>
                <CardTitle>Shipment</CardTitle>
                <CardDescription>
                  {DELIVERY_MODE_LABEL[order.shipment.deliveryMode]} · dispatched {formatShortDateTime(order.shipment.dispatchedAt)}
                  {order.shipment.deliveredAt ? ` · delivered ${formatShortDateTime(order.shipment.deliveredAt)}` : ''}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <dl className="grid flex-1 grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 text-sm">
                  {order.shipment.carrierOrVan ? (
                    <>
                      <dt className="text-muted-foreground">
                        {order.shipment.deliveryMode === 'bilti' ? 'Transport' : 'Vehicle'}
                      </dt>
                      <dd>{order.shipment.carrierOrVan}</dd>
                    </>
                  ) : null}
                  {order.shipment.biltiRef ? (
                    <>
                      <dt className="text-muted-foreground">Bilti no.</dt>
                      <dd className="figures select-all font-medium">{order.shipment.biltiRef}</dd>
                    </>
                  ) : null}
                  {order.shipment.driverName ? (
                    <>
                      <dt className="text-muted-foreground">Driver</dt>
                      <dd>{order.shipment.driverName}</dd>
                    </>
                  ) : null}
                  {order.shipment.driverPhone ? (
                    <>
                      <dt className="text-muted-foreground">Phone</dt>
                      <dd>
                        <a
                          href={`tel:${order.shipment.driverPhone.replace(/[^\d+]/g, '')}`}
                          className="inline-flex items-center gap-1 rounded-sm text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-3 focus-visible:ring-ring/50"
                        >
                          <PhoneIcon className="size-3.5" aria-hidden="true" />
                          <span className="figures">{order.shipment.driverPhone}</span>
                        </a>
                      </dd>
                    </>
                  ) : null}
                  {order.shipment.note ? (
                    <>
                      <dt className="text-muted-foreground">Note</dt>
                      <dd className="leading-relaxed">{order.shipment.note}</dd>
                    </>
                  ) : null}
                </dl>
                {order.shipment.biltiPhotoFileId ? (
                  <a
                    href={`/api/files/${order.shipment.biltiPhotoFileId}`}
                    target="_blank"
                    rel="noreferrer"
                    className="block w-32 shrink-0 overflow-hidden rounded-lg border bg-muted outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
                  >
                    <img
                      src={`/api/files/${order.shipment.biltiPhotoFileId}`}
                      alt={`Bilti slip for order ${order.orderNo}`}
                      className="aspect-[3/4] w-full object-cover"
                    />
                  </a>
                ) : null}
              </CardContent>
            </Card>
          ) : null}
        </div>

        <div className="flex flex-col gap-4">
          <PaymentsCard order={order} canPay={permissions.pay} onOpen={setDialog} onChanged={refresh} />

          {order.receipts.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Receipts</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="flex flex-col gap-1.5">
                  {order.receipts.map((receipt) => (
                    <li key={receipt.id}>
                      <Link
                        href={`/app/receipts/${receipt.id}`}
                        className="flex items-center gap-3 rounded-lg border bg-background px-3 py-2 outline-none transition-colors hover:bg-accent/60 focus-visible:ring-3 focus-visible:ring-ring/50"
                      >
                        <ReceiptTextIcon className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                        <span className="flex min-w-0 flex-1 flex-col">
                          <span className="figures text-sm font-medium">{receipt.receiptNo}</span>
                          <span className="text-xs text-muted-foreground">
                            {receipt.kind === 'payment' ? 'Payment receipt' : 'Order confirmation'} ·{' '}
                            {formatShortDateTime(receipt.issuedAt)}
                          </span>
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ) : null}

          <Card>
            <CardHeader>
              <CardTitle>Parties</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {(
                [
                  ['Supplier', order.supplier],
                  ['Buyer', order.retailer],
                ] as const
              ).map(([role, party]) => (
                <div key={role} className="flex flex-col gap-0.5 text-sm">
                  <span className="text-xs text-muted-foreground">{role}</span>
                  <span className="font-medium">{party.name}</span>
                  <span className="leading-relaxed text-muted-foreground">
                    {party.address}, {party.city}
                  </span>
                  <span className="text-muted-foreground">
                    PAN/VAT <span className="figures">{party.panVatNo}</span> ·{' '}
                    <a
                      href={`tel:${party.phone.replace(/[^\d+]/g, '')}`}
                      className="figures rounded-sm text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-3 focus-visible:ring-ring/50"
                    >
                      {party.phone}
                    </a>
                  </span>
                </div>
              ))}
              {order.retailerNote ? (
                <div className="flex flex-col gap-0.5 text-sm">
                  <span className="text-xs text-muted-foreground">Note from the buyer</span>
                  <p className="leading-relaxed">{order.retailerNote}</p>
                </div>
              ) : null}
              {order.supplierNote ? (
                <div className="flex flex-col gap-0.5 text-sm">
                  <span className="text-xs text-muted-foreground">Note from the supplier</span>
                  <p className="leading-relaxed">{order.supplierNote}</p>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Activity</CardTitle>
          <CardDescription>Every change to this order, in order. Entries cannot be edited or removed.</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="flex flex-col gap-3">
            {order.events.map((event) => (
              <li key={event.id} className="flex gap-3">
                <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                <div className="flex min-w-0 flex-col gap-0.5">
                  <span className="text-pretty text-sm leading-relaxed">{event.message}</span>
                  <span className="text-xs text-muted-foreground">
                    {formatShortDateTime(event.createdAt)}
                    {event.actorName ? ` · ${event.actorName}` : ''}
                  </span>
                </div>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>

      {dialog === 'accept' ? <AcceptOrderDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'dispatch' ? <DispatchDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'confirm-delivery' ? <ConfirmDeliveryDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'pay' ? <PayDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'record-payment' ? <RecordPaymentDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'credit' ? <CreditDecisionDialog order={order} onClose={close} onDone={refresh} /> : null}
      {dialog === 'reject' ? (
        <ReasonDialog
          title={`Reject ${order.orderNo}?`}
          description={`${order.retailer.name} is told why. This cannot be undone; they would need to place a new order.`}
          label="Why are you rejecting it?"
          hint="For example: out of stock this week, or outside your delivery area."
          submitLabel="Reject order"
          pending={reject.pending}
          onSubmit={(reason) => void reject.run({ orderId: order.id, reason })}
          onClose={close}
        />
      ) : null}
      {dialog === 'cancel' ? (
        <ReasonDialog
          title={cancelCopy.title}
          description="The other party sees the reason in the order's activity. This cannot be undone."
          label={cancelCopy.label}
          submitLabel={cancelCopy.button}
          pending={cancel.pending}
          onSubmit={(reason) => void cancel.run({ orderId: order.id, reason })}
          onClose={close}
        />
      ) : null}
      <ConfirmDialog
        open={dialog === 'mark-delivered'}
        onOpenChange={(open) => {
          if (!open) close()
        }}
        title="Mark this order as delivered?"
        description={`Use this when ${order.retailer.name} has the goods but has not confirmed in FeriStock. Their stock updates when they count the goods in.`}
        confirmLabel="Mark delivered"
        pending={markDelivered.pending}
        onConfirm={() => void markDelivered.run({ orderId: order.id })}
      />
    </>
  )
}
