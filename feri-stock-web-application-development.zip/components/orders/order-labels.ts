import type { PaymentRecordStatus } from '@/lib/constants'
import { formatDateString } from '@/lib/dates'
import { isCommitted } from '@/lib/domain/order-rules'
import type { OrderDetail } from '@/lib/domain/orders'

export const PAYMENT_RECORD_LABEL: Record<PaymentRecordStatus, string> = {
  initiated: 'Checkout started',
  pending_verification: 'Awaiting confirmation',
  verified: 'Verified',
  failed: 'Failed',
  rejected: 'Rejected',
}

export const PAYMENT_RECORD_VARIANT: Record<PaymentRecordStatus, 'outline' | 'warning' | 'success' | 'destructive'> = {
  initiated: 'outline',
  pending_verification: 'warning',
  verified: 'success',
  failed: 'destructive',
  rejected: 'destructive',
}

export type StampSpec = { tone: 'paid' | 'credit' | 'due' | 'neutral'; label: string; detail?: string }

/** The payment position to stamp on an order. Nothing is stamped until the supplier has accepted it. */
export function paymentStamp(
  order: Pick<OrderDetail, 'status' | 'paymentStatus' | 'overdue' | 'dueDate' | 'creditState'>,
): StampSpec | null {
  if (!isCommitted(order.status)) return null
  const due = order.creditState === 'approved' && order.dueDate ? `Due ${formatDateString(order.dueDate)}` : undefined
  if (order.paymentStatus === 'paid') return { tone: 'paid', label: 'Paid' }
  if (order.overdue) return { tone: 'due', label: 'Overdue', detail: due }
  if (order.paymentStatus === 'partial') return { tone: 'credit', label: 'Part paid', detail: due }
  if (order.paymentStatus === 'credit') return { tone: 'credit', label: 'Udharo', detail: due }
  if (order.paymentStatus === 'pending') return { tone: 'neutral', label: 'Proof sent' }
  return { tone: 'due', label: 'Unpaid' }
}
