import { ChevronRightIcon } from 'lucide-react'
import Link from 'next/link'
import { Money } from '@/components/app/money'
import { OrderStatusBadge, PaymentStatusBadge } from '@/components/app/status-badges'
import { Item, ItemActions, ItemContent, ItemDescription, ItemGroup, ItemTitle } from '@/components/ui/item'
import { ORDER_TYPE_LABEL } from '@/lib/constants'
import { formatShortDateTime } from '@/lib/dates'
import { isCommitted } from '@/lib/domain/order-rules'
import type { OrderListItem } from '@/lib/domain/orders'
import { pluralize } from '@/lib/format'

export function OrderList({ orders }: { orders: OrderListItem[] }) {
  return (
    <ItemGroup className="gap-2">
      {orders.map((order) => (
        <Item
          key={order.id}
          variant="outline"
          className="bg-card"
          render={<Link href={`/app/orders/${order.id}`} aria-label={`Order ${order.orderNo}, ${order.counterparty.name}`} />}
        >
          <ItemContent>
            <ItemTitle className="flex-wrap">
              <span className="figures">{order.orderNo}</span>
              <OrderStatusBadge status={order.status} />
              {isCommitted(order.status) ? (
                <PaymentStatusBadge status={order.paymentStatus} overdue={order.overdue} />
              ) : null}
            </ItemTitle>
            <ItemDescription>
              {order.counterparty.name} · {pluralize(order.itemCount, 'item')}
              {order.orderType === 'reorder' ? '' : ` · ${ORDER_TYPE_LABEL[order.orderType]}`} ·{' '}
              {formatShortDateTime(order.placedAt ?? order.createdAt)}
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Money paisa={order.totalPaisa} className="text-sm font-medium" />
            <ChevronRightIcon className="size-4 text-muted-foreground" aria-hidden="true" />
          </ItemActions>
        </Item>
      ))}
    </ItemGroup>
  )
}
