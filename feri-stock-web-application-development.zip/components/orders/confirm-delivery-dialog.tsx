'use client'

import { useState } from 'react'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormDialog } from '@/components/app/form-dialog'
import { Field, FieldLabel } from '@/components/ui/field'
import { useAction } from '@/hooks/use-action'
import { confirmDeliveryAction } from '@/lib/actions/orders'
import type { OrderDetail } from '@/lib/domain/orders'
import { pluralize } from '@/lib/format'

/** The shop counts what actually arrived. Those quantities are added to live stock, once. */
export function ConfirmDeliveryDialog({
  order,
  onClose,
  onDone,
}: {
  order: OrderDetail
  onClose: () => void
  onDone: () => void
}) {
  const supplied = order.items.filter((item) => item.qty > 0)
  const [received, setReceived] = useState<Record<string, string>>(() =>
    Object.fromEntries(supplied.map((item) => [item.id, String(item.qty)])),
  )
  const confirm = useAction(confirmDeliveryAction, {
    success: 'Delivery confirmed and stock updated.',
    onSuccess: () => {
      onDone()
      onClose()
    },
  })
  const units = supplied.reduce((sum, item) => sum + toInt(received[item.id]), 0)

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Confirm delivery"
      description="Count what arrived. Change a number if a line came short or with extra units."
      onSubmit={() =>
        void confirm.run({
          orderId: order.id,
          items: supplied.map((item) => ({ itemId: item.id, receivedQty: toInt(received[item.id]) })),
        })
      }
      submitLabel={`Add ${pluralize(units, 'unit')} to stock`}
      pending={confirm.pending}
    >
      <ul className="flex flex-col divide-y">
        {supplied.map((item) => (
          <li key={item.id} className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0">
            <div className="flex min-w-0 flex-col gap-0.5">
              <span className="text-pretty text-sm font-medium">{item.name}</span>
              <span className="text-xs text-muted-foreground">
                Sent <span className="figures">{item.qty}</span> {item.unit}
              </span>
            </div>
            <Field className="w-24 shrink-0">
              <FieldLabel htmlFor={`received-${item.id}`} className="sr-only">
                Received quantity of {item.name}
              </FieldLabel>
              <DigitsInput
                id={`received-${item.id}`}
                value={received[item.id]}
                onValueChange={(value) => setReceived((current) => ({ ...current, [item.id]: value }))}
              />
            </Field>
          </li>
        ))}
      </ul>
    </FormDialog>
  )
}
