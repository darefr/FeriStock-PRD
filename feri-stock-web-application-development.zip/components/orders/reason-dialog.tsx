'use client'

import { useState } from 'react'
import { FormDialog } from '@/components/app/form-dialog'
import { Field, FieldDescription, FieldLabel } from '@/components/ui/field'
import { Textarea } from '@/components/ui/textarea'

/** Asks for a short written reason before an action the other party will want explained. */
export function ReasonDialog({
  title,
  description,
  label,
  hint,
  submitLabel,
  pending,
  onSubmit,
  onClose,
}: {
  title: string
  description: string
  label: string
  hint?: string
  submitLabel: string
  pending: boolean
  onSubmit: (reason: string) => void
  onClose: () => void
}) {
  const [reason, setReason] = useState('')
  const trimmed = reason.trim()

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={title}
      description={description}
      onSubmit={() => onSubmit(trimmed)}
      submitLabel={submitLabel}
      submitVariant="destructive"
      submitDisabled={trimmed.length < 3}
      pending={pending}
    >
      <Field>
        <FieldLabel htmlFor="reason-text">{label}</FieldLabel>
        <Textarea
          id="reason-text"
          rows={3}
          maxLength={300}
          value={reason}
          onChange={(event) => setReason(event.target.value)}
        />
        {hint ? <FieldDescription>{hint}</FieldDescription> : null}
      </Field>
    </FormDialog>
  )
}
