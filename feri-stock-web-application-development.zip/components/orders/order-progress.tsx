import { CheckIcon } from 'lucide-react'
import { FULFILMENT_STAGES } from '@/lib/constants'
import { formatShortDateTime } from '@/lib/dates'
import type { OrderDetail } from '@/lib/domain/orders'
import { cn } from '@/lib/utils'

type Stage = (typeof FULFILMENT_STAGES)[number]

const STAGE_LABEL: Record<Stage, string> = {
  pending: 'Ordered',
  accepted: 'Accepted',
  packed: 'Packed',
  dispatched: 'Dispatched',
  delivered: 'Delivered',
}

/** The five fulfilment stages with the time each was reached. A closed order shows how far it got. */
export function OrderProgress({ status, timestamps }: Pick<OrderDetail, 'status' | 'timestamps'>) {
  const reachedAt: Record<Stage, string | null> = {
    pending: timestamps.placedAt,
    accepted: timestamps.acceptedAt,
    packed: timestamps.packedAt,
    dispatched: timestamps.dispatchedAt,
    delivered: timestamps.deliveredAt,
  }
  const currentIndex = FULFILMENT_STAGES.indexOf(status as Stage)
  const isDone = (index: number) =>
    currentIndex >= 0 ? index <= currentIndex : reachedAt[FULFILMENT_STAGES[index]] !== null

  return (
    <ol className="grid grid-cols-5" aria-label="Order progress">
      {FULFILMENT_STAGES.map((stage, index) => {
        const done = isDone(index)
        const at = reachedAt[stage]
        return (
          <li
            key={stage}
            aria-current={index === currentIndex ? 'step' : undefined}
            className="flex min-w-0 flex-col items-center gap-1.5 text-center"
          >
            <div className="flex w-full items-center" aria-hidden="true">
              <span className={cn('h-0.5 flex-1', index === 0 ? 'bg-transparent' : done ? 'bg-primary' : 'bg-border')} />
              <span
                className={cn(
                  'flex size-6 shrink-0 items-center justify-center rounded-full border-2',
                  done ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card',
                )}
              >
                {done ? <CheckIcon className="size-3.5" /> : null}
              </span>
              <span
                className={cn(
                  'h-0.5 flex-1',
                  index === FULFILMENT_STAGES.length - 1
                    ? 'bg-transparent'
                    : isDone(index + 1)
                      ? 'bg-primary'
                      : 'bg-border',
                )}
              />
            </div>
            <span className={cn('truncate text-xs font-medium', done ? 'text-foreground' : 'text-muted-foreground')}>
              {STAGE_LABEL[stage]}
              <span className="sr-only">{done ? ', done' : ', not yet'}</span>
            </span>
            {at ? <span className="hidden text-xs text-muted-foreground sm:block">{formatShortDateTime(at)}</span> : null}
          </li>
        )
      })}
    </ol>
  )
}
