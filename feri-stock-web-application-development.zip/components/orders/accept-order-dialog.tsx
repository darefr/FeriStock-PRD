'use client'

import { useState } from 'react'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { Money } from '@/components/app/money'
import { RupeeInput } from '@/components/app/rupee-input'
import { Segmented } from '@/components/app/segmented'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Field, FieldDescription, FieldGroup, FieldLabel, FieldLegend, FieldSet } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { acceptOrderAction } from '@/lib/actions/orders'
import { addDays, todayNpt } from '@/lib/dates'
import type { OrderDetail } from '@/lib/domain/orders'
import { paisaToRupeeString, parseRupees } from '@/lib/money'

type CreditChoice = 'approve' | 'decline'

/** The supplier confirms what they will supply: the same or fewer units, at the same or a lower price. */
export function AcceptOrderDialog({
  order,
  onClose,
  onDone,
}: {
  order: OrderDetail
  onClose: () => void
  onDone: () => void
}) {
  const [lines, setLines] = useState(() =>
    order.items.map((item) => ({ qty: String(item.qty), price: paisaToRupeeString(item.unitPricePaisa) })),
  )
  const [supplierNote, setSupplierNote] = useState('')
  const creditRequested = order.creditState === 'requested'
  const [creditChoice, setCreditChoice] = useState<CreditChoice>('approve')
  const today = todayNpt()
  const [dueDate, setDueDate] = useState(() => addDays(today, order.supplierTerms.creditDays))
  const [error, setError] = useState<string | null>(null)

  const accept = useAction(acceptOrderAction, {
    success: `Order ${order.orderNo} accepted.`,
    onSuccess: () => {
      onDone()
      onClose()
    },
  })

  const offers = order.items.map((item, index) => ({
    item,
    qty: toInt(lines[index].qty),
    pricePaisa: parseRupees(lines[index].price),
  }))
  const total = offers.reduce((sum, offer) => sum + offer.qty * (offer.pricePaisa ?? 0), 0)
  const changed = offers.some(
    (offer) => offer.qty !== offer.item.requestedQty || offer.pricePaisa !== offer.item.unitPricePaisa,
  )

  function handleSubmit() {
    for (const { item, qty, pricePaisa } of offers) {
      if (pricePaisa === null) return setError(`Enter a valid price for ${item.name}.`)
      if (qty > item.requestedQty) {
        return setError(`${item.name}: the buyer ordered ${item.requestedQty} ${item.unit}. Supply that many or fewer.`)
      }
      if (pricePaisa > item.unitPricePaisa) {
        return setError(`${item.name}: the price cannot be higher than the ordered price.`)
      }
    }
    if (offers.every((offer) => offer.qty === 0)) {
      return setError('There is nothing left to supply. Reject the order instead.')
    }
    if (creditRequested && creditChoice === 'approve' && dueDate < today) {
      return setError('Choose a credit due date from today onwards.')
    }
    setError(null)
    void accept.run({
      orderId: order.id,
      items: offers.map((offer) => ({
        itemId: offer.item.id,
        qty: offer.qty,
        unitPricePaisa: offer.pricePaisa as number,
      })),
      supplierNote,
      credit: creditRequested
        ? { approve: creditChoice === 'approve', dueDate: creditChoice === 'approve' ? dueDate : null }
        : null,
    })
  }

  const updateLine = (index: number, patch: Partial<{ qty: string; price: string }>) =>
    setLines((current) => current.map((line, position) => (position === index ? { ...line, ...patch } : line)))

  return (
    <FormDialog
      open
      size="lg"
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={`Accept ${order.orderNo}`}
      description={`From ${order.retailer.name}. Lower a quantity if you are short, or a price if you are giving a better rate.`}
      onSubmit={handleSubmit}
      submitLabel={changed ? 'Accept with changes' : 'Accept order'}
      pending={accept.pending}
    >
      <FieldGroup>
        <ul className="flex flex-col divide-y">
          {order.items.map((item, index) => (
            <li key={item.id} className="flex flex-col gap-3 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-end sm:gap-4">
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <span className="text-pretty text-sm font-medium">{item.name}</span>
                <span className="text-xs text-muted-foreground">
                  Ordered <span className="figures">{item.requestedQty}</span> {item.unit} at{' '}
                  <Money paisa={item.unitPricePaisa} />
                </span>
              </div>
              <div className="grid grid-cols-[6rem_1fr] gap-3 sm:w-64">
                <Field>
                  <FieldLabel htmlFor={`accept-qty-${item.id}`}>Supply</FieldLabel>
                  <DigitsInput
                    id={`accept-qty-${item.id}`}
                    value={lines[index].qty}
                    onValueChange={(qty) => updateLine(index, { qty })}
                  />
                </Field>
                <Field>
                  <FieldLabel htmlFor={`accept-price-${item.id}`}>Price each</FieldLabel>
                  <RupeeInput
                    id={`accept-price-${item.id}`}
                    value={lines[index].price}
                    onValueChange={(price) => updateLine(index, { price })}
                  />
                </Field>
              </div>
            </li>
          ))}
        </ul>

        <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
          <span className="text-sm text-muted-foreground">Order total after your changes</span>
          <Money paisa={total} className="text-base font-semibold" />
        </div>

        {creditRequested ? (
          <FieldSet>
            <FieldLegend variant="label">The buyer asked to pay on udharo</FieldLegend>
            <Segmented
              label="Udharo decision"
              value={creditChoice}
              onChange={setCreditChoice}
              options={[
                { value: 'approve', label: 'Approve credit' },
                { value: 'decline', label: 'Payment up front' },
              ]}
            />
            {creditChoice === 'approve' ? (
              <FormField label="Payment due by" htmlFor="accept-due" className="max-w-56">
                <Input
                  id="accept-due"
                  type="date"
                  min={today}
                  value={dueDate}
                  onChange={(event) => setDueDate(event.target.value)}
                />
              </FormField>
            ) : (
              <FieldDescription>The order is accepted and the buyer is asked to pay before or on delivery.</FieldDescription>
            )}
          </FieldSet>
        ) : null}

        <Field>
          <FieldLabel htmlFor="accept-note">
            Note to buyer <span className="font-normal text-muted-foreground">(optional)</span>
          </FieldLabel>
          <Textarea
            id="accept-note"
            rows={2}
            maxLength={500}
            placeholder="e.g. Two cartons short this week, balance next Tuesday."
            value={supplierNote}
            onChange={(event) => setSupplierNote(event.target.value)}
          />
        </Field>

        {error ? (
          <Alert variant="destructive" role="alert">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}
      </FieldGroup>
    </FormDialog>
  )
}
