'use client'

import { HandCoinsIcon, ReceiptTextIcon, RefreshCwIcon, WalletIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'
import { toast } from 'sonner'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { Money } from '@/components/app/money'
import { PaymentStatusBadge } from '@/components/app/status-badges'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import {
  confirmPaymentProofAction,
  recheckPaymentAction,
  rejectPaymentProofAction,
  requestCreditAction,
} from '@/lib/actions/payments'
import { PAYMENT_METHOD_LABEL } from '@/lib/constants'
import { formatDateString, formatShortDateTime } from '@/lib/dates'
import { isCommitted } from '@/lib/domain/order-rules'
import type { OrderDetail } from '@/lib/domain/orders'
import type { VerificationOutcome } from '@/lib/domain/payments'
import { formatNpr } from '@/lib/money'
import { PAYMENT_RECORD_LABEL, PAYMENT_RECORD_VARIANT } from './order-labels'
import { ReasonDialog } from './reason-dialog'

type Payment = OrderDetail['payments'][number]

function reportOutcome(outcome: VerificationOutcome) {
  if (outcome === 'verified') toast.success('Payment verified. The receipt has been issued.')
  else if (outcome === 'pending') toast.info('The gateway has not completed this payment yet.')
  else if (outcome === 'failed') toast.error('The gateway reports that this payment did not go through.')
  else if (outcome === 'mismatch') toast.error('The amount the gateway reports does not match, so it was not accepted.')
  else toast.error('The gateway could not be reached. Try again in a moment.')
}

export function PaymentsCard({
  order,
  canPay,
  onOpen,
  onChanged,
}: {
  order: OrderDetail
  /** The viewer's role may pay, confirm or record payments. */
  canPay: boolean
  onOpen: (dialog: 'pay' | 'record-payment' | 'credit') => void
  onChanged: () => void
}) {
  const [confirming, setConfirming] = useState<Payment | null>(null)
  const [rejecting, setRejecting] = useState<Payment | null>(null)

  const requestCredit = useAction(requestCreditAction, { success: 'Udharo request sent to the supplier.', onSuccess: onChanged })
  const recheck = useAction(recheckPaymentAction, {
    onSuccess: ({ outcome }) => {
      reportOutcome(outcome)
      onChanged()
    },
  })
  const confirmProof = useAction(confirmPaymentProofAction, {
    success: 'Payment confirmed and receipt issued.',
    onSuccess: () => {
      setConfirming(null)
      onChanged()
    },
  })
  const rejectProof = useAction(rejectPaymentProofAction, {
    success: 'Payment proof rejected.',
    onSuccess: () => {
      setRejecting(null)
      onChanged()
    },
  })

  const committed = isCommitted(order.status)
  const isSupplier = order.viewerSide === 'supplier'
  const can = (action: OrderDetail['actions'][number]) => canPay && order.actions.includes(action)
  const hasActions = can('pay') || can('request_credit') || can('record_payment') || can('decide_credit')

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payment</CardTitle>
        {committed ? (
          <CardAction>
            <PaymentStatusBadge status={order.paymentStatus} overdue={order.overdue} />
          </CardAction>
        ) : null}
      </CardHeader>

      <CardContent className="flex flex-col gap-4">
        <dl className="flex flex-col gap-1.5 text-sm">
          <div className="flex items-center justify-between gap-3">
            <dt className="text-muted-foreground">Order total</dt>
            <dd>
              <Money paisa={order.totalPaisa} />
            </dd>
          </div>
          <div className="flex items-center justify-between gap-3">
            <dt className="text-muted-foreground">Paid</dt>
            <dd>
              <Money paisa={order.paidPaisa} />
            </dd>
          </div>
          <div className="flex items-center justify-between gap-3 border-t pt-1.5 font-medium">
            <dt>Balance</dt>
            <dd>
              <Money paisa={order.balancePaisa} className="text-base" />
            </dd>
          </div>
        </dl>

        {!committed && order.status !== 'cancelled' && order.status !== 'rejected' ? (
          <p className="text-sm leading-relaxed text-muted-foreground">
            Payment opens once the supplier accepts the order and confirms the final amount.
          </p>
        ) : null}

        {order.creditState === 'requested' ? (
          <p className="rounded-lg bg-warning/20 px-3 py-2 text-sm leading-relaxed text-warning-foreground">
            {isSupplier
              ? 'The buyer asked to pay on udharo. Approve it with a due date, or ask for payment up front.'
              : 'You asked to pay on udharo. Waiting for the supplier to decide.'}
          </p>
        ) : null}
        {order.creditState === 'approved' && order.dueDate && order.balancePaisa > 0 ? (
          <p
            className={
              order.overdue
                ? 'rounded-lg bg-destructive/10 px-3 py-2 text-sm leading-relaxed text-destructive'
                : 'rounded-lg bg-muted px-3 py-2 text-sm leading-relaxed'
            }
          >
            On udharo. {order.overdue ? 'Was due' : 'Due'} by{' '}
            <span className="font-medium">{formatDateString(order.dueDate)}</span>.
          </p>
        ) : null}
        {order.creditState === 'declined' && order.balancePaisa > 0 ? (
          <p className="text-sm leading-relaxed text-muted-foreground">
            Udharo was not approved for this order. Payment is expected before or on delivery.
          </p>
        ) : null}

        {order.payments.length > 0 ? (
          <ul className="flex flex-col divide-y border-t">
            {order.payments.map((payment) => {
              const gateway = payment.method === 'esewa' || payment.method === 'khalti'
              return (
                <li key={payment.id} className="flex flex-col gap-2 py-3 last:pb-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 flex-col gap-0.5">
                      <span className="text-sm font-medium">
                        {PAYMENT_METHOD_LABEL[payment.method]}
                        {payment.gatewayEnv === 'test' ? <span className="font-normal text-muted-foreground"> (test)</span> : null}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatShortDateTime(payment.paidAt ?? payment.createdAt)}
                        {payment.transactionRef ? (
                          <>
                            {' · ref '}
                            <span className="figures break-all">{payment.transactionRef}</span>
                          </>
                        ) : null}
                      </span>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1">
                      <Money paisa={payment.amountPaisa} className="text-sm font-medium" />
                      <Badge variant={PAYMENT_RECORD_VARIANT[payment.status]}>{PAYMENT_RECORD_LABEL[payment.status]}</Badge>
                    </div>
                  </div>

                  {payment.note ? <p className="text-xs leading-relaxed text-muted-foreground">{payment.note}</p> : null}
                  {payment.rejectReason ? (
                    <p className="text-xs leading-relaxed text-destructive">Rejected: {payment.rejectReason}</p>
                  ) : null}

                  <div className="flex flex-wrap gap-1.5 empty:hidden">
                    {payment.receipt ? (
                      <Button variant="outline" size="sm" nativeButton={false} render={<Link href={`/app/receipts/${payment.receipt.id}`} />}>
                        <ReceiptTextIcon data-icon="inline-start" />
                        Receipt <span className="figures">{payment.receipt.receiptNo}</span>
                      </Button>
                    ) : null}
                    {payment.proofFileId ? (
                      <Button
                        variant="outline"
                        size="sm"
                        nativeButton={false}
                        render={<a href={`/api/files/${payment.proofFileId}`} target="_blank" rel="noreferrer" />}
                      >
                        View screenshot
                      </Button>
                    ) : null}
                    {isSupplier && canPay && payment.status === 'pending_verification' ? (
                      <>
                        <Button type="button" size="sm" onClick={() => setConfirming(payment)}>
                          Confirm received
                        </Button>
                        <Button type="button" variant="destructive" size="sm" onClick={() => setRejecting(payment)}>
                          Reject
                        </Button>
                      </>
                    ) : null}
                    {gateway && (payment.status === 'initiated' || payment.status === 'failed') ? (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        disabled={recheck.pending}
                        onClick={() => void recheck.run({ paymentId: payment.id })}
                      >
                        {recheck.pending ? <Spinner data-icon="inline-start" /> : <RefreshCwIcon data-icon="inline-start" />}
                        Check with {PAYMENT_METHOD_LABEL[payment.method]}
                      </Button>
                    ) : null}
                  </div>
                </li>
              )
            })}
          </ul>
        ) : null}
      </CardContent>

      {hasActions ? (
        <CardFooter className="flex-wrap gap-2">
          {can('pay') ? (
            <Button type="button" onClick={() => onOpen('pay')}>
              <WalletIcon data-icon="inline-start" />
              Pay supplier
            </Button>
          ) : null}
          {can('request_credit') && order.supplierTerms.creditEnabled ? (
            <Button
              type="button"
              variant="outline"
              disabled={requestCredit.pending}
              onClick={() => void requestCredit.run({ orderId: order.id })}
            >
              {requestCredit.pending ? <Spinner data-icon="inline-start" /> : null}
              Ask for udharo
            </Button>
          ) : null}
          {can('decide_credit') ? (
            <Button type="button" onClick={() => onOpen('credit')}>
              Decide udharo request
            </Button>
          ) : null}
          {can('record_payment') ? (
            <Button type="button" variant={can('decide_credit') ? 'outline' : 'default'} onClick={() => onOpen('record-payment')}>
              <HandCoinsIcon data-icon="inline-start" />
              Record payment
            </Button>
          ) : null}
        </CardFooter>
      ) : null}

      <ConfirmDialog
        open={confirming !== null}
        onOpenChange={(open) => {
          if (!open) setConfirming(null)
        }}
        title="Confirm this payment?"
        description={
          confirming
            ? `Only confirm once ${formatNpr(confirming.amountPaisa)} has reached your account. A receipt is issued to the buyer and the record cannot be changed afterwards.`
            : ''
        }
        confirmLabel="Yes, I received it"
        pending={confirmProof.pending}
        onConfirm={() => {
          if (confirming) void confirmProof.run({ paymentId: confirming.id })
        }}
      />

      {rejecting ? (
        <ReasonDialog
          title="Reject this payment proof"
          description={`${formatNpr(rejecting.amountPaisa)} from ${order.retailer.name}. They are told why and can send it again.`}
          label="Why are you rejecting it?"
          hint="For example: the amount has not reached the account, or the reference does not match."
          submitLabel="Reject proof"
          pending={rejectProof.pending}
          onSubmit={(reason) => void rejectProof.run({ paymentId: rejecting.id, reason })}
          onClose={() => setRejecting(null)}
        />
      ) : null}
    </Card>
  )
}
