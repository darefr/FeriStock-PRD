'use client'

import { useState } from 'react'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { Money } from '@/components/app/money'
import { RupeeInput } from '@/components/app/rupee-input'
import { Segmented } from '@/components/app/segmented'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { FieldDescription, FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { useAction } from '@/hooks/use-action'
import { decideCreditAction, recordReceivedPaymentAction } from '@/lib/actions/payments'
import { addDays, todayNpt } from '@/lib/dates'
import type { OrderDetail } from '@/lib/domain/orders'
import { formatNpr, paisaToRupeeString, parseRupees } from '@/lib/money'

type DialogProps = { order: OrderDetail; onClose: () => void; onDone: () => void }

/** The supplier records money received outside a gateway: cash, cheque or a transfer they have checked. */
export function RecordPaymentDialog({ order, onClose, onDone }: DialogProps) {
  const [amount, setAmount] = useState(paisaToRupeeString(order.balancePaisa))
  const [transactionRef, setTransactionRef] = useState('')
  const [note, setNote] = useState('')
  const [error, setError] = useState<string | null>(null)
  const record = useAction(recordReceivedPaymentAction, {
    success: 'Payment recorded and receipt issued.',
    onSuccess: () => {
      onDone()
      onClose()
    },
  })

  function handleSubmit() {
    const amountPaisa = parseRupees(amount)
    if (amountPaisa === null || amountPaisa <= 0) return setError('Enter the amount you received.')
    if (amountPaisa > order.balancePaisa) {
      return setError(`The outstanding balance on this order is ${formatNpr(order.balancePaisa)}.`)
    }
    setError(null)
    void record.run({ orderId: order.id, amountPaisa, transactionRef, note })
  }

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Record a payment received"
      description={`From ${order.retailer.name} for ${order.orderNo}. A receipt is issued to both of you and cannot be edited afterwards.`}
      onSubmit={handleSubmit}
      submitLabel="Record payment"
      pending={record.pending}
    >
      <FieldGroup>
        <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
          <span className="text-sm text-muted-foreground">Balance on this order</span>
          <Money paisa={order.balancePaisa} className="text-base font-semibold" />
        </div>
        <FormField label="Amount received" htmlFor="record-amount" className="max-w-56">
          <RupeeInput id="record-amount" value={amount} onValueChange={setAmount} />
        </FormField>
        <FormField
          label="Reference"
          htmlFor="record-reference"
          optional
          hint="Cheque number, voucher number or bank reference."
        >
          <Input
            id="record-reference"
            autoComplete="off"
            className="figures"
            maxLength={80}
            value={transactionRef}
            onChange={(event) => setTransactionRef(event.target.value)}
          />
        </FormField>
        <FormField label="Note" htmlFor="record-note" optional>
          <Input
            id="record-note"
            autoComplete="off"
            maxLength={300}
            placeholder="e.g. Cash collected by the driver"
            value={note}
            onChange={(event) => setNote(event.target.value)}
          />
        </FormField>
        {error ? (
          <Alert variant="destructive" role="alert">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : null}
      </FieldGroup>
    </FormDialog>
  )
}

/** The supplier answers a request to buy on udharo: approve with a due date, or ask for payment up front. */
export function CreditDecisionDialog({ order, onClose, onDone }: DialogProps) {
  const today = todayNpt()
  const [choice, setChoice] = useState<'approve' | 'decline'>('approve')
  const [dueDate, setDueDate] = useState(() => addDays(today, order.supplierTerms.creditDays))
  const decide = useAction(decideCreditAction, {
    success: choice === 'approve' ? 'Udharo approved.' : 'Udharo request declined.',
    onSuccess: () => {
      onDone()
      onClose()
    },
  })

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Udharo request"
      description={`${order.retailer.name} asked to pay ${formatNpr(order.balancePaisa)} later for ${order.orderNo}.`}
      onSubmit={() =>
        void decide.run({
          orderId: order.id,
          approve: choice === 'approve',
          dueDate: choice === 'approve' ? dueDate : null,
        })
      }
      submitLabel={choice === 'approve' ? 'Approve udharo' : 'Decline request'}
      submitVariant={choice === 'approve' ? 'default' : 'destructive'}
      submitDisabled={choice === 'approve' && dueDate < today}
      pending={decide.pending}
    >
      <FieldGroup>
        <Segmented
          label="Udharo decision"
          value={choice}
          onChange={setChoice}
          options={[
            { value: 'approve', label: 'Approve credit' },
            { value: 'decline', label: 'Payment up front' },
          ]}
        />
        {choice === 'approve' ? (
          <FormField
            label="Payment due by"
            htmlFor="credit-due"
            hint="Shown to the buyer and tracked in both ledgers. It turns overdue the day after."
            className="max-w-64"
          >
            <Input
              id="credit-due"
              type="date"
              min={today}
              value={dueDate}
              onChange={(event) => setDueDate(event.target.value)}
            />
          </FormField>
        ) : (
          <FieldDescription>The buyer is told to pay before or on delivery.</FieldDescription>
        )}
      </FieldGroup>
    </FormDialog>
  )
}
