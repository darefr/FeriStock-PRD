'use client'

import { InfoIcon } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { ImageUpload } from '@/components/app/image-upload'
import { Money } from '@/components/app/money'
import { RupeeInput } from '@/components/app/rupee-input'
import { Segmented } from '@/components/app/segmented'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { useAction } from '@/hooks/use-action'
import { startGatewayPaymentAction, submitPaymentProofAction } from '@/lib/actions/payments'
import { LIMITS, PAYMENT_METHOD_LABEL } from '@/lib/constants'
import type { EsewaForm } from '@/lib/domain/gateways/esewa'
import type { OrderDetail } from '@/lib/domain/orders'
import { formatNpr, paisaToRupeeString, parseRupees } from '@/lib/money'

type Method = 'esewa' | 'khalti' | 'qr_bank'

const CHECKOUT_WINDOW = 'feristock-checkout'

function postForm(form: EsewaForm, target: string | null) {
  const element = document.createElement('form')
  element.method = 'POST'
  element.action = form.action
  if (target) element.target = target
  for (const [name, value] of Object.entries(form.fields)) {
    const input = document.createElement('input')
    input.type = 'hidden'
    input.name = name
    input.value = value
    element.append(input)
  }
  document.body.append(element)
  element.submit()
  element.remove()
}

/**
 * Pays the supplier directly: their eSewa or Khalti checkout, or their bank account / QR with proof
 * for them to confirm. FeriStock never receives the money.
 */
export function PayDialog({ order, onClose, onDone }: { order: OrderDetail; onClose: () => void; onDone: () => void }) {
  const terms = order.supplierTerms
  const methods: Method[] = [
    ...(terms.esewa ? (['esewa'] as const) : []),
    ...(terms.khalti ? (['khalti'] as const) : []),
    ...(terms.qrFileId || terms.bank ? (['qr_bank'] as const) : []),
  ]
  const [method, setMethod] = useState<Method | null>(methods[0] ?? null)
  const [amount, setAmount] = useState(paisaToRupeeString(order.balancePaisa))
  const [transactionRef, setTransactionRef] = useState('')
  const [proofFileId, setProofFileId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const startCheckout = useAction(startGatewayPaymentAction)
  const submitProof = useAction(submitPaymentProofAction, {
    success: `Sent to ${order.supplier.name} to confirm.`,
    onSuccess: () => {
      onDone()
      onClose()
    },
  })
  const pending = startCheckout.pending || submitProof.pending
  const testMode =
    (method === 'esewa' && terms.esewaEnv === 'test') || (method === 'khalti' && terms.khaltiEnv === 'test')

  async function handleSubmit() {
    if (!method) return
    const amountPaisa = parseRupees(amount)
    if (amountPaisa === null || amountPaisa <= 0) return setError('Enter the amount you are paying.')
    if (amountPaisa > order.balancePaisa) {
      return setError(`The outstanding balance on this order is ${formatNpr(order.balancePaisa)}.`)
    }
    if (method === 'khalti' && amountPaisa < LIMITS.khaltiMinPaisa) {
      return setError(`Khalti payments start at ${formatNpr(LIMITS.khaltiMinPaisa)}.`)
    }
    if (method === 'qr_bank' && !transactionRef.trim() && !proofFileId) {
      return setError('Enter the transaction reference or attach a screenshot of the payment.')
    }
    setError(null)

    if (method === 'qr_bank') {
      void submitProof.run({ orderId: order.id, amountPaisa, transactionRef, proofFileId, note: '' })
      return
    }

    // Gateways refuse to load inside a frame, so an embedded page hands checkout to a new tab.
    // The tab is opened now, while the click still counts as a user gesture.
    const embedded = window.self !== window.top
    const tab = embedded ? window.open('', CHECKOUT_WINDOW) : null
    if (embedded && !tab) return setError('Allow pop-ups for this site to open the payment page.')

    const started = await startCheckout.run({ orderId: order.id, method, amountPaisa })
    if (!started) {
      tab?.close()
      return
    }
    if (started.data.kind === 'form') postForm(started.data.form, embedded ? CHECKOUT_WINDOW : null)
    else if (tab) tab.location.href = started.data.url
    else window.location.assign(started.data.url)

    if (embedded) {
      toast.info('Finish the payment in the new tab. This order updates once the gateway confirms it.')
      onDone()
      onClose()
    }
  }

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={`Pay ${order.supplier.name}`}
      description={`Order ${order.orderNo}. The money goes straight to the supplier's own account.`}
      onSubmit={() => void handleSubmit()}
      submitLabel={method === 'qr_bank' ? 'Send payment proof' : method ? `Continue to ${PAYMENT_METHOD_LABEL[method]}` : 'Pay'}
      submitDisabled={!method}
      pending={pending}
    >
      {method === null ? (
        <Alert>
          <InfoIcon />
          <AlertTitle>No payment details on file</AlertTitle>
          <AlertDescription>
            {order.supplier.name} has not added eSewa, Khalti or bank details yet. Pay them directly and ask them to
            record the payment on this order. You will get the receipt here.
          </AlertDescription>
        </Alert>
      ) : (
        <FieldGroup>
          <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
            <span className="text-sm text-muted-foreground">Balance on this order</span>
            <Money paisa={order.balancePaisa} className="text-base font-semibold" />
          </div>

          {methods.length > 1 ? (
            <Field>
              <FieldLabel>Pay with</FieldLabel>
              <Segmented
                label="Payment method"
                value={method}
                onChange={(next) => {
                  setMethod(next)
                  setError(null)
                }}
                options={methods.map((value) => ({ value, label: PAYMENT_METHOD_LABEL[value] }))}
              />
            </Field>
          ) : null}

          <FormField
            label="Amount"
            htmlFor="pay-amount"
            hint="Pay the full balance, or part of it now and the rest later."
            className="max-w-56"
          >
            <RupeeInput id="pay-amount" value={amount} onValueChange={setAmount} />
          </FormField>

          {method === 'qr_bank' ? (
            <>
              <div className="flex flex-col gap-3 rounded-lg border bg-background p-3 sm:flex-row sm:items-start">
                {terms.qrFileId ? (
                  <a
                    href={`/api/files/${terms.qrFileId}`}
                    target="_blank"
                    rel="noreferrer"
                    className="block w-40 shrink-0 self-center overflow-hidden rounded-md border bg-card outline-none focus-visible:ring-3 focus-visible:ring-ring/50 sm:self-start"
                  >
                    <img
                      src={`/api/files/${terms.qrFileId}`}
                      alt={`Payment QR code for ${order.supplier.name}`}
                      className="aspect-square w-full object-contain"
                    />
                  </a>
                ) : null}
                {terms.bank ? (
                  <dl className="flex min-w-0 flex-1 flex-col gap-1.5 text-sm">
                    <div className="flex flex-col">
                      <dt className="text-xs text-muted-foreground">Bank</dt>
                      <dd>
                        {terms.bank.bankName}
                        {terms.bank.branch ? `, ${terms.bank.branch}` : ''}
                      </dd>
                    </div>
                    <div className="flex flex-col">
                      <dt className="text-xs text-muted-foreground">Account name</dt>
                      <dd>{terms.bank.accountName}</dd>
                    </div>
                    <div className="flex flex-col">
                      <dt className="text-xs text-muted-foreground">Account number</dt>
                      <dd className="figures select-all font-medium">{terms.bank.accountNumber}</dd>
                    </div>
                  </dl>
                ) : (
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Scan the QR with your banking or wallet app, then send the proof below.
                  </p>
                )}
              </div>

              <FormField
                label="Transaction reference"
                htmlFor="pay-reference"
                hint="The reference or transaction ID shown by your bank or wallet."
              >
                <Input
                  id="pay-reference"
                  autoComplete="off"
                  className="figures"
                  maxLength={80}
                  value={transactionRef}
                  onChange={(event) => setTransactionRef(event.target.value)}
                />
              </FormField>
              <Field>
                <FieldLabel>Payment screenshot</FieldLabel>
                <ImageUpload kind="payment_proof" label="Screenshot" value={proofFileId} onChange={setProofFileId} />
                <FieldDescription>
                  The supplier checks it against their account and confirms. Your receipt is issued then.
                </FieldDescription>
              </Field>
            </>
          ) : (
            <Alert>
              <InfoIcon />
              <AlertTitle>
                {testMode ? `${PAYMENT_METHOD_LABEL[method]} test mode` : `You will leave FeriStock to pay`}
              </AlertTitle>
              <AlertDescription>
                {testMode
                  ? 'This supplier is using the gateway sandbox, so no real money moves.'
                  : `You pay on ${PAYMENT_METHOD_LABEL[method]}'s own page.`}{' '}
                The order is marked paid only after the gateway confirms the exact amount to our server.
              </AlertDescription>
            </Alert>
          )}

          {error ? (
            <Alert variant="destructive" role="alert">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : null}
        </FieldGroup>
      )}
    </FormDialog>
  )
}
