'use client'

import { ClipboardListIcon, InboxIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'
import { EmptyState } from '@/components/app/empty-state'
import { FilterBar } from '@/components/app/filter-bar'
import { Button } from '@/components/ui/button'
import { isClosed, isCommitted, type OrderSide } from '@/lib/domain/order-rules'
import type { OrderListItem } from '@/lib/domain/orders'
import { OrderList } from './order-list'

type Tab = {
  value: string
  label: string
  match: (order: OrderListItem) => boolean
  /** Shown only when it has orders, to keep the filter row short. */
  optional?: boolean
}

const TABS: Record<OrderSide, Tab[]> = {
  retailer: [
    { value: 'all', label: 'All', match: () => true },
    { value: 'draft', label: 'Drafts to review', match: (order) => order.status === 'draft', optional: true },
    {
      value: 'open',
      label: 'In progress',
      match: (order) => order.status === 'pending' || order.status === 'accepted' || order.status === 'packed',
    },
    { value: 'transit', label: 'On the way', match: (order) => order.status === 'dispatched' },
    { value: 'delivered', label: 'Delivered', match: (order) => order.status === 'delivered' },
    { value: 'closed', label: 'Closed', match: (order) => isClosed(order.status), optional: true },
  ],
  supplier: [
    { value: 'all', label: 'All', match: () => true },
    { value: 'new', label: 'New', match: (order) => order.status === 'pending' },
    { value: 'pack', label: 'To pack', match: (order) => order.status === 'accepted' },
    { value: 'dispatch', label: 'To dispatch', match: (order) => order.status === 'packed' },
    { value: 'transit', label: 'On the way', match: (order) => order.status === 'dispatched' },
    { value: 'delivered', label: 'Delivered', match: (order) => order.status === 'delivered' },
    {
      value: 'payments',
      label: 'Payments to confirm',
      match: (order) => isCommitted(order.status) && order.paymentStatus === 'pending',
      optional: true,
    },
    {
      value: 'credit',
      label: 'Udharo requests',
      match: (order) => isCommitted(order.status) && order.creditState === 'requested',
      optional: true,
    },
    { value: 'closed', label: 'Closed', match: (order) => isClosed(order.status), optional: true },
  ],
}

export function OrdersView({
  orders,
  side,
  initialTab,
}: {
  orders: OrderListItem[]
  side: OrderSide
  initialTab?: string
}) {
  const tabs = TABS[side]
  const [selected, setSelected] = useState(() => (tabs.some((tab) => tab.value === initialTab) ? (initialTab as string) : 'all'))

  if (orders.length === 0) {
    return side === 'retailer' ? (
      <EmptyState
        icon={ClipboardListIcon}
        title="No purchase orders yet"
        description="Send your first order from the cart. You can follow it here from acceptance to delivery and payment."
      >
        <div className="flex flex-wrap justify-center gap-2">
          <Button nativeButton={false} render={<Link href="/app/suppliers" />}>
            Browse suppliers
          </Button>
          <Button variant="outline" nativeButton={false} render={<Link href="/app/inventory" />}>
            Open inventory
          </Button>
        </div>
      </EmptyState>
    ) : (
      <EmptyState
        icon={InboxIcon}
        title="No orders yet"
        description="Purchase orders from shops arrive here. Make sure your catalog and selling terms are ready for them."
      >
        <Button nativeButton={false} render={<Link href="/app/catalog" />}>
          Open catalog
        </Button>
      </EmptyState>
    )
  }

  const counted = tabs.map((tab) => ({ ...tab, count: orders.filter(tab.match).length }))
  const active = counted.find((tab) => tab.value === selected) ?? counted[0]
  const visible = orders.filter(active.match)

  return (
    <>
      <FilterBar
        label="Filter orders"
        value={active.value}
        onChange={setSelected}
        options={counted
          .filter((tab) => !tab.optional || tab.count > 0 || tab.value === active.value)
          .map((tab) => ({ value: tab.value, label: tab.label, count: tab.count }))}
      />
      {visible.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">No orders here right now.</p>
      ) : (
        <OrderList orders={visible} />
      )}
    </>
  )
}
