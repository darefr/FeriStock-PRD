'use client'

import { useState } from 'react'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { ImageUpload } from '@/components/app/image-upload'
import { Segmented } from '@/components/app/segmented'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { dispatchOrderAction } from '@/lib/actions/orders'
import { DELIVERY_MODES, DELIVERY_MODE_LABEL, type DeliveryMode } from '@/lib/constants'
import type { OrderDetail } from '@/lib/domain/orders'
import { dispatchSchema, fieldErrors } from '@/lib/validation'

/** Records how the goods left the godown: own van, transport bilti or pickup. */
export function DispatchDialog({
  order,
  onClose,
  onDone,
}: {
  order: OrderDetail
  onClose: () => void
  onDone: () => void
}) {
  const modes = order.supplierTerms.deliveryModes.length > 0 ? order.supplierTerms.deliveryModes : [...DELIVERY_MODES]
  const [mode, setMode] = useState<DeliveryMode>(modes[0])
  const [carrierOrVan, setCarrierOrVan] = useState('')
  const [driverName, setDriverName] = useState('')
  const [driverPhone, setDriverPhone] = useState('')
  const [biltiRef, setBiltiRef] = useState('')
  const [biltiPhotoFileId, setBiltiPhotoFileId] = useState<string | null>(null)
  const [note, setNote] = useState('')
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})

  const dispatch = useAction(dispatchOrderAction, {
    success: `Order ${order.orderNo} marked as dispatched.`,
    onSuccess: () => {
      onDone()
      onClose()
    },
  })
  const errors = { ...dispatch.fields, ...localErrors }

  function handleSubmit() {
    const parsed = dispatchSchema.safeParse({
      orderId: order.id,
      deliveryMode: mode,
      carrierOrVan: mode === 'pickup' ? '' : carrierOrVan,
      driverName: mode === 'own_van' ? driverName : '',
      driverPhone: mode === 'own_van' ? driverPhone : '',
      biltiRef: mode === 'bilti' ? biltiRef : '',
      biltiPhotoFileId: mode === 'bilti' ? biltiPhotoFileId : null,
      note,
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void dispatch.run(parsed.data)
  }

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={`Dispatch ${order.orderNo}`}
      description={`${order.retailer.name}, ${order.retailer.address}, ${order.retailer.city}. The buyer sees these details straight away.`}
      onSubmit={handleSubmit}
      submitLabel="Mark as dispatched"
      pending={dispatch.pending}
    >
      <FieldGroup>
        <Field>
          <FieldLabel>How is it going?</FieldLabel>
          <Segmented
            label="Delivery method"
            value={mode}
            onChange={setMode}
            options={modes.map((value) => ({ value, label: DELIVERY_MODE_LABEL[value] }))}
          />
        </Field>

        {mode === 'own_van' ? (
          <>
            <FormField label="Vehicle number" htmlFor="dispatch-vehicle" error={errors.carrierOrVan}>
              <Input
                id="dispatch-vehicle"
                autoComplete="off"
                autoCapitalize="characters"
                placeholder="e.g. Ba 2 Kha 4521"
                aria-invalid={errors.carrierOrVan ? true : undefined}
                value={carrierOrVan}
                onChange={(event) => setCarrierOrVan(event.target.value)}
              />
            </FormField>
            <div className="grid gap-5 sm:grid-cols-2">
              <FormField label="Driver name" htmlFor="dispatch-driver" optional error={errors.driverName}>
                <Input
                  id="dispatch-driver"
                  autoComplete="off"
                  value={driverName}
                  onChange={(event) => setDriverName(event.target.value)}
                />
              </FormField>
              <FormField label="Driver phone" htmlFor="dispatch-phone" optional error={errors.driverPhone}>
                <Input
                  id="dispatch-phone"
                  type="tel"
                  inputMode="tel"
                  autoComplete="off"
                  placeholder="98XXXXXXXX"
                  aria-invalid={errors.driverPhone ? true : undefined}
                  value={driverPhone}
                  onChange={(event) => setDriverPhone(event.target.value)}
                />
              </FormField>
            </div>
          </>
        ) : null}

        {mode === 'bilti' ? (
          <>
            <div className="grid gap-5 sm:grid-cols-2">
              <FormField label="Transport company" htmlFor="dispatch-transport" error={errors.carrierOrVan}>
                <Input
                  id="dispatch-transport"
                  autoComplete="off"
                  placeholder="e.g. Sajha Yatayat"
                  aria-invalid={errors.carrierOrVan ? true : undefined}
                  value={carrierOrVan}
                  onChange={(event) => setCarrierOrVan(event.target.value)}
                />
              </FormField>
              <FormField label="Bilti number" htmlFor="dispatch-bilti" error={errors.biltiRef}>
                <Input
                  id="dispatch-bilti"
                  autoComplete="off"
                  className="figures"
                  aria-invalid={errors.biltiRef ? true : undefined}
                  value={biltiRef}
                  onChange={(event) => setBiltiRef(event.target.value)}
                />
              </FormField>
            </div>
            <Field>
              <FieldLabel>
                Bilti photo <span className="font-normal text-muted-foreground">(optional)</span>
              </FieldLabel>
              <ImageUpload kind="bilti_photo" label="Bilti photo" capture value={biltiPhotoFileId} onChange={setBiltiPhotoFileId} />
              <FieldDescription>The buyer uses it to collect the goods from the transport office.</FieldDescription>
            </Field>
          </>
        ) : null}

        <Field>
          <FieldLabel htmlFor="dispatch-note">
            {mode === 'pickup' ? 'Pickup details' : 'Delivery note'}{' '}
            <span className="font-normal text-muted-foreground">(optional)</span>
          </FieldLabel>
          <Textarea
            id="dispatch-note"
            rows={2}
            maxLength={300}
            placeholder={mode === 'pickup' ? 'e.g. Collected by Ramesh from the Kalimati godown.' : 'e.g. 12 cartons, arriving by 4 PM.'}
            value={note}
            onChange={(event) => setNote(event.target.value)}
          />
        </Field>
      </FieldGroup>
    </FormDialog>
  )
}
