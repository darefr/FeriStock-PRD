'use client'

import { PrinterIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'

/** Opens the browser's print dialog, where the receipt can be printed or saved as a PDF. */
export function PrintButton() {
  return (
    <Button type="button" onClick={() => window.print()}>
      <PrinterIcon data-icon="inline-start" />
      Print or save as PDF
    </Button>
  )
}
