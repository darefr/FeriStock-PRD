'use client'

import { useState, type FormEvent } from 'react'
import { OrganizationFields, type OrganizationDraft } from '@/components/org/organization-fields'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { updateOrganizationAction } from '@/lib/actions/org'
import { fieldErrors, organizationSchema } from '@/lib/validation'

export function BusinessForm({ organization }: { organization: OrganizationDraft }) {
  const [draft, setDraft] = useState(organization)
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})
  const save = useAction(updateOrganizationAction, { success: 'Business details saved.' })

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const parsed = organizationSchema.safeParse(draft)
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Business details</CardTitle>
        <CardDescription>Printed on every purchase order and receipt, so keep them as registered.</CardDescription>
      </CardHeader>
      <CardContent>
        <form id="business-form" onSubmit={handleSubmit} noValidate>
          <OrganizationFields
            value={draft}
            onChange={setDraft}
            errors={{ ...save.fields, ...localErrors }}
            idPrefix="business"
          />
        </form>
      </CardContent>
      <CardFooter className="justify-end">
        <Button type="submit" form="business-form" disabled={save.pending}>
          {save.pending ? <Spinner data-icon="inline-start" /> : null}
          Save changes
        </Button>
      </CardFooter>
    </Card>
  )
}
