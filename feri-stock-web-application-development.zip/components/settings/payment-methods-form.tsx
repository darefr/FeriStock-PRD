'use client'

import { ShieldCheckIcon } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { FormField } from '@/components/app/form-field'
import { ImageUpload } from '@/components/app/image-upload'
import { Segmented } from '@/components/app/segmented'
import { PasswordInput } from '@/components/auth/password-input'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { Switch } from '@/components/ui/switch'
import { useAction } from '@/hooks/use-action'
import { removeQrImageAction, updatePaymentConfigAction } from '@/lib/actions/org'
import type { GatewayEnv } from '@/lib/constants'
import type { PaymentConfigView } from '@/lib/domain/orgs'
import { fieldErrors, paymentConfigSchema } from '@/lib/validation'

const ENVIRONMENTS = [
  { value: 'test', label: 'Test' },
  { value: 'live', label: 'Live' },
] as const satisfies ReadonlyArray<{ value: GatewayEnv; label: string }>

const ENV_HINT = 'Test uses the gateway sandbox. Switch to Live only with your production merchant credentials.'

export function PaymentMethodsForm({ config }: { config: PaymentConfigView }) {
  const [esewaEnabled, setEsewaEnabled] = useState(config.esewa.enabled)
  const [esewaMerchantId, setEsewaMerchantId] = useState(config.esewa.merchantId)
  const [esewaSecret, setEsewaSecret] = useState('')
  const [esewaEnv, setEsewaEnv] = useState<GatewayEnv>(config.esewa.env)
  const [khaltiEnabled, setKhaltiEnabled] = useState(config.khalti.enabled)
  const [khaltiSecret, setKhaltiSecret] = useState('')
  const [khaltiEnv, setKhaltiEnv] = useState<GatewayEnv>(config.khalti.env)
  const [bank, setBank] = useState({
    bankName: config.bank?.bankName ?? '',
    accountName: config.bank?.accountName ?? '',
    accountNumber: config.bank?.accountNumber ?? '',
    branch: config.bank?.branch ?? '',
  })
  const [qrFileId, setQrFileId] = useState(config.qrFileId)
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})

  const save = useAction(updatePaymentConfigAction, {
    success: 'Payment methods saved.',
    onSuccess: () => {
      setEsewaSecret('')
      setKhaltiSecret('')
    },
  })
  const removeQr = useAction((_input: null) => removeQrImageAction(), { success: 'Payment QR removed.' })
  const errors = { ...save.fields, ...localErrors }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const parsed = paymentConfigSchema.safeParse({
      esewaEnabled,
      esewaMerchantId,
      esewaSecret,
      esewaEnv,
      khaltiEnabled,
      khaltiSecret,
      khaltiEnv,
      ...bank,
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  async function handleQrChange(fileId: string | null) {
    if (fileId) {
      setQrFileId(fileId)
      return
    }
    if (await removeQr.run(null)) setQrFileId(null)
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
      <Alert>
        <ShieldCheckIcon />
        <AlertTitle>Payments go straight to you</AlertTitle>
        <AlertDescription>
          Buyers pay into your own eSewa, Khalti or bank account. FeriStock never holds the money. Secret keys are
          encrypted before they are stored and are never shown again.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>eSewa</CardTitle>
          <CardDescription>Buyers check out with eSewa against your merchant account.</CardDescription>
          <CardAction>
            <Switch checked={esewaEnabled} onCheckedChange={setEsewaEnabled} aria-label="Accept eSewa payments" />
          </CardAction>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <FormField label="Merchant code" htmlFor="esewa-merchant" error={errors.esewaMerchantId} hint="Also called the product code.">
              <Input
                id="esewa-merchant"
                autoComplete="off"
                spellCheck={false}
                className="figures"
                aria-invalid={errors.esewaMerchantId ? true : undefined}
                value={esewaMerchantId}
                onChange={(event) => setEsewaMerchantId(event.target.value)}
              />
            </FormField>
            <FormField label="Secret key" htmlFor="esewa-secret" error={errors.esewaSecret}>
              <PasswordInput
                id="esewa-secret"
                autoComplete="new-password"
                placeholder={config.esewa.hasSecret ? 'Saved. Leave blank to keep it.' : ''}
                value={esewaSecret}
                onChange={(event) => setEsewaSecret(event.target.value)}
              />
            </FormField>
            <Field>
              <FieldLabel>Environment</FieldLabel>
              <Segmented label="eSewa environment" value={esewaEnv} onChange={setEsewaEnv} options={ENVIRONMENTS} />
              <FieldDescription>{ENV_HINT}</FieldDescription>
            </Field>
          </FieldGroup>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Khalti</CardTitle>
          <CardDescription>Buyers check out with Khalti against your merchant account.</CardDescription>
          <CardAction>
            <Switch checked={khaltiEnabled} onCheckedChange={setKhaltiEnabled} aria-label="Accept Khalti payments" />
          </CardAction>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <FormField
              label="Live or test secret key"
              htmlFor="khalti-secret"
              error={errors.khaltiSecret}
              hint="The key is checked with Khalti when you save."
            >
              <PasswordInput
                id="khalti-secret"
                autoComplete="new-password"
                placeholder={config.khalti.hasSecret ? 'Saved. Leave blank to keep it.' : ''}
                value={khaltiSecret}
                onChange={(event) => setKhaltiSecret(event.target.value)}
              />
            </FormField>
            <Field>
              <FieldLabel>Environment</FieldLabel>
              <Segmented label="Khalti environment" value={khaltiEnv} onChange={setKhaltiEnv} options={ENVIRONMENTS} />
              <FieldDescription>{ENV_HINT}</FieldDescription>
            </Field>
          </FieldGroup>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Bank transfer and QR</CardTitle>
          <CardDescription>
            Shown to buyers on accepted orders. They pay, then send the reference or a screenshot for you to confirm.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <div className="grid gap-5 sm:grid-cols-2">
              <FormField label="Bank name" htmlFor="bank-name" error={errors.bankName}>
                <Input
                  id="bank-name"
                  autoComplete="off"
                  value={bank.bankName}
                  onChange={(event) => setBank({ ...bank, bankName: event.target.value })}
                />
              </FormField>
              <FormField label="Branch" htmlFor="bank-branch" optional error={errors.branch}>
                <Input
                  id="bank-branch"
                  autoComplete="off"
                  value={bank.branch}
                  onChange={(event) => setBank({ ...bank, branch: event.target.value })}
                />
              </FormField>
              <FormField label="Account name" htmlFor="bank-account-name" error={errors.accountName}>
                <Input
                  id="bank-account-name"
                  autoComplete="off"
                  value={bank.accountName}
                  onChange={(event) => setBank({ ...bank, accountName: event.target.value })}
                />
              </FormField>
              <FormField label="Account number" htmlFor="bank-account-number" error={errors.accountNumber}>
                <Input
                  id="bank-account-number"
                  autoComplete="off"
                  inputMode="numeric"
                  className="figures"
                  value={bank.accountNumber}
                  onChange={(event) => setBank({ ...bank, accountNumber: event.target.value })}
                />
              </FormField>
            </div>
            <Field>
              <FieldLabel>Payment QR</FieldLabel>
              <ImageUpload
                kind="qr_image"
                label="Payment QR"
                value={qrFileId}
                disabled={removeQr.pending}
                onChange={(fileId) => void handleQrChange(fileId)}
              />
              <FieldDescription>
                Your Fonepay, eSewa or bank QR. It is saved as soon as it is uploaded.
              </FieldDescription>
            </Field>
          </FieldGroup>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" size="lg" disabled={save.pending}>
          {save.pending ? <Spinner data-icon="inline-start" /> : null}
          Save payment methods
        </Button>
      </div>
    </form>
  )
}
