'use client'

import { CopyIcon, UserMinusIcon, UserPlusIcon } from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { Segmented } from '@/components/app/segmented'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, FieldLabel } from '@/components/ui/field'
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { changeMemberRoleAction, createInviteAction, removeMemberAction, revokeInviteAction } from '@/lib/actions/org'
import { MEMBER_ROLES, MEMBER_ROLE_LABEL, type MemberRole } from '@/lib/constants'
import { formatDate } from '@/lib/dates'
import type { InviteDto, MemberDto } from '@/lib/domain/orgs'
import { formatInviteCode, initials } from '@/lib/format'

const ROLE_SUMMARY: Record<MemberRole, string> = {
  owner: 'Everything, including business details, payment credentials and the team.',
  manager: 'Orders, catalog, inventory, quotes and payments. No access to credentials or the team.',
  staff: 'Counts stock, packs and dispatches orders, and confirms deliveries.',
}

const INVITE_ROLES = [
  { value: 'manager', label: 'Manager' },
  { value: 'staff', label: 'Staff' },
] as const

export function TeamView({
  members,
  invites,
  canManage,
}: {
  members: MemberDto[]
  invites: InviteDto[]
  canManage: boolean
}) {
  const [inviteRole, setInviteRole] = useState<'manager' | 'staff'>('staff')
  const [removing, setRemoving] = useState<MemberDto | null>(null)

  const changeRole = useAction(changeMemberRoleAction, { success: 'Role updated.' })
  const remove = useAction(removeMemberAction, {
    success: 'Member removed.',
    onSuccess: () => setRemoving(null),
  })
  const createInvite = useAction(createInviteAction, { success: 'Invite code created.' })
  const revokeInvite = useAction(revokeInviteAction, { success: 'Invite code revoked.' })

  async function copyCode(code: string) {
    try {
      await navigator.clipboard.writeText(formatInviteCode(code))
      toast.success('Invite code copied.')
    } catch {
      toast.error('Could not copy. Select the code and copy it by hand.')
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Members</CardTitle>
          <CardDescription>People who can sign in to this organization.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="flex flex-col divide-y">
            {members.map((member) => (
              <li key={member.membershipId} className="flex flex-wrap items-center gap-3 py-3 first:pt-0 last:pb-0">
                <Avatar>
                  <AvatarFallback>{initials(member.name)}</AvatarFallback>
                </Avatar>
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{member.name}</span>
                    {member.isYou ? <Badge variant="secondary">You</Badge> : null}
                  </span>
                  <span className="truncate text-xs text-muted-foreground">{member.email}</span>
                </div>
                {canManage && !member.isYou ? (
                  <div className="flex items-center gap-1">
                    <NativeSelect
                      size="sm"
                      aria-label={`Role of ${member.name}`}
                      value={member.role}
                      disabled={changeRole.pending}
                      onChange={(event) =>
                        void changeRole.run({ membershipId: member.membershipId, role: event.target.value })
                      }
                    >
                      {MEMBER_ROLES.map((role) => (
                        <NativeSelectOption key={role} value={role}>
                          {MEMBER_ROLE_LABEL[role]}
                        </NativeSelectOption>
                      ))}
                    </NativeSelect>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={`Remove ${member.name}`}
                      onClick={() => setRemoving(member)}
                    >
                      <UserMinusIcon />
                    </Button>
                  </div>
                ) : (
                  <Badge variant="outline">{MEMBER_ROLE_LABEL[member.role]}</Badge>
                )}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {canManage ? (
        <Card>
          <CardHeader>
            <CardTitle>Invite someone</CardTitle>
            <CardDescription>
              Create a single-use code and share it. They create an account, choose “Join with a code” and enter it.
              Codes expire after 7 days.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="flex flex-wrap items-end gap-3">
              <Field className="w-auto">
                <FieldLabel>Role</FieldLabel>
                <Segmented label="Role for the invite" value={inviteRole} onChange={setInviteRole} options={INVITE_ROLES} />
              </Field>
              <Button
                type="button"
                disabled={createInvite.pending}
                onClick={() => void createInvite.run({ role: inviteRole })}
              >
                {createInvite.pending ? <Spinner data-icon="inline-start" /> : <UserPlusIcon data-icon="inline-start" />}
                Create invite code
              </Button>
            </div>

            {invites.length > 0 ? (
              <ul className="flex flex-col gap-2">
                {invites.map((invite) => (
                  <li
                    key={invite.id}
                    className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-lg border bg-background px-3 py-2.5"
                  >
                    <span className="figures text-base font-semibold tracking-wider">{formatInviteCode(invite.code)}</span>
                    <Badge variant="secondary">{MEMBER_ROLE_LABEL[invite.role]}</Badge>
                    <span className="flex-1 text-xs text-muted-foreground">Expires {formatDate(invite.expiresAt)}</span>
                    <div className="flex items-center gap-1">
                      <Button type="button" variant="outline" size="sm" onClick={() => void copyCode(invite.code)}>
                        <CopyIcon data-icon="inline-start" />
                        Copy
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        disabled={revokeInvite.pending}
                        onClick={() => void revokeInvite.run({ inviteId: invite.id })}
                      >
                        Revoke
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : null}
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>What each role can do</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="flex flex-col divide-y">
            {MEMBER_ROLES.map((role) => (
              <div key={role} className="flex flex-col gap-0.5 py-2.5 first:pt-0 last:pb-0 sm:flex-row sm:gap-4">
                <dt className="text-sm font-medium sm:w-24 sm:shrink-0">{MEMBER_ROLE_LABEL[role]}</dt>
                <dd className="text-sm leading-relaxed text-muted-foreground">{ROLE_SUMMARY[role]}</dd>
              </div>
            ))}
          </dl>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={removing !== null}
        onOpenChange={(open) => {
          if (!open) setRemoving(null)
        }}
        title={`Remove ${removing?.name ?? 'this member'}?`}
        description="They lose access to this organization straight away. Orders and stock changes they made stay on record."
        confirmLabel="Remove member"
        variant="destructive"
        pending={remove.pending}
        onConfirm={() => {
          if (removing) void remove.run({ membershipId: removing.membershipId })
        }}
      />
    </div>
  )
}
