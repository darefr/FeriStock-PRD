'use client'

import { useState, type FormEvent } from 'react'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormField } from '@/components/app/form-field'
import { RupeeInput } from '@/components/app/rupee-input'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSeparator,
  FieldSet,
} from '@/components/ui/field'
import { Spinner } from '@/components/ui/spinner'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { updateSupplierSettingsAction } from '@/lib/actions/org'
import { DELIVERY_MODES, DELIVERY_MODE_LABEL, type DeliveryMode } from '@/lib/constants'
import type { SupplierSettingsDto } from '@/lib/domain/orgs'
import { paisaToRupeeString, parseRupees } from '@/lib/money'
import { fieldErrors, supplierSettingsSchema } from '@/lib/validation'

const DELIVERY_HINT: Record<DeliveryMode, string> = {
  own_van: 'You deliver with your own vehicle and record the driver at dispatch.',
  bilti: 'You hand goods to a transport company and record the bilti number.',
  pickup: 'The shop collects the goods from your godown.',
}

export function SupplierTermsForm({ settings }: { settings: SupplierSettingsDto }) {
  const [modes, setModes] = useState<DeliveryMode[]>(settings.deliveryModes)
  const [deliveryNote, setDeliveryNote] = useState(settings.deliveryNote)
  const [minOrder, setMinOrder] = useState(settings.minOrderPaisa > 0 ? paisaToRupeeString(settings.minOrderPaisa) : '')
  const [creditEnabled, setCreditEnabled] = useState(settings.creditEnabled)
  const [creditDays, setCreditDays] = useState(String(settings.creditDays))
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})
  const save = useAction(updateSupplierSettingsAction, { success: 'Selling terms saved.' })
  const errors = { ...save.fields, ...localErrors }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const minOrderPaisa = minOrder.trim() === '' ? 0 : parseRupees(minOrder)
    if (minOrderPaisa === null) {
      setLocalErrors({ minOrderPaisa: 'Enter an amount in rupees, for example 5000.' })
      return
    }
    const parsed = supplierSettingsSchema.safeParse({
      deliveryModes: modes,
      deliveryNote,
      creditEnabled,
      creditDays: toInt(creditDays),
      minOrderPaisa,
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Selling terms</CardTitle>
        <CardDescription>Shops see these terms on your profile and in their cart before they order.</CardDescription>
      </CardHeader>
      <CardContent>
        <form id="terms-form" onSubmit={handleSubmit} noValidate>
          <FieldGroup>
            <FieldSet>
              <FieldLegend variant="label">How goods reach the shop</FieldLegend>
              <FieldGroup className="gap-3">
                {DELIVERY_MODES.map((mode) => (
                  <Field key={mode} orientation="horizontal">
                    <Checkbox
                      id={`mode-${mode}`}
                      checked={modes.includes(mode)}
                      onCheckedChange={(checked) =>
                        setModes((current) =>
                          checked ? [...new Set([...current, mode])] : current.filter((value) => value !== mode),
                        )
                      }
                    />
                    <FieldContent>
                      <FieldLabel htmlFor={`mode-${mode}`}>{DELIVERY_MODE_LABEL[mode]}</FieldLabel>
                      <FieldDescription>{DELIVERY_HINT[mode]}</FieldDescription>
                    </FieldContent>
                  </Field>
                ))}
              </FieldGroup>
              {errors.deliveryModes ? <FieldError>{errors.deliveryModes}</FieldError> : null}
            </FieldSet>

            <FormField
              label="Delivery note"
              htmlFor="delivery-note"
              optional
              error={errors.deliveryNote}
              hint="Areas you cover, dispatch days, delivery charges."
            >
              <Textarea
                id="delivery-note"
                rows={3}
                maxLength={300}
                placeholder="e.g. Free delivery inside Ring Road. Orders before 2 PM are dispatched the same day."
                value={deliveryNote}
                onChange={(event) => setDeliveryNote(event.target.value)}
              />
            </FormField>

            <FormField
              label="Minimum order value"
              htmlFor="min-order"
              optional
              error={errors.minOrderPaisa}
              hint="Orders below this total cannot be sent to you. Leave blank for no minimum."
            >
              <RupeeInput
                id="min-order"
                placeholder="0"
                aria-invalid={errors.minOrderPaisa ? true : undefined}
                value={minOrder}
                onValueChange={setMinOrder}
              />
            </FormField>

            <FieldSeparator />

            <Field orientation="horizontal">
              <FieldContent>
                <FieldLabel htmlFor="credit-enabled">Sell on udharo (credit)</FieldLabel>
                <FieldDescription>
                  Shops can ask to pay later. You approve each request and set its due date when you accept the order.
                </FieldDescription>
              </FieldContent>
              <Switch id="credit-enabled" checked={creditEnabled} onCheckedChange={setCreditEnabled} />
            </Field>

            {creditEnabled ? (
              <FormField
                label="Usual credit period (days)"
                htmlFor="credit-days"
                error={errors.creditDays}
                hint="Suggested as the due date when you approve credit. Between 1 and 180 days."
                className="max-w-56"
              >
                <DigitsInput
                  id="credit-days"
                  maxLength={3}
                  aria-invalid={errors.creditDays ? true : undefined}
                  value={creditDays}
                  onValueChange={setCreditDays}
                />
              </FormField>
            ) : null}
          </FieldGroup>
        </form>
      </CardContent>
      <CardFooter className="justify-end">
        <Button type="submit" form="terms-form" disabled={save.pending}>
          {save.pending ? <Spinner data-icon="inline-start" /> : null}
          Save terms
        </Button>
      </CardFooter>
    </Card>
  )
}
