'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

const SECTIONS = [
  { href: '/app/settings', label: 'Business', supplierOnly: false },
  { href: '/app/settings/selling', label: 'Selling terms', supplierOnly: true },
  { href: '/app/settings/payments', label: 'Payment methods', supplierOnly: true },
  { href: '/app/settings/team', label: 'Team', supplierOnly: false },
  { href: '/app/settings/account', label: 'My account', supplierOnly: false },
] as const

export function SettingsNav({ isSupplier }: { isSupplier: boolean }) {
  const pathname = usePathname()
  return (
    <nav aria-label="Settings sections" className="-mx-4 overflow-x-auto px-4 md:mx-0 md:px-0">
      <ul className="flex w-max min-w-full gap-1 border-b">
        {SECTIONS.filter((section) => isSupplier || !section.supplierOnly).map((section) => {
          const active = pathname === section.href
          return (
            <li key={section.href}>
              <Link
                href={section.href}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  '-mb-px inline-flex h-10 items-center whitespace-nowrap border-b-2 px-3 text-sm font-medium outline-none transition-colors focus-visible:ring-3 focus-visible:ring-ring/50',
                  active
                    ? 'border-primary text-foreground'
                    : 'border-transparent text-muted-foreground hover:text-foreground',
                )}
              >
                {section.label}
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
