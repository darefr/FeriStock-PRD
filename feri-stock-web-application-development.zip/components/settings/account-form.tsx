'use client'

import { useRouter } from 'next/navigation'
import { useState, type FormEvent } from 'react'
import { toast } from 'sonner'
import { FormField } from '@/components/app/form-field'
import { PasswordInput } from '@/components/auth/password-input'
import { SignOutButton } from '@/components/auth/sign-out-button'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { authClient } from '@/lib/auth-client'
import { credentialsSchema, profileSchema } from '@/lib/validation'

const OFFLINE = 'Could not reach FeriStock. Check your connection and try again.'

export function AccountForm({ name: initialName, email }: { name: string; email: string }) {
  const router = useRouter()
  const [name, setName] = useState(initialName)
  const [nameError, setNameError] = useState<string>()
  const [savingName, setSavingName] = useState(false)

  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [passwordErrors, setPasswordErrors] = useState<{ current?: string; next?: string }>({})
  const [savingPassword, setSavingPassword] = useState(false)

  async function handleName(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const parsed = profileSchema.safeParse({ name })
    if (!parsed.success) {
      setNameError(parsed.error.issues[0]?.message)
      return
    }
    setNameError(undefined)
    setSavingName(true)
    const result = await authClient.updateUser({ name: parsed.data.name }).catch(() => null)
    setSavingName(false)
    if (!result || result.error) {
      toast.error(result ? 'Your name could not be saved. Please try again.' : OFFLINE)
      return
    }
    toast.success('Name updated.')
    router.refresh()
  }

  async function handlePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const parsed = credentialsSchema.password.safeParse(newPassword)
    if (!parsed.success) {
      setPasswordErrors({ next: parsed.error.issues[0]?.message })
      return
    }
    if (newPassword === currentPassword) {
      setPasswordErrors({ next: 'Choose a password you have not used here before.' })
      return
    }
    setPasswordErrors({})
    setSavingPassword(true)
    const result = await authClient
      .changePassword({ currentPassword, newPassword, revokeOtherSessions: true })
      .catch(() => null)
    setSavingPassword(false)
    if (!result) {
      toast.error(OFFLINE)
      return
    }
    if (result.error) {
      setPasswordErrors({ current: 'That is not your current password.' })
      return
    }
    setCurrentPassword('')
    setNewPassword('')
    toast.success('Password changed. Other devices have been signed out.')
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Your profile</CardTitle>
          <CardDescription>Your name appears on the orders and stock changes you make.</CardDescription>
        </CardHeader>
        <CardContent>
          <form id="profile-form" onSubmit={handleName} noValidate>
            <FieldGroup>
              <FormField label="Full name" htmlFor="account-name" error={nameError}>
                <Input
                  id="account-name"
                  autoComplete="name"
                  aria-invalid={nameError ? true : undefined}
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                />
              </FormField>
              <FormField label="Email" htmlFor="account-email" hint="Used to log in. It cannot be changed here.">
                <Input id="account-email" type="email" value={email} readOnly disabled />
              </FormField>
            </FieldGroup>
          </form>
        </CardContent>
        <CardFooter className="justify-end">
          <Button type="submit" form="profile-form" disabled={savingName || name.trim() === initialName}>
            {savingName ? <Spinner data-icon="inline-start" /> : null}
            Save name
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Password</CardTitle>
          <CardDescription>Changing it signs you out on every other device.</CardDescription>
        </CardHeader>
        <CardContent>
          <form id="password-form" onSubmit={handlePassword} noValidate>
            <FieldGroup>
              <FormField label="Current password" htmlFor="current-password" error={passwordErrors.current}>
                <PasswordInput
                  id="current-password"
                  autoComplete="current-password"
                  aria-invalid={passwordErrors.current ? true : undefined}
                  value={currentPassword}
                  onChange={(event) => setCurrentPassword(event.target.value)}
                />
              </FormField>
              <FormField
                label="New password"
                htmlFor="new-password"
                error={passwordErrors.next}
                hint="At least 8 characters."
              >
                <PasswordInput
                  id="new-password"
                  autoComplete="new-password"
                  aria-invalid={passwordErrors.next ? true : undefined}
                  value={newPassword}
                  onChange={(event) => setNewPassword(event.target.value)}
                />
              </FormField>
            </FieldGroup>
          </form>
        </CardContent>
        <CardFooter className="justify-end">
          <Button type="submit" form="password-form" disabled={savingPassword || !currentPassword || !newPassword}>
            {savingPassword ? <Spinner data-icon="inline-start" /> : null}
            Change password
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Log out</CardTitle>
          <CardDescription>End your session on this device.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignOutButton variant="outline" />
        </CardContent>
      </Card>
    </div>
  )
}
