'use client'

import { CalendarClockIcon, PencilIcon, PlayIcon, PlusIcon, Trash2Icon } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { EmptyState } from '@/components/app/empty-state'
import { PageHeader } from '@/components/app/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardAction, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Spinner } from '@/components/ui/spinner'
import { Switch } from '@/components/ui/switch'
import { useAction } from '@/hooks/use-action'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import { deleteScheduleAction, runScheduleNowAction, setScheduleActiveAction } from '@/lib/actions/planning'
import { WEEKDAYS } from '@/lib/constants'
import { formatShortDateTime, formatTimeOfDay } from '@/lib/dates'
import type { ScheduleDto } from '@/lib/domain/schedules'
import { ScheduleDialog } from './schedule-dialog'

function describeTiming(schedule: ScheduleDto): string {
  const time = formatTimeOfDay(schedule.timeOfDay)
  return schedule.frequency === 'weekly'
    ? `Every ${WEEKDAYS[schedule.dayOfWeek ?? 0]} at ${time}`
    : `Day ${schedule.dayOfMonth ?? 1} of every month at ${time}`
}

export function SchedulesView({
  schedules,
  suppliers,
  canOrder,
}: {
  schedules: ScheduleDto[]
  suppliers: Array<{ id: string; name: string }>
  canOrder: boolean
}) {
  const router = useRouter()
  const [editing, setEditing] = useState<ScheduleDto | 'new' | null>(null)
  const [deleting, setDeleting] = useState<ScheduleDto | null>(null)
  const [runningId, setRunningId] = useState<string | null>(null)

  const setActive = useAction(setScheduleActiveAction)
  const remove = useAction(deleteScheduleAction, { success: 'Schedule deleted.', onSuccess: () => setDeleting(null) })
  const runNow = useAction(runScheduleNowAction, {
    success: ({ orderNo, status }) =>
      status === 'draft' ? `Draft ${orderNo} created. Review it and send.` : `Order ${orderNo} sent to the supplier.`,
    onSuccess: ({ orderId }) => {
      void refreshNavBadges()
      router.push(`/app/orders/${orderId}`)
    },
  })

  const newButton = canOrder ? (
    <Button onClick={() => setEditing('new')}>
      <PlusIcon data-icon="inline-start" />
      New schedule
    </Button>
  ) : null

  return (
    <>
      <PageHeader
        title="Schedules"
        description="Repeat restocks for what you buy every week or month. Each run prepares a purchase order."
        actions={schedules.length > 0 ? newButton : null}
      />

      {schedules.length === 0 ? (
        <EmptyState
          icon={CalendarClockIcon}
          title="No restock schedules yet"
          description="Set up a weekly or monthly order for your regular items. It can wait as a draft for your review, or go to the supplier automatically."
        >
          {newButton}
        </EmptyState>
      ) : (
        <ul className="grid gap-4 lg:grid-cols-2">
          {schedules.map((schedule) => (
            <li key={schedule.id}>
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="flex flex-wrap items-center gap-2">
                    {schedule.name}
                    <Badge variant={schedule.mode === 'auto' ? 'default' : 'secondary'}>
                      {schedule.mode === 'auto' ? 'Sends automatically' : 'Draft for review'}
                    </Badge>
                  </CardTitle>
                  <CardDescription>
                    {schedule.supplier.name} · {describeTiming(schedule)}
                  </CardDescription>
                  {canOrder ? (
                    <CardAction>
                      <Switch
                        checked={schedule.isActive}
                        disabled={setActive.pending}
                        aria-label={`${schedule.name} active`}
                        onCheckedChange={(isActive) => void setActive.run({ scheduleId: schedule.id, isActive })}
                      />
                    </CardAction>
                  ) : null}
                </CardHeader>
                <CardContent className="flex flex-col gap-3">
                  <ul className="flex flex-col gap-1 text-sm">
                    {schedule.items.map((item) => (
                      <li key={item.productId} className="flex items-baseline justify-between gap-3">
                        <span className={item.isActive ? 'min-w-0 truncate' : 'min-w-0 truncate text-muted-foreground line-through'}>
                          {item.name}
                        </span>
                        <span className="shrink-0 text-muted-foreground">
                          <span className="figures text-foreground">{item.qty}</span> {item.unit}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    {schedule.isActive ? `Next run ${formatShortDateTime(schedule.nextRunAt)}` : 'Paused'}
                    {schedule.lastOrder ? (
                      <>
                        {' · last order '}
                        <Link
                          href={`/app/orders/${schedule.lastOrder.id}`}
                          className="figures rounded-sm text-primary underline-offset-4 outline-none hover:underline focus-visible:ring-3 focus-visible:ring-ring/50"
                        >
                          {schedule.lastOrder.orderNo}
                        </Link>
                      </>
                    ) : null}
                  </p>
                </CardContent>
                {canOrder ? (
                  <CardFooter className="flex-wrap gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={runNow.pending}
                      onClick={() => {
                        setRunningId(schedule.id)
                        void runNow.run({ scheduleId: schedule.id })
                      }}
                    >
                      {runNow.pending && runningId === schedule.id ? (
                        <Spinner data-icon="inline-start" />
                      ) : (
                        <PlayIcon data-icon="inline-start" />
                      )}
                      Run now
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setEditing(schedule)}>
                      <PencilIcon data-icon="inline-start" />
                      Edit
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setDeleting(schedule)}>
                      <Trash2Icon data-icon="inline-start" />
                      Delete
                    </Button>
                  </CardFooter>
                ) : null}
              </Card>
            </li>
          ))}
        </ul>
      )}

      {editing ? (
        <ScheduleDialog
          key={editing === 'new' ? 'new' : editing.id}
          schedule={editing === 'new' ? null : editing}
          suppliers={suppliers}
          onClose={() => setEditing(null)}
        />
      ) : null}

      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(open) => {
          if (!open) setDeleting(null)
        }}
        title={`Delete “${deleting?.name ?? ''}”?`}
        description="No more orders are prepared from this schedule. Orders it already created are kept."
        confirmLabel="Delete schedule"
        variant="destructive"
        pending={remove.pending}
        onConfirm={() => {
          if (deleting) void remove.run({ scheduleId: deleting.id })
        }}
      />
    </>
  )
}
