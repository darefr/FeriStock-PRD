'use client'

import { Trash2Icon } from 'lucide-react'
import { useState } from 'react'
import useSWR from 'swr'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { QtyStepper } from '@/components/app/qty-stepper'
import { Segmented } from '@/components/app/segmented'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel, FieldLegend, FieldSet } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { saveScheduleAction } from '@/lib/actions/planning'
import { WEEKDAYS, type ScheduleFrequency, type ScheduleMode } from '@/lib/constants'
import type { CatalogProductDto } from '@/lib/domain/catalog'
import type { ScheduleDto } from '@/lib/domain/schedules'
import { fetcher } from '@/lib/fetcher'
import { fieldErrors, scheduleSchema } from '@/lib/validation'

type Line = { productId: string; name: string; unit: string; qty: number; moq: number; isActive: boolean }

const MONTH_DAYS = Array.from({ length: 28 }, (_, index) => index + 1)

/** Create a recurring restock, or edit one when `schedule` is given. Mount it fresh each time (use a `key`). */
export function ScheduleDialog({
  schedule,
  suppliers,
  onClose,
}: {
  schedule: ScheduleDto | null
  suppliers: Array<{ id: string; name: string }>
  onClose: () => void
}) {
  const [name, setName] = useState(schedule?.name ?? '')
  const [supplierId, setSupplierId] = useState(schedule?.supplier.id ?? suppliers[0]?.id ?? '')
  const [frequency, setFrequency] = useState<ScheduleFrequency>(schedule?.frequency ?? 'weekly')
  const [dayOfWeek, setDayOfWeek] = useState(schedule?.dayOfWeek ?? 0)
  const [dayOfMonth, setDayOfMonth] = useState(schedule?.dayOfMonth ?? 1)
  const [timeOfDay, setTimeOfDay] = useState(schedule?.timeOfDay ?? '07:00')
  const [mode, setMode] = useState<ScheduleMode>(schedule?.mode ?? 'draft')
  const [lines, setLines] = useState<Line[]>(schedule?.items ?? [])
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})

  const { data, isLoading } = useSWR<{ products: CatalogProductDto[] }>(
    supplierId ? `/api/catalog/search?supplierId=${supplierId}` : null,
    fetcher,
  )
  const available = (data?.products ?? []).filter((product) => !lines.some((line) => line.productId === product.id))

  const save = useAction(saveScheduleAction, {
    success: schedule ? 'Schedule updated.' : 'Schedule created.',
    onSuccess: onClose,
  })
  const errors = { ...save.fields, ...localErrors }

  function handleSubmit() {
    const parsed = scheduleSchema.safeParse({
      id: schedule?.id ?? null,
      supplierOrgId: supplierId,
      name,
      frequency,
      dayOfWeek: frequency === 'weekly' ? dayOfWeek : null,
      dayOfMonth: frequency === 'monthly' ? dayOfMonth : null,
      timeOfDay,
      mode,
      isActive: schedule?.isActive ?? true,
      items: lines.map((line) => ({ productId: line.productId, qty: line.qty })),
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  function addProduct(productId: string) {
    const product = data?.products.find((candidate) => candidate.id === productId)
    if (!product) return
    setLines((current) => [
      ...current,
      { productId: product.id, name: product.name, unit: product.unit, qty: product.moq, moq: product.moq, isActive: true },
    ])
  }

  return (
    <FormDialog
      open
      size="lg"
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title={schedule ? 'Edit restock schedule' : 'New restock schedule'}
      description="A purchase order is prepared on this timetable, at the supplier's prices on the day."
      onSubmit={handleSubmit}
      submitLabel={schedule ? 'Save schedule' : 'Create schedule'}
      submitDisabled={suppliers.length === 0}
      pending={save.pending}
    >
      <FieldGroup>
        <div className="grid gap-5 sm:grid-cols-2">
          <FormField label="Name" htmlFor="schedule-name" error={errors.name}>
            <Input
              id="schedule-name"
              autoComplete="off"
              placeholder="e.g. Weekly noodles and biscuits"
              aria-invalid={errors.name ? true : undefined}
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </FormField>
          <FormField
            label="Supplier"
            htmlFor="schedule-supplier"
            error={errors.supplierOrgId}
            hint={schedule ? 'To order from another supplier, create a new schedule.' : undefined}
          >
            <NativeSelect
              id="schedule-supplier"
              className="w-full"
              disabled={schedule !== null}
              value={supplierId}
              onChange={(event) => {
                setSupplierId(event.target.value)
                setLines([])
              }}
            >
              {suppliers.map((supplier) => (
                <NativeSelectOption key={supplier.id} value={supplier.id}>
                  {supplier.name}
                </NativeSelectOption>
              ))}
            </NativeSelect>
          </FormField>
        </div>

        <FieldSet>
          <FieldLegend variant="label">When</FieldLegend>
          <div className="flex flex-wrap items-end gap-3">
            <Segmented
              label="How often"
              value={frequency}
              onChange={setFrequency}
              options={[
                { value: 'weekly', label: 'Every week' },
                { value: 'monthly', label: 'Every month' },
              ]}
            />
            {frequency === 'weekly' ? (
              <NativeSelect
                aria-label="Day of the week"
                value={dayOfWeek}
                onChange={(event) => setDayOfWeek(Number(event.target.value))}
              >
                {WEEKDAYS.map((day, index) => (
                  <NativeSelectOption key={day} value={index}>
                    {day}
                  </NativeSelectOption>
                ))}
              </NativeSelect>
            ) : (
              <NativeSelect
                aria-label="Day of the month"
                value={dayOfMonth}
                onChange={(event) => setDayOfMonth(Number(event.target.value))}
              >
                {MONTH_DAYS.map((day) => (
                  <NativeSelectOption key={day} value={day}>
                    Day {day}
                  </NativeSelectOption>
                ))}
              </NativeSelect>
            )}
            <Input
              type="time"
              aria-label="Time of day"
              className="figures w-32"
              value={timeOfDay}
              onChange={(event) => setTimeOfDay(event.target.value)}
            />
          </div>
          <FieldDescription>Nepal time. Monthly schedules run on days 1 to 28 so no month is skipped.</FieldDescription>
          {errors.timeOfDay ? <FieldError>{errors.timeOfDay}</FieldError> : null}
        </FieldSet>

        <Field>
          <FieldLabel>What happens on the day</FieldLabel>
          <Segmented
            label="What happens on the day"
            value={mode}
            onChange={setMode}
            options={[
              { value: 'draft', label: 'Create a draft' },
              { value: 'auto', label: 'Send automatically' },
            ]}
          />
          <FieldDescription>
            {mode === 'draft'
              ? 'A draft waits under Purchases for you to check and send.'
              : 'The order goes straight to the supplier without a review.'}
          </FieldDescription>
        </Field>

        <FieldSet>
          <FieldLegend variant="label">Items to order each time</FieldLegend>
          {lines.length > 0 ? (
            <ul className="flex flex-col divide-y">
              {lines.map((line) => (
                <li key={line.productId} className="flex items-center justify-between gap-3 py-2.5 first:pt-0">
                  <div className="flex min-w-0 flex-col gap-0.5">
                    <span className="text-pretty text-sm font-medium">{line.name}</span>
                    <span className="text-xs text-muted-foreground">
                      Minimum {line.moq} {line.unit}
                    </span>
                    {line.isActive ? null : (
                      <Badge variant="destructive">No longer supplied. Remove it to save.</Badge>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <QtyStepper
                      label={line.name}
                      min={1}
                      value={line.qty}
                      onChange={(qty) =>
                        setLines((current) =>
                          current.map((row) => (row.productId === line.productId ? { ...row, qty } : row)),
                        )
                      }
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={`Remove ${line.name}`}
                      onClick={() => setLines((current) => current.filter((row) => row.productId !== line.productId))}
                    >
                      <Trash2Icon />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          ) : null}

          {isLoading ? (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Spinner /> Loading this supplier&apos;s catalog…
            </p>
          ) : available.length > 0 ? (
            <NativeSelect
              aria-label="Add a product"
              className="w-full"
              value=""
              onChange={(event) => addProduct(event.target.value)}
            >
              <NativeSelectOption value="" disabled>
                Add a product…
              </NativeSelectOption>
              {available.map((product) => (
                <NativeSelectOption key={product.id} value={product.id}>
                  {product.name} ({product.unit})
                </NativeSelectOption>
              ))}
            </NativeSelect>
          ) : lines.length === 0 ? (
            <p className="text-sm leading-relaxed text-muted-foreground">
              {suppliers.length === 0
                ? 'There are no suppliers to order from yet.'
                : 'This supplier has no products listed yet.'}
            </p>
          ) : null}
          {errors.items ? <FieldError>{errors.items}</FieldError> : null}
        </FieldSet>
      </FieldGroup>
    </FormDialog>
  )
}
