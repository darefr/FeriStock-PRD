'use client'

import { BoxesIcon, PlusIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'
import useSWR from 'swr'
import { EmptyState } from '@/components/app/empty-state'
import { FilterBar } from '@/components/app/filter-bar'
import { PageHeader } from '@/components/app/page-header'
import { SearchInput } from '@/components/app/search-input'
import { ReorderLowStockButton } from '@/components/dashboard/reorder-low-stock-button'
import { Button } from '@/components/ui/button'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import type { InventoryItemDto } from '@/lib/domain/inventory'
import { stockStatus } from '@/lib/domain/stock-rules'
import { fetcher } from '@/lib/fetcher'
import { AddItemDialog } from './add-item-dialog'
import { ItemSheet } from './item-sheet'
import { StockRow } from './stock-row'

export type InventoryFilter = 'all' | 'restock' | 'ok'

const SEVERITY = { out: 0, low: 1, ok: 2 } as const

export function InventoryView({
  initialItems,
  initialFilter,
  canManage,
  canOrder,
}: {
  initialItems: InventoryItemDto[]
  initialFilter: InventoryFilter
  canManage: boolean
  canOrder: boolean
}) {
  // Polled so counts made on another phone in the shop show up here without a reload.
  const { data, mutate } = useSWR<{ items: InventoryItemDto[] }>('/api/inventory', fetcher, {
    fallbackData: { items: initialItems },
    refreshInterval: 20_000,
  })
  const items = data?.items ?? initialItems

  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<InventoryFilter>(initialFilter)
  const [adding, setAdding] = useState(false)
  const [openItemId, setOpenItemId] = useState<string | null>(null)
  const openItem = items.find((item) => item.id === openItemId) ?? null

  const reload = () => {
    void mutate()
    void refreshNavBadges()
  }

  const confirmQty = (inventoryId: string, qty: number) => {
    void mutate(
      (current) =>
        current && {
          items: current.items.map((item) =>
            item.id === inventoryId
              ? { ...item, currentQty: qty, status: stockStatus(qty, item.reorderThreshold) }
              : item,
          ),
        },
      { revalidate: true },
    )
    void refreshNavBadges()
  }

  const restockCount = items.filter((item) => item.status !== 'ok').length
  const term = query.trim().toLowerCase()
  const visible = items
    .filter((item) => {
      if (filter === 'restock' && item.status === 'ok') return false
      if (filter === 'ok' && item.status !== 'ok') return false
      if (!term) return true
      return [item.name, item.sku ?? '', item.supplier?.name ?? ''].some((value) => value.toLowerCase().includes(term))
    })
    .sort((a, b) => (filter === 'restock' ? SEVERITY[a.status] - SEVERITY[b.status] : 0))

  return (
    <>
      <PageHeader
        title="Inventory"
        description="Count stock up and down as you sell and receive. Items at or below their reorder level are flagged."
        actions={
          <>
            {canOrder && restockCount > 0 ? <ReorderLowStockButton variant="outline" /> : null}
            {canManage ? (
              <Button onClick={() => setAdding(true)}>
                <PlusIcon data-icon="inline-start" />
                Add item
              </Button>
            ) : null}
          </>
        }
      />

      {items.length === 0 ? (
        <EmptyState
          icon={BoxesIcon}
          title="No items tracked yet"
          description="Add the products you stock. Linking them to a supplier's catalog lets you reorder low items in one tap."
        >
          <div className="flex flex-wrap justify-center gap-2">
            {canManage ? (
              <Button onClick={() => setAdding(true)}>
                <PlusIcon data-icon="inline-start" />
                Add your first item
              </Button>
            ) : null}
            <Button variant="outline" nativeButton={false} render={<Link href="/app/suppliers" />}>
              Browse suppliers
            </Button>
          </div>
        </EmptyState>
      ) : (
        <>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <SearchInput
              label="Search inventory"
              placeholder="Search by item, SKU or supplier"
              value={query}
              onValueChange={setQuery}
              className="sm:max-w-xs"
            />
            <FilterBar
              label="Filter by stock status"
              value={filter}
              onChange={setFilter}
              options={[
                { value: 'all', label: 'All', count: items.length },
                { value: 'restock', label: 'To restock', count: restockCount },
                { value: 'ok', label: 'OK', count: items.length - restockCount },
              ]}
            />
          </div>

          {visible.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              {filter === 'restock' && !term ? 'Nothing needs restocking.' : 'No items match.'}
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {visible.map((item) => (
                <StockRow
                  key={item.id}
                  item={item}
                  canOrder={canOrder}
                  onConfirmed={confirmQty}
                  onResync={reload}
                  onOpen={setOpenItemId}
                />
              ))}
            </ul>
          )}
        </>
      )}

      {adding ? <AddItemDialog onClose={() => setAdding(false)} onAdded={reload} /> : null}
      {openItem ? (
        <ItemSheet
          key={openItem.id}
          item={openItem}
          canManage={canManage}
          onClose={() => setOpenItemId(null)}
          onChanged={reload}
        />
      ) : null}
    </>
  )
}
