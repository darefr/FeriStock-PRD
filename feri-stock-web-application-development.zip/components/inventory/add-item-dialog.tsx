'use client'

import { CheckIcon } from 'lucide-react'
import { useRef, useState } from 'react'
import useSWR from 'swr'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormDialog } from '@/components/app/form-dialog'
import { FormField } from '@/components/app/form-field'
import { Money } from '@/components/app/money'
import { SearchInput } from '@/components/app/search-input'
import { Segmented } from '@/components/app/segmented'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { FieldGroup } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { addInventoryItemAction } from '@/lib/actions/inventory'
import { COMMON_UNITS } from '@/lib/constants'
import type { CatalogProductDto } from '@/lib/domain/catalog'
import { fetcher } from '@/lib/fetcher'
import { addInventorySchema, fieldErrors } from '@/lib/validation'

export type TrackableProduct = { id: string; name: string; unit: string; moq: number; supplierName: string }

type Levels = { currentQty: string; reorderThreshold: string; reorderQty: string }
const EMPTY_LEVELS: Levels = { currentQty: '', reorderThreshold: '', reorderQty: '' }

function StockLevelFields({
  levels,
  onChange,
  errors,
  unit,
  showReorderQty,
}: {
  levels: Levels
  onChange: (levels: Levels) => void
  errors: Record<string, string>
  unit: string
  showReorderQty: boolean
}) {
  const suffix = unit ? ` (${unit})` : ''
  return (
    <>
      <div className="grid gap-5 sm:grid-cols-2">
        <FormField label={`In stock now${suffix}`} htmlFor="level-current" error={errors.currentQty}>
          <DigitsInput
            id="level-current"
            placeholder="0"
            value={levels.currentQty}
            onValueChange={(currentQty) => onChange({ ...levels, currentQty })}
          />
        </FormField>
        <FormField
          label={`Reorder level${suffix}`}
          htmlFor="level-threshold"
          error={errors.reorderThreshold}
          hint="Marked low at or below this."
        >
          <DigitsInput
            id="level-threshold"
            placeholder="0"
            value={levels.reorderThreshold}
            onValueChange={(reorderThreshold) => onChange({ ...levels, reorderThreshold })}
          />
        </FormField>
      </div>
      {showReorderQty ? (
        <FormField
          label={`Restock quantity${suffix}`}
          htmlFor="level-reorder"
          optional
          error={errors.reorderQty}
          hint="How much to order each time. Left blank, FeriStock tops you up to twice the reorder level."
        >
          <DigitsInput
            id="level-reorder"
            value={levels.reorderQty}
            onValueChange={(reorderQty) => onChange({ ...levels, reorderQty })}
          />
        </FormField>
      ) : null}
    </>
  )
}

function useAddItem(onAdded: () => void, success: string) {
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})
  const add = useAction(addInventoryItemAction, { success, onSuccess: onAdded })

  function submit(input: { productId: string | null; customName: string; customUnit: string; levels: Levels }) {
    const parsed = addInventorySchema.safeParse({
      productId: input.productId,
      customName: input.customName,
      customUnit: input.customUnit,
      currentQty: toInt(input.levels.currentQty),
      reorderThreshold: toInt(input.levels.reorderThreshold),
      reorderQty: input.levels.reorderQty === '' ? null : toInt(input.levels.reorderQty),
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void add.run(parsed.data)
  }

  return { submit, pending: add.pending, errors: { ...add.fields, ...localErrors } }
}

/** Start tracking stock for a product that has already been chosen, for example from a supplier's catalog. */
export function TrackProductDialog({
  product,
  onClose,
  onAdded,
}: {
  product: TrackableProduct
  onClose: () => void
  onAdded?: () => void
}) {
  const [levels, setLevels] = useState(EMPTY_LEVELS)
  const add = useAddItem(() => {
    onAdded?.()
    onClose()
  }, `${product.name} is now in your inventory.`)

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Track this item"
      description={`${product.name} from ${product.supplierName}. Count it in your inventory and reorder it in one tap.`}
      onSubmit={() => add.submit({ productId: product.id, customName: '', customUnit: '', levels })}
      submitLabel="Add to inventory"
      pending={add.pending}
    >
      <FieldGroup>
        <StockLevelFields levels={levels} onChange={setLevels} errors={add.errors} unit={product.unit} showReorderQty />
      </FieldGroup>
    </FormDialog>
  )
}

type Mode = 'catalog' | 'custom'

export function AddItemDialog({ onClose, onAdded }: { onClose: () => void; onAdded: () => void }) {
  const [mode, setMode] = useState<Mode>('catalog')
  const [query, setQuery] = useState('')
  const [search, setSearch] = useState('')
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [selected, setSelected] = useState<CatalogProductDto | null>(null)
  const [customName, setCustomName] = useState('')
  const [customUnit, setCustomUnit] = useState('')
  const [levels, setLevels] = useState(EMPTY_LEVELS)

  const add = useAddItem(() => {
    onAdded()
    onClose()
  }, 'Item added to your inventory.')

  const { data, isLoading } = useSWR<{ products: CatalogProductDto[] }>(
    mode === 'catalog' && !selected ? `/api/catalog/search?q=${encodeURIComponent(search)}` : null,
    fetcher,
    { keepPreviousData: true },
  )
  const results = data?.products ?? []

  function handleQuery(value: string) {
    setQuery(value)
    if (searchTimer.current) clearTimeout(searchTimer.current)
    searchTimer.current = setTimeout(() => setSearch(value.trim()), 250)
  }

  const canSubmit = mode === 'custom' || selected !== null

  return (
    <FormDialog
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
      title="Add an item to inventory"
      description="Pick a product from a supplier's catalog so it can be reordered in one tap, or add your own item."
      onSubmit={() =>
        add.submit({
          productId: mode === 'catalog' ? (selected?.id ?? null) : null,
          customName: mode === 'custom' ? customName : '',
          customUnit: mode === 'custom' ? customUnit : '',
          levels,
        })
      }
      submitLabel="Add to inventory"
      submitDisabled={!canSubmit}
      pending={add.pending}
    >
      <FieldGroup>
        <Segmented
          label="Where the item comes from"
          value={mode}
          onChange={setMode}
          options={[
            { value: 'catalog', label: 'From a supplier' },
            { value: 'custom', label: 'My own item' },
          ]}
        />

        {mode === 'catalog' && !selected ? (
          <div className="flex flex-col gap-3">
            <SearchInput label="Search supplier products" placeholder="Search by product name or SKU" value={query} onValueChange={handleQuery} />
            {isLoading && results.length === 0 ? (
              <p className="flex items-center gap-2 py-4 text-sm text-muted-foreground">
                <Spinner /> Searching catalogs…
              </p>
            ) : results.length === 0 ? (
              <p className="py-4 text-sm leading-relaxed text-muted-foreground">
                {search
                  ? 'No supplier lists a product with that name. Add it as your own item and ask a supplier for a quote.'
                  : 'No supplier has published products yet.'}
              </p>
            ) : (
              <ul className="flex max-h-72 flex-col gap-1.5 overflow-y-auto">
                {results.map((product) => (
                  <li key={product.id}>
                    <button
                      type="button"
                      disabled={product.inventoryId !== null}
                      onClick={() => setSelected(product)}
                      className="flex w-full items-center gap-3 rounded-lg border bg-background px-3 py-2 text-left outline-none transition-colors hover:bg-accent/60 focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:bg-background"
                    >
                      <span className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate text-sm font-medium">{product.name}</span>
                        <span className="truncate text-xs text-muted-foreground">
                          {product.supplierName} · <Money paisa={product.pricePaisa} /> / {product.unit}
                        </span>
                      </span>
                      {product.inventoryId !== null ? <Badge variant="secondary">Tracked</Badge> : null}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ) : null}

        {mode === 'catalog' && selected ? (
          <>
            <div className="flex items-center gap-3 rounded-lg border bg-accent/50 px-3 py-2">
              <CheckIcon className="size-4 shrink-0 text-success" aria-hidden="true" />
              <span className="flex min-w-0 flex-1 flex-col">
                <span className="truncate text-sm font-medium">{selected.name}</span>
                <span className="truncate text-xs text-muted-foreground">
                  {selected.supplierName} · minimum order {selected.moq} {selected.unit}
                </span>
              </span>
              <Button type="button" variant="ghost" size="sm" onClick={() => setSelected(null)}>
                Change
              </Button>
            </div>
            <StockLevelFields levels={levels} onChange={setLevels} errors={add.errors} unit={selected.unit} showReorderQty />
          </>
        ) : null}

        {mode === 'custom' ? (
          <>
            <div className="grid gap-5 sm:grid-cols-[2fr_1fr]">
              <FormField label="Item name" htmlFor="custom-name" error={add.errors.customName}>
                <Input
                  id="custom-name"
                  autoComplete="off"
                  placeholder="e.g. Local honey 500g"
                  aria-invalid={add.errors.customName ? true : undefined}
                  value={customName}
                  onChange={(event) => setCustomName(event.target.value)}
                />
              </FormField>
              <FormField label="Unit" htmlFor="custom-unit" error={add.errors.customUnit}>
                <Input
                  id="custom-unit"
                  list="custom-units"
                  autoComplete="off"
                  placeholder="pcs"
                  aria-invalid={add.errors.customUnit ? true : undefined}
                  value={customUnit}
                  onChange={(event) => setCustomUnit(event.target.value.slice(0, 20))}
                />
                <datalist id="custom-units">
                  {COMMON_UNITS.map((unit) => (
                    <option key={unit} value={unit} />
                  ))}
                </datalist>
              </FormField>
            </div>
            <StockLevelFields levels={levels} onChange={setLevels} errors={add.errors} unit={customUnit} showReorderQty={false} />
          </>
        ) : null}
      </FieldGroup>
    </FormDialog>
  )
}
