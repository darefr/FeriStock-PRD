'use client'

import Link from 'next/link'
import { useState } from 'react'
import useSWR from 'swr'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormField } from '@/components/app/form-field'
import { Button } from '@/components/ui/button'
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Separator } from '@/components/ui/separator'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Skeleton } from '@/components/ui/skeleton'
import { Spinner } from '@/components/ui/spinner'
import { Switch } from '@/components/ui/switch'
import { useAction } from '@/hooks/use-action'
import { archiveInventoryItemAction, updateInventorySettingsAction } from '@/lib/actions/inventory'
import type { StockReason } from '@/lib/constants'
import { formatShortDateTime } from '@/lib/dates'
import type { InventoryItemDto, StockMovementDto } from '@/lib/domain/inventory'
import { fetcher } from '@/lib/fetcher'
import { cn } from '@/lib/utils'
import { fieldErrors, inventorySettingsSchema } from '@/lib/validation'

const REASON_LABEL: Record<StockReason, string> = {
  initial: 'Opening stock',
  manual: 'Counted',
  correction: 'Recount',
  delivery: 'Delivery received',
}

function History({ inventoryId }: { inventoryId: string }) {
  const { data, error } = useSWR<{ movements: StockMovementDto[] }>(`/api/inventory/${inventoryId}/history`, fetcher)

  if (error) return <p className="text-sm text-muted-foreground">The history could not be loaded.</p>
  if (!data) {
    return (
      <div className="flex flex-col gap-2" role="status" aria-label="Loading history">
        <Skeleton className="h-10" />
        <Skeleton className="h-10" />
        <Skeleton className="h-10" />
      </div>
    )
  }
  if (data.movements.length === 0) return <p className="text-sm text-muted-foreground">No stock changes yet.</p>

  return (
    <ul className="flex flex-col divide-y">
      {data.movements.map((movement) => (
        <li key={movement.id} className="flex items-center justify-between gap-3 py-2 first:pt-0 last:pb-0">
          <div className="flex min-w-0 flex-col">
            <span className="text-sm">
              {REASON_LABEL[movement.reason]}
              {movement.orderId && movement.orderNo ? (
                <>
                  {' · '}
                  <Link href={`/app/orders/${movement.orderId}`} className="figures text-primary underline-offset-4 hover:underline">
                    {movement.orderNo}
                  </Link>
                </>
              ) : null}
            </span>
            <span className="truncate text-xs text-muted-foreground">
              {movement.userName ?? 'FeriStock'} · {formatShortDateTime(movement.createdAt)}
            </span>
          </div>
          <div className="flex shrink-0 flex-col items-end">
            <span className={cn('figures text-sm font-medium', movement.delta > 0 ? 'text-success' : 'text-destructive')}>
              {movement.delta > 0 ? '+' : '−'}
              {Math.abs(movement.delta)}
            </span>
            <span className="figures text-xs text-muted-foreground">= {movement.qtyAfter}</span>
          </div>
        </li>
      ))}
    </ul>
  )
}

/** Reorder settings and the stock ledger for one item. Mount it fresh per item (use a `key`). */
export function ItemSheet({
  item,
  canManage,
  onClose,
  onChanged,
}: {
  item: InventoryItemDto
  canManage: boolean
  onClose: () => void
  onChanged: () => void
}) {
  const [threshold, setThreshold] = useState(String(item.reorderThreshold))
  const [reorderQty, setReorderQty] = useState(item.reorderQty === null ? '' : String(item.reorderQty))
  const [alertsEnabled, setAlertsEnabled] = useState(item.alertsEnabled)
  const [autoReorder, setAutoReorder] = useState(item.autoReorder)
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})
  const [confirmingArchive, setConfirmingArchive] = useState(false)

  const save = useAction(updateInventorySettingsAction, { success: 'Reorder settings saved.', onSuccess: onChanged })
  const archive = useAction(archiveInventoryItemAction, {
    success: `${item.name} is no longer tracked.`,
    onSuccess: () => {
      onChanged()
      onClose()
    },
  })
  const errors = { ...save.fields, ...localErrors }

  function handleSave() {
    const parsed = inventorySettingsSchema.safeParse({
      inventoryId: item.id,
      reorderThreshold: toInt(threshold),
      reorderQty: reorderQty === '' ? null : toInt(reorderQty),
      alertsEnabled,
      autoReorder,
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void save.run(parsed.data)
  }

  return (
    <Sheet
      open
      onOpenChange={(open) => {
        if (!open) onClose()
      }}
    >
      <SheetContent className="gap-0 overflow-y-auto data-[side=right]:w-full data-[side=right]:sm:max-w-md">
        <SheetHeader className="pr-12">
          <SheetTitle>{item.name}</SheetTitle>
          <SheetDescription>
            {item.sku ? `${item.sku} · ` : ''}
            {item.supplier?.name ?? 'Your own item'} · {item.currentQty} {item.unit} in stock
          </SheetDescription>
        </SheetHeader>

        <div className="flex flex-col gap-6 px-4 pb-6">
          {canManage ? (
            <form
              noValidate
              onSubmit={(event) => {
                event.preventDefault()
                handleSave()
              }}
            >
              <FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Reorder level" htmlFor="sheet-threshold" error={errors.reorderThreshold}>
                    <DigitsInput id="sheet-threshold" value={threshold} onValueChange={setThreshold} />
                  </FormField>
                  <FormField label="Restock quantity" htmlFor="sheet-reorder" error={errors.reorderQty}>
                    <DigitsInput
                      id="sheet-reorder"
                      placeholder={item.suggestedQty === null ? 'Auto' : `Auto (${item.suggestedQty})`}
                      value={reorderQty}
                      onValueChange={setReorderQty}
                    />
                  </FormField>
                </div>
                <Field orientation="horizontal">
                  <FieldContent>
                    <FieldLabel htmlFor="sheet-alerts">Low-stock alerts</FieldLabel>
                    <FieldDescription>Count this item in the alerts on your overview and menu.</FieldDescription>
                  </FieldContent>
                  <Switch id="sheet-alerts" checked={alertsEnabled} onCheckedChange={setAlertsEnabled} />
                </Field>
                <Field orientation="horizontal">
                  <FieldContent>
                    <FieldLabel htmlFor="sheet-auto">Include in one-tap reorder</FieldLabel>
                    <FieldDescription>Added to the cart by “Reorder low stock” when it runs low.</FieldDescription>
                  </FieldContent>
                  <Switch id="sheet-auto" checked={autoReorder} onCheckedChange={setAutoReorder} />
                </Field>
                <Button type="submit" disabled={save.pending} className="w-fit">
                  {save.pending ? <Spinner data-icon="inline-start" /> : null}
                  Save settings
                </Button>
              </FieldGroup>
            </form>
          ) : null}

          {canManage ? <Separator /> : null}

          <section className="flex flex-col gap-3" aria-labelledby="history-heading">
            <h3 id="history-heading" className="text-sm font-medium">
              Stock history
            </h3>
            <History inventoryId={item.id} />
          </section>

          {canManage ? (
            <>
              <Separator />
              <div className="flex flex-col items-start gap-2">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Stop tracking this item if you no longer sell it. Its history is kept, and adding it again restores it.
                </p>
                <Button type="button" variant="destructive" onClick={() => setConfirmingArchive(true)}>
                  Stop tracking
                </Button>
              </div>
            </>
          ) : null}
        </div>

        <ConfirmDialog
          open={confirmingArchive}
          onOpenChange={setConfirmingArchive}
          title={`Stop tracking ${item.name}?`}
          description="It disappears from your inventory and from low-stock alerts. Its stock history is kept."
          confirmLabel="Stop tracking"
          variant="destructive"
          pending={archive.pending}
          onConfirm={() => void archive.run({ inventoryId: item.id })}
        />
      </SheetContent>
    </Sheet>
  )
}
