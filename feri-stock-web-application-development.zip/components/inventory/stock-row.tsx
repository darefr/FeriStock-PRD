'use client'

import { ShoppingCartIcon, SlidersHorizontalIcon } from 'lucide-react'
import Link from 'next/link'
import { useRef, useState } from 'react'
import { toast } from 'sonner'
import { QtyStepper } from '@/components/app/qty-stepper'
import { StockStatusBadge } from '@/components/app/status-badges'
import { Button } from '@/components/ui/button'
import { Spinner } from '@/components/ui/spinner'
import { useAction } from '@/hooks/use-action'
import { adjustStockAction, reorderToCartAction, setStockAction } from '@/lib/actions/inventory'
import type { ActionResult } from '@/lib/actions/types'
import type { InventoryItemDto } from '@/lib/domain/inventory'
import { stockStatus } from '@/lib/domain/stock-rules'

const TAP_WINDOW_MS = 450

/**
 * Counting at the counter means bursts of taps. They show on screen immediately and are sent as one
 * change once the tapping pauses; a typed count is sent as the exact number. Requests run one at a
 * time, and the row settles on the quantity the server reports.
 */
function useStockCount(item: InventoryItemDto, onConfirmed: (qty: number) => void, onResync: () => void) {
  const [optimistic, setOptimistic] = useState<number | null>(null)
  const pendingDelta = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const queue = useRef<Promise<void>>(Promise.resolve())
  const latestTicket = useRef(0)
  const shown = optimistic ?? item.currentQty

  function enqueue(request: (() => Promise<ActionResult<{ qty: number }>>) | null) {
    latestTicket.current += 1
    const ticket = latestTicket.current
    queue.current = queue.current.then(async () => {
      let confirmed: number | null = null
      if (request) {
        const result = await request().catch(() => null)
        if (result?.ok) confirmed = result.data.qty
        else toast.error(result?.error ?? 'Could not reach FeriStock. Check your connection and try again.')
      }
      const idle = ticket === latestTicket.current && pendingDelta.current === 0 && timer.current === null
      if (!idle) return
      if (confirmed === null) onResync()
      else onConfirmed(confirmed)
      setOptimistic(null)
    })
  }

  function flushTaps() {
    timer.current = null
    const delta = pendingDelta.current
    pendingDelta.current = 0
    enqueue(delta === 0 ? null : () => adjustStockAction({ inventoryId: item.id, delta }))
  }

  function change(next: number) {
    const delta = next - shown
    if (delta === 0) return
    setOptimistic(next)
    if (timer.current) clearTimeout(timer.current)

    if (Math.abs(delta) === 1) {
      pendingDelta.current += delta
      timer.current = setTimeout(flushTaps, TAP_WINDOW_MS)
      return
    }
    // A typed count replaces any taps that were still waiting to be sent.
    timer.current = null
    pendingDelta.current = 0
    enqueue(() => setStockAction({ inventoryId: item.id, qty: next }))
  }

  return { shown, change, saving: optimistic !== null }
}

export function StockRow({
  item,
  canOrder,
  onConfirmed,
  onResync,
  onOpen,
}: {
  item: InventoryItemDto
  canOrder: boolean
  /** The server confirmed a new quantity for this item. */
  onConfirmed: (inventoryId: string, qty: number) => void
  /** Something changed outside this row's control; reload the list. */
  onResync: () => void
  onOpen: (inventoryId: string) => void
}) {
  const count = useStockCount(item, (qty) => onConfirmed(item.id, qty), onResync)
  const status = stockStatus(count.shown, item.reorderThreshold)
  const reorder = useAction(reorderToCartAction, {
    onSuccess: ({ added }) => {
      if (added > 0) toast.success(`${item.name} added to your cart.`)
      else toast.info('This item cannot be ordered right now.')
      onResync()
    },
  })
  const orderable = item.suggestedQty !== null

  return (
    <li className="flex flex-col gap-3 rounded-lg border bg-card p-3 lg:flex-row lg:items-center lg:gap-4">
      <div className="flex min-w-0 flex-1 items-start justify-between gap-3">
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className="text-pretty text-sm font-medium">{item.name}</span>
          <span className="text-xs leading-relaxed text-muted-foreground">
            {item.sku ? <span className="figures">{item.sku} · </span> : null}
            {item.supplier?.name ?? 'Not linked to a supplier'}
            {item.reorderThreshold > 0 ? ` · reorder at ${item.reorderThreshold}` : ''}
          </span>
        </div>
        <StockStatusBadge status={status} className="mt-0.5" />
      </div>

      <div className="flex items-center justify-between gap-2 lg:justify-end lg:gap-3">
        <div className="flex items-center gap-2">
          <QtyStepper size="lg" label={item.name} value={count.shown} onChange={count.change} />
          <span className="text-sm text-muted-foreground">{item.unit}</span>
        </div>

        <div className="flex items-center gap-1">
          {canOrder && orderable ? (
            item.cartQty > 0 ? (
              <Button variant="secondary" size="sm" nativeButton={false} render={<Link href="/app/cart" />}>
                <ShoppingCartIcon data-icon="inline-start" />
                <span className="figures">{item.cartQty}</span> in cart
              </Button>
            ) : (
              <Button
                type="button"
                variant={status === 'ok' ? 'outline' : 'default'}
                size="sm"
                disabled={reorder.pending}
                onClick={() => void reorder.run({ inventoryIds: [item.id] })}
              >
                {reorder.pending ? <Spinner data-icon="inline-start" /> : <ShoppingCartIcon data-icon="inline-start" />}
                Reorder <span className="figures">{item.suggestedQty}</span>
              </Button>
            )
          ) : null}
          {canOrder && item.isCustom ? (
            <Button
              variant="outline"
              size="sm"
              nativeButton={false}
              render={
                <Link
                  href={`/app/quotes/new?item=${encodeURIComponent(item.name)}&unit=${encodeURIComponent(item.unit)}`}
                />
              }
            >
              Request quote
            </Button>
          ) : null}
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label={`Settings and history for ${item.name}`}
            onClick={() => onOpen(item.id)}
          >
            <SlidersHorizontalIcon />
          </Button>
        </div>
      </div>
    </li>
  )
}
