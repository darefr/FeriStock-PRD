'use client'

import { ChevronRightIcon, MapPinIcon, StoreIcon } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'
import { EmptyState } from '@/components/app/empty-state'
import { SearchInput } from '@/components/app/search-input'
import type { SupplierSummary } from '@/lib/domain/catalog'
import { pluralize } from '@/lib/format'
import { SupplierTerms } from './supplier-terms'

export function SuppliersView({ suppliers }: { suppliers: SupplierSummary[] }) {
  const [query, setQuery] = useState('')
  const term = query.trim().toLowerCase()
  const visible = term
    ? suppliers.filter((supplier) => [supplier.name, supplier.city, supplier.address].some((value) => value.toLowerCase().includes(term)))
    : suppliers

  if (suppliers.length === 0) {
    return (
      <EmptyState
        icon={StoreIcon}
        title="No suppliers on FeriStock yet"
        description="Wholesalers appear here as soon as they register. Invite yours to sign up as a supplier and publish their catalog."
      />
    )
  }

  return (
    <>
      <SearchInput
        label="Search suppliers"
        placeholder="Search by name or city"
        value={query}
        onValueChange={setQuery}
        className="sm:max-w-sm"
      />
      {visible.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">No suppliers match this search.</p>
      ) : (
        <ul className="grid gap-3 md:grid-cols-2">
          {visible.map((supplier) => (
            <li key={supplier.id}>
              <Link
                href={`/app/suppliers/${supplier.id}`}
                className="flex h-full flex-col gap-3 rounded-xl bg-card p-4 outline-none ring-1 ring-foreground/10 transition-colors hover:bg-accent/50 focus-visible:ring-3 focus-visible:ring-ring/50"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex min-w-0 flex-col gap-0.5">
                    <span className="text-pretty text-base font-semibold">{supplier.name}</span>
                    <span className="flex items-center gap-1 text-sm text-muted-foreground">
                      <MapPinIcon className="size-3.5 shrink-0" aria-hidden="true" />
                      <span className="truncate">
                        {supplier.address}, {supplier.city}
                      </span>
                    </span>
                  </div>
                  <ChevronRightIcon className="mt-1 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                </div>
                <SupplierTerms supplier={supplier} />
                <span className="mt-auto text-sm text-muted-foreground">
                  {supplier.productCount > 0 ? pluralize(supplier.productCount, 'product') : 'No products listed yet'}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}
