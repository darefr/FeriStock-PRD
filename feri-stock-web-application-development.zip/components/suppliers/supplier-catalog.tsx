'use client'

import { BoxesIcon, PackageSearchIcon, PlusIcon } from 'lucide-react'
import { useState } from 'react'
import { EmptyState } from '@/components/app/empty-state'
import { Money } from '@/components/app/money'
import { QtyStepper } from '@/components/app/qty-stepper'
import { SearchInput } from '@/components/app/search-input'
import { TrackProductDialog } from '@/components/inventory/add-item-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useCartQuantities } from '@/hooks/use-cart-qty'
import type { CatalogProductDto } from '@/lib/domain/catalog'
import { unitPriceForQty } from '@/lib/money'

export function SupplierCatalog({
  products,
  canOrder,
  canTrack,
}: {
  products: CatalogProductDto[]
  canOrder: boolean
  canTrack: boolean
}) {
  const [query, setQuery] = useState('')
  const [tracking, setTracking] = useState<CatalogProductDto | null>(null)
  const cart = useCartQuantities()

  if (products.length === 0) {
    return (
      <EmptyState
        icon={PackageSearchIcon}
        title="No products listed yet"
        description="This supplier has not published a catalog. You can still send them a quote request for what you need."
      />
    )
  }

  const term = query.trim().toLowerCase()
  const visible = term
    ? products.filter((product) =>
        [product.name, product.sku, product.category ?? ''].some((value) => value.toLowerCase().includes(term)),
      )
    : products

  const groups = new Map<string, CatalogProductDto[]>()
  for (const product of visible) {
    const category = product.category ?? 'Other products'
    groups.set(category, [...(groups.get(category) ?? []), product])
  }

  return (
    <div className="flex flex-col gap-4">
      <SearchInput
        label="Search this catalog"
        placeholder="Search by product, SKU or category"
        value={query}
        onValueChange={setQuery}
        className="sm:max-w-sm"
      />

      {visible.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">No products match this search.</p>
      ) : (
        [...groups.entries()].map(([category, items]) => (
          <section key={category} className="flex flex-col gap-2" aria-label={category}>
            <h2 className="text-sm font-medium text-muted-foreground">{category}</h2>
            <ul className="flex flex-col gap-2">
              {items.map((product) => {
                const qty = cart.qtyOf(product.id, product.cartQty)
                const unitPrice = unitPriceForQty(product.pricePaisa, product.bulkTiers, Math.max(qty, 1))
                const belowMinimum = qty > 0 && qty < product.moq
                return (
                  <li
                    key={product.id}
                    className="flex flex-col gap-3 rounded-lg border bg-card p-3 sm:flex-row sm:items-center sm:gap-4"
                  >
                    <div className="flex min-w-0 flex-1 flex-col gap-1">
                      <span className="text-pretty text-sm font-medium">{product.name}</span>
                      <span className="text-xs text-muted-foreground">
                        <span className="figures">{product.sku}</span> · Minimum {product.moq} {product.unit}
                      </span>
                      {product.bulkTiers.length > 0 ? (
                        <ul className="flex flex-wrap gap-1.5" aria-label="Bulk rates">
                          {product.bulkTiers.map((tier) => (
                            <li key={tier.minQty}>
                              <Badge variant={qty >= tier.minQty ? 'success' : 'outline'}>
                                <span className="figures">{tier.minQty}+</span>
                                <Money paisa={tier.pricePaisa} />
                              </Badge>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                      {product.schemeNote ? (
                        <span className="text-xs leading-relaxed text-warning-foreground">{product.schemeNote}</span>
                      ) : null}
                      {belowMinimum ? (
                        <span className="text-xs text-destructive" role="status">
                          Minimum order is {product.moq} {product.unit}.
                        </span>
                      ) : null}
                    </div>

                    <div className="flex items-center justify-between gap-3 sm:justify-end">
                      <span className="text-sm">
                        <Money paisa={unitPrice} className="font-medium" />{' '}
                        <span className="text-muted-foreground">/ {product.unit}</span>
                      </span>
                      <div className="flex items-center gap-1">
                        {canTrack && product.inventoryId === null ? (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            aria-label={`Track ${product.name} in inventory`}
                            onClick={() => setTracking(product)}
                          >
                            <BoxesIcon />
                          </Button>
                        ) : null}
                        {canOrder ? (
                          qty > 0 ? (
                            <QtyStepper label={product.name} value={qty} onChange={(next) => cart.setQty(product.id, next)} />
                          ) : (
                            <Button type="button" variant="outline" onClick={() => cart.setQty(product.id, product.moq)}>
                              <PlusIcon data-icon="inline-start" />
                              Add
                            </Button>
                          )
                        ) : null}
                      </div>
                    </div>
                  </li>
                )
              })}
            </ul>
          </section>
        ))
      )}

      {tracking ? (
        <TrackProductDialog
          key={tracking.id}
          product={{
            id: tracking.id,
            name: tracking.name,
            unit: tracking.unit,
            moq: tracking.moq,
            supplierName: tracking.supplierName,
          }}
          onClose={() => setTracking(null)}
        />
      ) : null}
    </div>
  )
}
