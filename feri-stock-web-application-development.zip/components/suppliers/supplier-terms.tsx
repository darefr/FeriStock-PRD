import { Money } from '@/components/app/money'
import { Badge } from '@/components/ui/badge'
import { DELIVERY_MODE_LABEL } from '@/lib/constants'
import type { SupplierSummary } from '@/lib/domain/catalog'

/** How a supplier delivers, gets paid and extends credit, as a row of compact labels. */
export function SupplierTerms({ supplier }: { supplier: SupplierSummary }) {
  const payments = [
    supplier.payments.esewa ? 'eSewa' : null,
    supplier.payments.khalti ? 'Khalti' : null,
    supplier.payments.qrBank ? 'QR / Bank' : null,
  ].filter((method): method is string => method !== null)

  return (
    <ul className="flex flex-wrap gap-1.5" aria-label="Supplier terms">
      {supplier.deliveryModes.map((mode) => (
        <li key={mode}>
          <Badge variant="secondary">{DELIVERY_MODE_LABEL[mode]}</Badge>
        </li>
      ))}
      {payments.map((method) => (
        <li key={method}>
          <Badge variant="outline">{method}</Badge>
        </li>
      ))}
      {supplier.creditEnabled ? (
        <li>
          <Badge variant="warning">Udharo · {supplier.creditDays} days</Badge>
        </li>
      ) : null}
      {supplier.minOrderPaisa > 0 ? (
        <li>
          <Badge variant="outline">
            Min order <Money paisa={supplier.minOrderPaisa} />
          </Badge>
        </li>
      ) : null}
    </ul>
  )
}
