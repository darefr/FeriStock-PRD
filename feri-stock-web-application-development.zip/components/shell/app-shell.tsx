'use client'

import type { ReactNode } from 'react'
import { SWRConfig } from 'swr'
import { SidebarInset, SidebarProvider } from '@/components/ui/sidebar'
import { NAV_BADGES_KEY } from '@/hooks/use-nav-badges'
import type { NavBadges } from '@/lib/domain/dashboard'
import { AppHeader } from './app-header'
import { AppSidebar } from './app-sidebar'
import { MobileTabBar } from './mobile-tab-bar'

export type ShellProps = {
  orgName: string
  orgRoleLabel: string
  userName: string
  userEmail: string
  memberRoleLabel: string
  isRetailer: boolean
  isSupplier: boolean
  badges: NavBadges
}

export function AppShell({ children, badges, ...shell }: ShellProps & { children: ReactNode }) {
  return (
    <SWRConfig value={{ fallback: { [NAV_BADGES_KEY]: { badges } } }}>
      <SidebarProvider>
        <AppSidebar
          orgName={shell.orgName}
          orgRoleLabel={shell.orgRoleLabel}
          isRetailer={shell.isRetailer}
          isSupplier={shell.isSupplier}
        />
        <SidebarInset className="min-w-0">
          <AppHeader
            orgName={shell.orgName}
            orgRoleLabel={shell.orgRoleLabel}
            userName={shell.userName}
            userEmail={shell.userEmail}
            memberRoleLabel={shell.memberRoleLabel}
            showCart={shell.isRetailer}
          />
          <div className="flex flex-1 flex-col pb-tabbar md:pb-0 print:pb-0">{children}</div>
        </SidebarInset>
        <MobileTabBar isRetailer={shell.isRetailer} isSupplier={shell.isSupplier} />
      </SidebarProvider>
    </SWRConfig>
  )
}
