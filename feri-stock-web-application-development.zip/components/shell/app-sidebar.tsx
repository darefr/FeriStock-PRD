'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LogoMark } from '@/components/brand/logo'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  useSidebar,
} from '@/components/ui/sidebar'
import { useNavBadges } from '@/hooks/use-nav-badges'
import { isActivePath, navSections, settingsItem, type NavItem } from './nav-config'

export function AppSidebar({
  orgName,
  orgRoleLabel,
  isRetailer,
  isSupplier,
}: {
  orgName: string
  orgRoleLabel: string
  isRetailer: boolean
  isSupplier: boolean
}) {
  const pathname = usePathname()
  const badges = useNavBadges()
  const { setOpenMobile } = useSidebar()

  const renderItem = (item: NavItem) => {
    const count = item.badge ? badges[item.badge] : 0
    return (
      <SidebarMenuItem key={item.href}>
        <SidebarMenuButton
          render={<Link href={item.href} onClick={() => setOpenMobile(false)} />}
          isActive={isActivePath(pathname, item.href)}
          tooltip={item.label}
        >
          <item.icon />
          <span>{item.label}</span>
        </SidebarMenuButton>
        {count > 0 ? (
          <SidebarMenuBadge aria-label={`${count} waiting`}>{count > 99 ? '99+' : count}</SidebarMenuBadge>
        ) : null}
      </SidebarMenuItem>
    )
  }

  return (
    <Sidebar collapsible="icon" className="print:hidden">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              size="lg"
              render={<Link href="/app" onClick={() => setOpenMobile(false)} />}
              tooltip="FeriStock"
            >
              <LogoMark className="size-8" />
              <div className="grid flex-1 text-left leading-tight">
                <span className="truncate font-semibold">{orgName}</span>
                <span className="truncate text-xs text-muted-foreground">{orgRoleLabel}</span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent>
        {navSections(isRetailer, isSupplier).map((section) => (
          <SidebarGroup key={section.label ?? 'main'}>
            {section.label ? <SidebarGroupLabel>{section.label}</SidebarGroupLabel> : null}
            <SidebarGroupContent>
              <SidebarMenu>{section.items.map(renderItem)}</SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>{renderItem(settingsItem)}</SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
