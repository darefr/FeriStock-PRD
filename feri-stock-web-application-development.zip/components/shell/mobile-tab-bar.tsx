'use client'

import { MenuIcon } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useSidebar } from '@/components/ui/sidebar'
import { useNavBadges } from '@/hooks/use-nav-badges'
import { cn } from '@/lib/utils'
import { isActivePath, tabItems } from './nav-config'

const tabClass =
  'relative flex min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-lg py-1.5 text-[0.7rem] font-medium outline-none transition-colors focus-visible:ring-3 focus-visible:ring-ring/50'

/** Thumb-reach navigation for phones. Everything else lives behind "More", which opens the full menu. */
export function MobileTabBar({ isRetailer, isSupplier }: { isRetailer: boolean; isSupplier: boolean }) {
  const pathname = usePathname()
  const badges = useNavBadges()
  const { toggleSidebar, openMobile } = useSidebar()
  const items = tabItems(isRetailer, isSupplier)
  const onPrimaryTab = items.some((item) => isActivePath(pathname, item.href))

  return (
    <nav
      aria-label="Primary"
      className="fixed inset-x-0 bottom-0 z-30 border-t bg-card/95 px-2 pt-1.5 backdrop-blur pb-safe md:hidden print:hidden"
    >
      <ul className="mx-auto flex max-w-md items-stretch gap-1 pb-1.5">
        {items.map((item) => {
          const active = isActivePath(pathname, item.href)
          const count = item.badge ? badges[item.badge] : 0
          return (
            <li key={item.href} className="flex min-w-0 flex-1">
              <Link
                href={item.href}
                aria-current={active ? 'page' : undefined}
                className={cn(tabClass, active ? 'bg-accent text-primary' : 'text-muted-foreground')}
              >
                <span className="relative">
                  <item.icon className="size-5" aria-hidden="true" />
                  {count > 0 ? (
                    <span className="figures absolute -top-1.5 left-3 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[0.6rem] font-semibold leading-none text-primary-foreground">
                      {count > 9 ? '9+' : count}
                      <span className="sr-only"> waiting</span>
                    </span>
                  ) : null}
                </span>
                <span className="truncate">{item.shortLabel ?? item.label}</span>
              </Link>
            </li>
          )
        })}
        <li className="flex min-w-0 flex-1">
          <button
            type="button"
            onClick={toggleSidebar}
            aria-expanded={openMobile}
            className={cn(tabClass, !onPrimaryTab ? 'bg-accent text-primary' : 'text-muted-foreground')}
          >
            <MenuIcon className="size-5" aria-hidden="true" />
            <span>More</span>
          </button>
        </li>
      </ul>
    </nav>
  )
}
