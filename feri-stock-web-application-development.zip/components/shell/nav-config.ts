import {
  BoxesIcon,
  CalendarClockIcon,
  ClipboardListIcon,
  FileTextIcon,
  InboxIcon,
  LayoutDashboardIcon,
  NotebookTextIcon,
  SettingsIcon,
  ShoppingCartIcon,
  StoreIcon,
  TagsIcon,
  type LucideIcon,
} from 'lucide-react'
import type { NavBadges } from '@/lib/domain/dashboard'

export type NavItem = {
  href: string
  label: string
  /** Shorter label for the phone tab bar. */
  shortLabel?: string
  icon: LucideIcon
  badge?: keyof NavBadges
}

export type NavSection = { label: string | null; items: NavItem[] }

const overview: NavItem = { href: '/app', label: 'Overview', shortLabel: 'Home', icon: LayoutDashboardIcon }
const inventory: NavItem = { href: '/app/inventory', label: 'Inventory', shortLabel: 'Stock', icon: BoxesIcon, badge: 'stockAlerts' }
const suppliers: NavItem = { href: '/app/suppliers', label: 'Suppliers', icon: StoreIcon }
const cart: NavItem = { href: '/app/cart', label: 'Cart', icon: ShoppingCartIcon, badge: 'cart' }
const purchases: NavItem = { href: '/app/purchases', label: 'Purchases', shortLabel: 'Orders', icon: ClipboardListIcon, badge: 'purchases' }
const schedules: NavItem = { href: '/app/schedules', label: 'Schedules', icon: CalendarClockIcon }
const sales: NavItem = { href: '/app/sales', label: 'Sales orders', shortLabel: 'Sales', icon: InboxIcon, badge: 'sales' }
const catalog: NavItem = { href: '/app/catalog', label: 'Catalog', icon: TagsIcon }
const quotes: NavItem = { href: '/app/quotes', label: 'Quotes', icon: FileTextIcon, badge: 'quotes' }
const udharo: NavItem = { href: '/app/udharo', label: 'Udharo & dues', shortLabel: 'Udharo', icon: NotebookTextIcon }
export const settingsItem: NavItem = { href: '/app/settings', label: 'Settings', icon: SettingsIcon }

export function navSections(isRetailer: boolean, isSupplier: boolean): NavSection[] {
  const sections: NavSection[] = [{ label: null, items: [overview] }]
  if (isRetailer) sections.push({ label: 'Buying', items: [inventory, suppliers, cart, purchases, schedules] })
  if (isSupplier) sections.push({ label: 'Selling', items: [sales, catalog] })
  sections.push({ label: 'Deals & money', items: [quotes, udharo] })
  return sections
}

/** The four destinations a phone user reaches most, by the kind of business they run. */
export function tabItems(isRetailer: boolean, isSupplier: boolean): NavItem[] {
  if (isRetailer && isSupplier) return [overview, inventory, purchases, sales]
  if (isRetailer) return [overview, inventory, cart, purchases]
  return [overview, sales, catalog, udharo]
}

export function isActivePath(pathname: string, href: string): boolean {
  if (href === '/app') return pathname === '/app'
  return pathname === href || pathname.startsWith(`${href}/`)
}
