'use client'

import { LogOutIcon, SettingsIcon, ShoppingCartIcon } from 'lucide-react'
import Link from 'next/link'
import { useSignOut } from '@/components/auth/sign-out-button'
import { LogoMark } from '@/components/brand/logo'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { SidebarTrigger } from '@/components/ui/sidebar'
import { useNavBadges } from '@/hooks/use-nav-badges'
import { initials } from '@/lib/format'

export function AppHeader({
  orgName,
  orgRoleLabel,
  userName,
  userEmail,
  memberRoleLabel,
  showCart,
}: {
  orgName: string
  orgRoleLabel: string
  userName: string
  userEmail: string
  memberRoleLabel: string
  showCart: boolean
}) {
  const badges = useNavBadges()
  const { signOut, pending } = useSignOut()

  return (
    <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-2 border-b bg-background/95 px-3 backdrop-blur md:px-4 print:hidden">
      <SidebarTrigger className="hidden md:inline-flex" />
      <Link
        href="/app"
        aria-label="FeriStock overview"
        className="rounded-md outline-none focus-visible:ring-3 focus-visible:ring-ring/50 md:hidden"
      >
        <LogoMark className="size-8" />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col leading-tight md:hidden">
        <span className="truncate text-sm font-semibold">{orgName}</span>
        <span className="truncate text-xs text-muted-foreground">{orgRoleLabel}</span>
      </div>
      <div className="hidden flex-1 md:block" />

      {showCart ? (
        <Button
          variant="ghost"
          size="icon"
          nativeButton={false}
          render={<Link href="/app/cart" />}
          aria-label={badges.cart > 0 ? `Cart, ${badges.cart} items` : 'Cart'}
          className="relative"
        >
          <ShoppingCartIcon />
          {badges.cart > 0 ? (
            <span
              aria-hidden="true"
              className="figures absolute -top-0.5 -right-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[0.6rem] font-semibold leading-none text-primary-foreground"
            >
              {badges.cart > 9 ? '9+' : badges.cart}
            </span>
          ) : null}
        </Button>
      ) : null}

      <DropdownMenu>
        <DropdownMenuTrigger
          render={<Button variant="ghost" size="icon" className="rounded-full" aria-label="Account menu" />}
        >
          <Avatar size="sm">
            <AvatarFallback>{initials(userName)}</AvatarFallback>
          </Avatar>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuGroup>
            <DropdownMenuLabel className="flex flex-col gap-0.5">
              <span className="truncate text-sm font-medium text-foreground">{userName}</span>
              <span className="truncate text-xs font-normal text-muted-foreground">{userEmail}</span>
              <span className="truncate text-xs font-normal text-muted-foreground">
                {memberRoleLabel} · {orgName}
              </span>
            </DropdownMenuLabel>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem render={<Link href="/app/settings" />}>
              <SettingsIcon />
              Settings
            </DropdownMenuItem>
            <DropdownMenuItem disabled={pending} onClick={signOut}>
              <LogOutIcon />
              Log out
            </DropdownMenuItem>
          </DropdownMenuGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
