'use client'

import { PlusIcon, SendIcon, Trash2Icon } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useRef, useState, type FormEvent } from 'react'
import useSWR from 'swr'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormField } from '@/components/app/form-field'
import { RupeeInput } from '@/components/app/rupee-input'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Field, FieldError, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select'
import { Spinner } from '@/components/ui/spinner'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { createQuoteRequestAction } from '@/lib/actions/planning'
import { COMMON_UNITS } from '@/lib/constants'
import type { CatalogProductDto } from '@/lib/domain/catalog'
import { fetcher } from '@/lib/fetcher'
import { parseRupees } from '@/lib/money'
import { fieldErrors, quoteRequestSchema } from '@/lib/validation'

type Row = { key: number; productId: string | null; name: string; unit: string; qty: string; targetPrice: string }

export function QuoteRequestForm({
  suppliers,
  initialSupplierId,
  initialItem,
}: {
  suppliers: Array<{ id: string; name: string; city: string }>
  initialSupplierId: string | null
  initialItem: { name: string; unit: string } | null
}) {
  const router = useRouter()
  const [supplierId, setSupplierId] = useState(initialSupplierId ?? suppliers[0]?.id ?? '')
  const [rows, setRows] = useState<Row[]>(() => [
    { key: 0, productId: null, name: initialItem?.name ?? '', unit: initialItem?.unit ?? '', qty: '', targetPrice: '' },
  ])
  const nextKey = useRef(1)
  const [note, setNote] = useState('')
  const [localErrors, setLocalErrors] = useState<Record<string, string>>({})

  const { data } = useSWR<{ products: CatalogProductDto[] }>(
    supplierId ? `/api/catalog/search?supplierId=${supplierId}` : null,
    fetcher,
  )
  const catalog = (data?.products ?? []).filter((product) => !rows.some((row) => row.productId === product.id))

  const create = useAction(createQuoteRequestAction, {
    success: 'Quote request sent.',
    onSuccess: ({ id }) => router.push(`/app/quotes/${id}`),
  })
  const errors = { ...create.fields, ...localErrors }
  const rowError = (index: number) => Object.entries(errors).find(([key]) => key.startsWith(`items.${index}.`))?.[1]

  const updateRow = (key: number, patch: Partial<Row>) =>
    setRows((current) => current.map((row) => (row.key === key ? { ...row, ...patch } : row)))

  function addRow(product: CatalogProductDto | null) {
    nextKey.current += 1
    const row: Row = {
      key: nextKey.current,
      productId: product?.id ?? null,
      name: product?.name ?? '',
      unit: product?.unit ?? '',
      qty: '',
      targetPrice: '',
    }
    // A blank first row is replaced rather than left behind.
    setRows((current) => (product && current.length === 1 && !current[0].name && !current[0].qty ? [row] : [...current, row]))
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const badPrice = rows.findIndex((row) => row.targetPrice.trim() !== '' && parseRupees(row.targetPrice) === null)
    if (badPrice >= 0) {
      setLocalErrors({ [`items.${badPrice}.targetPricePaisa`]: 'Enter the target price in rupees, for example 92.50.' })
      return
    }
    const parsed = quoteRequestSchema.safeParse({
      supplierOrgId: supplierId,
      note,
      items: rows.map((row) => ({
        productId: row.productId,
        name: row.name,
        unit: row.unit,
        qty: toInt(row.qty),
        targetPricePaisa: row.targetPrice.trim() === '' ? null : parseRupees(row.targetPrice),
      })),
    })
    if (!parsed.success) {
      setLocalErrors(fieldErrors(parsed.error))
      return
    }
    setLocalErrors({})
    void create.run(parsed.data)
  }

  if (suppliers.length === 0) {
    return (
      <Alert>
        <AlertDescription>
          There are no suppliers on FeriStock to ask yet. Invite your wholesaler to register as a supplier.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <Card>
        <CardHeader>
          <CardTitle>What do you need?</CardTitle>
          <CardDescription>
            The supplier answers with the quantity and price they can offer. Accepting their quote turns it into an order.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <FormField label="Supplier" htmlFor="quote-supplier" error={errors.supplierOrgId} className="max-w-md">
              <NativeSelect
                id="quote-supplier"
                className="w-full"
                value={supplierId}
                onChange={(event) => {
                  setSupplierId(event.target.value)
                  // Catalog items belong to one supplier; own-word items carry over.
                  setRows((current) => {
                    const kept = current.filter((row) => row.productId === null)
                    return kept.length > 0 ? kept : [{ key: 0, productId: null, name: '', unit: '', qty: '', targetPrice: '' }]
                  })
                }}
              >
                {suppliers.map((supplier) => (
                  <NativeSelectOption key={supplier.id} value={supplier.id}>
                    {supplier.name} ({supplier.city})
                  </NativeSelectOption>
                ))}
              </NativeSelect>
            </FormField>

            <ul className="flex flex-col gap-3">
              {rows.map((row, index) => {
                const error = rowError(index)
                return (
                  <li key={row.key} className="flex flex-col gap-3 rounded-lg border bg-background p-3">
                    <div className="grid gap-3 sm:grid-cols-[1fr_8rem]">
                      <Field>
                        <FieldLabel htmlFor={`quote-name-${row.key}`}>Item</FieldLabel>
                        <Input
                          id={`quote-name-${row.key}`}
                          autoComplete="off"
                          placeholder="e.g. Basmati rice 25kg sack"
                          readOnly={row.productId !== null}
                          value={row.name}
                          onChange={(event) => updateRow(row.key, { name: event.target.value })}
                        />
                      </Field>
                      <Field>
                        <FieldLabel htmlFor={`quote-unit-${row.key}`}>Unit</FieldLabel>
                        <Input
                          id={`quote-unit-${row.key}`}
                          list="quote-units"
                          autoComplete="off"
                          placeholder="sack"
                          readOnly={row.productId !== null}
                          value={row.unit}
                          onChange={(event) => updateRow(row.key, { unit: event.target.value.slice(0, 20) })}
                        />
                      </Field>
                    </div>
                    <div className="grid grid-cols-[1fr_1fr_auto] items-end gap-3">
                      <Field>
                        <FieldLabel htmlFor={`quote-qty-${row.key}`}>Quantity</FieldLabel>
                        <DigitsInput
                          id={`quote-qty-${row.key}`}
                          value={row.qty}
                          onValueChange={(qty) => updateRow(row.key, { qty })}
                        />
                      </Field>
                      <Field>
                        <FieldLabel htmlFor={`quote-price-${row.key}`}>
                          Target price <span className="font-normal text-muted-foreground">(optional)</span>
                        </FieldLabel>
                        <RupeeInput
                          id={`quote-price-${row.key}`}
                          value={row.targetPrice}
                          onValueChange={(targetPrice) => updateRow(row.key, { targetPrice })}
                        />
                      </Field>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        disabled={rows.length === 1}
                        aria-label={`Remove item ${index + 1}`}
                        onClick={() => setRows((current) => current.filter((candidate) => candidate.key !== row.key))}
                      >
                        <Trash2Icon />
                      </Button>
                    </div>
                    {error ? <FieldError>{error}</FieldError> : null}
                  </li>
                )
              })}
            </ul>
            <datalist id="quote-units">
              {COMMON_UNITS.map((unit) => (
                <option key={unit} value={unit} />
              ))}
            </datalist>
            {errors.items ? <FieldError>{errors.items}</FieldError> : null}

            <div className="flex flex-wrap items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => addRow(null)}>
                <PlusIcon data-icon="inline-start" />
                Add an item
              </Button>
              {catalog.length > 0 ? (
                <NativeSelect
                  size="sm"
                  aria-label="Add an item from this supplier's catalog"
                  value=""
                  onChange={(event) => addRow(catalog.find((product) => product.id === event.target.value) ?? null)}
                >
                  <NativeSelectOption value="" disabled>
                    Add from their catalog…
                  </NativeSelectOption>
                  {catalog.map((product) => (
                    <NativeSelectOption key={product.id} value={product.id}>
                      {product.name} ({product.unit})
                    </NativeSelectOption>
                  ))}
                </NativeSelect>
              ) : null}
            </div>

            <FormField label="Note to supplier" htmlFor="quote-note" optional error={errors.note}>
              <Textarea
                id="quote-note"
                rows={3}
                maxLength={600}
                placeholder="e.g. Needed before Tihar. Can you deliver to Bhaktapur?"
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </FormField>
          </FieldGroup>
        </CardContent>
        <CardFooter className="justify-end">
          <Button type="submit" size="lg" disabled={create.pending}>
            {create.pending ? <Spinner data-icon="inline-start" /> : <SendIcon data-icon="inline-start" />}
            Send quote request
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}
