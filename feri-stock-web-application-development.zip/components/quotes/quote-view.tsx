'use client'

import { ArrowRightIcon } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ConfirmDialog } from '@/components/app/confirm-dialog'
import { DigitsInput, toInt } from '@/components/app/digits-input'
import { FormField } from '@/components/app/form-field'
import { Money } from '@/components/app/money'
import { RupeeInput } from '@/components/app/rupee-input'
import { QuoteStatusBadge } from '@/components/app/status-badges'
import { ReasonDialog } from '@/components/orders/reason-dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Input } from '@/components/ui/input'
import { Spinner } from '@/components/ui/spinner'
import { Textarea } from '@/components/ui/textarea'
import { useAction } from '@/hooks/use-action'
import { refreshNavBadges } from '@/hooks/use-nav-badges'
import { acceptQuoteAction, declineQuoteAction, respondToQuoteAction } from '@/lib/actions/planning'
import { addDays, formatDateString, formatDateTime, todayNpt } from '@/lib/dates'
import type { QuoteDetail } from '@/lib/domain/quotes'
import { paisaToRupeeString, parseRupees } from '@/lib/money'

function statusLine(quote: QuoteDetail): string {
  const isRetailer = quote.viewerSide === 'retailer'
  switch (quote.status) {
    case 'requested':
      return isRetailer
        ? `Waiting for ${quote.supplier.name} to send their quote.`
        : 'Answer with the quantities and prices you can offer.'
    case 'quoted':
      if (quote.expired) {
        return isRetailer
          ? 'This quote has expired. Ask the supplier for an updated one.'
          : 'This quote has expired. Send a revised quote to renew it.'
      }
      return isRetailer
        ? 'Accept it to place an order the supplier has already agreed to.'
        : 'Quote sent. You can revise it until the buyer decides.'
    case 'accepted':
      return 'Accepted. It is now an order.'
    case 'declined':
      return 'Closed without an order.'
    default:
      return 'Withdrawn by the buyer before it was answered.'
  }
}

export function QuoteView({
  quote,
  canOrder,
  canManage,
}: {
  quote: QuoteDetail
  /** The viewer's role may place orders (buyer side). */
  canOrder: boolean
  /** The viewer's role may answer quote requests (supplier side). */
  canManage: boolean
}) {
  const router = useRouter()
  const isRetailer = quote.viewerSide === 'retailer'
  const open = quote.status === 'requested' || quote.status === 'quoted'
  const today = todayNpt()

  const [offers, setOffers] = useState(() =>
    quote.items.map((item) => {
      const price = item.quotedPricePaisa ?? item.targetPricePaisa ?? item.listPricePaisa
      return { qty: String(item.quotedQty ?? item.qty), price: price ? paisaToRupeeString(price) : '' }
    }),
  )
  const [validUntil, setValidUntil] = useState(
    quote.validUntil && quote.validUntil >= today ? quote.validUntil : addDays(today, 7),
  )
  const [supplierNote, setSupplierNote] = useState(quote.supplierNote ?? '')
  const [requestCredit, setRequestCredit] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [closing, setClosing] = useState(false)

  const respond = useAction(respondToQuoteAction, {
    success: 'Quote sent to the buyer.',
    onSuccess: () => void refreshNavBadges(),
  })
  const decline = useAction(declineQuoteAction, {
    success: isRetailer && quote.status === 'requested' ? 'Request withdrawn.' : 'Quote declined.',
    onSuccess: () => {
      setClosing(false)
      void refreshNavBadges()
    },
  })
  const accept = useAction(acceptQuoteAction, {
    success: ({ orderNo }) => `Order ${orderNo} placed.`,
    onSuccess: ({ orderId }) => {
      void refreshNavBadges()
      router.push(`/app/orders/${orderId}`)
    },
  })

  const canRespond = !isRetailer && open && canManage
  const canDecide = isRetailer && quote.status === 'quoted' && !quote.expired && canOrder
  const canClose = open && (isRetailer ? canOrder : canManage)
  const offerTotal = quote.items.reduce(
    (sum, _item, index) => sum + toInt(offers[index].qty) * (parseRupees(offers[index].price) ?? 0),
    0,
  )

  function handleRespond() {
    const items = quote.items.map((item, index) => ({
      item,
      quotedQty: toInt(offers[index].qty),
      quotedPricePaisa: offers[index].price.trim() === '' ? 0 : parseRupees(offers[index].price),
    }))
    for (const { item, quotedQty, quotedPricePaisa } of items) {
      if (quotedPricePaisa === null) return setError(`Enter a valid price for ${item.name}.`)
      if (quotedQty > 0 && quotedPricePaisa <= 0) return setError(`Enter a price for ${item.name}.`)
    }
    if (items.every((offer) => offer.quotedQty === 0)) {
      return setError('Offer at least one item, or decline the request instead.')
    }
    if (validUntil && validUntil < today) return setError('Choose a validity date from today onwards.')
    setError(null)
    void respond.run({
      quoteId: quote.id,
      supplierNote,
      validUntil: validUntil || null,
      items: items.map((offer) => ({
        itemId: offer.item.id,
        quotedQty: offer.quotedQty,
        quotedPricePaisa: offer.quotedPricePaisa as number,
      })),
    })
  }

  const updateOffer = (index: number, patch: Partial<{ qty: string; price: string }>) =>
    setOffers((current) => current.map((offer, position) => (position === index ? { ...offer, ...patch } : offer)))

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-wrap items-center gap-2">
            <span className="figures">{quote.quoteNo}</span>
            <QuoteStatusBadge status={quote.status} expired={quote.expired} />
          </CardTitle>
          <CardDescription>
            {isRetailer ? `To ${quote.supplier.name}` : `From ${quote.retailer.name}, ${quote.retailer.city}`} · requested{' '}
            {formatDateTime(quote.createdAt)}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <p className="text-pretty text-sm leading-relaxed">{statusLine(quote)}</p>
          {quote.status === 'quoted' && quote.validUntil ? (
            <p className="text-sm text-muted-foreground">
              Valid until <span className="font-medium text-foreground">{formatDateString(quote.validUntil)}</span>
            </p>
          ) : null}
          {quote.retailerNote ? (
            <div className="flex flex-col gap-0.5 text-sm">
              <span className="text-xs text-muted-foreground">Note from the buyer</span>
              <p className="leading-relaxed">{quote.retailerNote}</p>
            </div>
          ) : null}
          {quote.supplierNote && !canRespond ? (
            <div className="flex flex-col gap-0.5 text-sm">
              <span className="text-xs text-muted-foreground">Note from the supplier</span>
              <p className="leading-relaxed">{quote.supplierNote}</p>
            </div>
          ) : null}
          {quote.order ? (
            <Button variant="outline" className="w-fit" nativeButton={false} render={<Link href={`/app/orders/${quote.order.id}`} />}>
              Open order <span className="figures">{quote.order.orderNo}</span>
              <ArrowRightIcon data-icon="inline-end" />
            </Button>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{canRespond ? 'Your offer' : 'Items'}</CardTitle>
          {canRespond ? (
            <CardDescription>Set a quantity to 0 for anything you cannot supply.</CardDescription>
          ) : null}
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <ul className="flex flex-col divide-y">
              {quote.items.map((item, index) => {
                const answered = item.quotedQty !== null && quote.status !== 'requested'
                return (
                  <li key={item.id} className="flex flex-col gap-3 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-end sm:gap-4">
                    <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <span className="text-pretty text-sm font-medium">
                        {item.name}{' '}
                        {item.productId === null ? <Badge variant="outline">Not in catalog</Badge> : null}
                      </span>
                      <span className="text-xs leading-relaxed text-muted-foreground">
                        Asked for <span className="figures">{item.qty}</span> {item.unit}
                        {item.targetPricePaisa !== null ? (
                          <>
                            {' at '}
                            <Money paisa={item.targetPricePaisa} /> each
                          </>
                        ) : null}
                        {!isRetailer && item.listPricePaisa !== null ? (
                          <>
                            {' · your list price '}
                            <Money paisa={item.listPricePaisa} />
                          </>
                        ) : null}
                      </span>
                    </div>

                    {canRespond ? (
                      <div className="grid grid-cols-[6rem_1fr] gap-3 sm:w-64">
                        <Field>
                          <FieldLabel htmlFor={`offer-qty-${item.id}`}>Offer</FieldLabel>
                          <DigitsInput
                            id={`offer-qty-${item.id}`}
                            value={offers[index].qty}
                            onValueChange={(qty) => updateOffer(index, { qty })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel htmlFor={`offer-price-${item.id}`}>Price each</FieldLabel>
                          <RupeeInput
                            id={`offer-price-${item.id}`}
                            value={offers[index].price}
                            onValueChange={(price) => updateOffer(index, { price })}
                          />
                        </Field>
                      </div>
                    ) : answered ? (
                      item.quotedQty === 0 ? (
                        <Badge variant="outline">Not offered</Badge>
                      ) : (
                        <div className="flex flex-col sm:items-end">
                          <Money paisa={(item.quotedQty ?? 0) * (item.quotedPricePaisa ?? 0)} className="text-sm font-medium" />
                          <span className="text-xs text-muted-foreground">
                            <span className="figures">{item.quotedQty}</span> {item.unit} ×{' '}
                            <Money paisa={item.quotedPricePaisa ?? 0} />
                          </span>
                        </div>
                      )
                    ) : null}
                  </li>
                )
              })}
            </ul>

            {canRespond ? (
              <>
                <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                  <span className="text-sm text-muted-foreground">Quote total</span>
                  <Money paisa={offerTotal} className="text-base font-semibold" />
                </div>
                <FormField label="Valid until" htmlFor="quote-valid" className="max-w-56" hint="The buyer cannot accept after this date.">
                  <Input
                    id="quote-valid"
                    type="date"
                    min={today}
                    value={validUntil}
                    onChange={(event) => setValidUntil(event.target.value)}
                  />
                </FormField>
                <Field>
                  <FieldLabel htmlFor="quote-reply">
                    Note to buyer <span className="font-normal text-muted-foreground">(optional)</span>
                  </FieldLabel>
                  <Textarea
                    id="quote-reply"
                    rows={2}
                    maxLength={600}
                    placeholder="e.g. Price holds for full cartons. Delivery in three days."
                    value={supplierNote}
                    onChange={(event) => setSupplierNote(event.target.value)}
                  />
                </Field>
                {error ? (
                  <Alert variant="destructive" role="alert">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                ) : null}
              </>
            ) : null}

            {canDecide && quote.supplier.creditEnabled ? (
              <Field orientation="horizontal">
                <Checkbox
                  id="quote-credit"
                  checked={requestCredit}
                  onCheckedChange={(checked) => setRequestCredit(checked === true)}
                />
                <FieldContent>
                  <FieldLabel htmlFor="quote-credit">Ask to buy on udharo</FieldLabel>
                  <FieldDescription>
                    {quote.supplier.name} usually gives {quote.supplier.creditDays} days and decides on each request.
                  </FieldDescription>
                </FieldContent>
              </Field>
            ) : null}
          </FieldGroup>
        </CardContent>

        {!canRespond && quote.quotedTotalPaisa !== null ? (
          <CardFooter className="justify-between">
            <span className="text-sm font-medium">Quote total</span>
            <Money paisa={quote.quotedTotalPaisa} className="text-base font-semibold" />
          </CardFooter>
        ) : null}
      </Card>

      {canRespond || canDecide || canClose ? (
        <div className="flex flex-wrap justify-end gap-2">
          {canClose ? (
            <Button type="button" variant="ghost" onClick={() => setClosing(true)}>
              {isRetailer ? (quote.status === 'requested' ? 'Withdraw request' : 'Decline quote') : 'Decline request'}
            </Button>
          ) : null}
          {canRespond ? (
            <Button type="button" size="lg" disabled={respond.pending} onClick={handleRespond}>
              {respond.pending ? <Spinner data-icon="inline-start" /> : null}
              {quote.status === 'quoted' ? 'Send revised quote' : 'Send quote'}
            </Button>
          ) : null}
          {canDecide ? (
            <Button
              type="button"
              size="lg"
              disabled={accept.pending}
              onClick={() => void accept.run({ quoteId: quote.id, requestCredit })}
            >
              {accept.pending ? <Spinner data-icon="inline-start" /> : null}
              Accept and place order
            </Button>
          ) : null}
        </div>
      ) : null}

      {closing && !isRetailer ? (
        <ReasonDialog
          title="Decline this request?"
          description={`${quote.retailer.name} is told you cannot supply this.`}
          label="Reason for the buyer"
          hint="For example: we do not stock this, or not in this quantity."
          submitLabel="Decline request"
          pending={decline.pending}
          onSubmit={(reason) => void decline.run({ quoteId: quote.id, note: reason })}
          onClose={() => setClosing(false)}
        />
      ) : null}
      <ConfirmDialog
        open={closing && isRetailer}
        onOpenChange={setClosing}
        title={quote.status === 'requested' ? 'Withdraw this request?' : 'Decline this quote?'}
        description={
          quote.status === 'requested'
            ? 'The supplier no longer needs to answer it. You can send a new request any time.'
            : 'The quote is closed without an order. You can send a new request any time.'
        }
        confirmLabel={quote.status === 'requested' ? 'Withdraw request' : 'Decline quote'}
        variant="destructive"
        pending={decline.pending}
        onConfirm={() => void decline.run({ quoteId: quote.id, note: '' })}
      />
    </>
  )
}
