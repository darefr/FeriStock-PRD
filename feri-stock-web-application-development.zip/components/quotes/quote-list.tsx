import { ChevronRightIcon } from 'lucide-react'
import Link from 'next/link'
import { Money } from '@/components/app/money'
import { QuoteStatusBadge } from '@/components/app/status-badges'
import { Item, ItemActions, ItemContent, ItemDescription, ItemGroup, ItemTitle } from '@/components/ui/item'
import { formatDateString, formatShortDateTime } from '@/lib/dates'
import type { QuoteListItem } from '@/lib/domain/quotes'
import { pluralize } from '@/lib/format'

export function QuoteList({ quotes }: { quotes: QuoteListItem[] }) {
  return (
    <ItemGroup className="gap-2">
      {quotes.map((quote) => (
        <Item
          key={quote.id}
          variant="outline"
          className="bg-card"
          render={<Link href={`/app/quotes/${quote.id}`} aria-label={`Quote ${quote.quoteNo}, ${quote.counterparty.name}`} />}
        >
          <ItemContent>
            <ItemTitle className="flex-wrap">
              <span className="figures">{quote.quoteNo}</span>
              <QuoteStatusBadge status={quote.status} expired={quote.expired} />
            </ItemTitle>
            <ItemDescription>
              {quote.counterparty.name} · {pluralize(quote.itemCount, 'item')} · {formatShortDateTime(quote.createdAt)}
              {quote.status === 'quoted' && quote.validUntil ? ` · valid until ${formatDateString(quote.validUntil)}` : ''}
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            {quote.quotedTotalPaisa !== null ? (
              <Money paisa={quote.quotedTotalPaisa} className="text-sm font-medium" />
            ) : null}
            <ChevronRightIcon className="size-4 text-muted-foreground" aria-hidden="true" />
          </ItemActions>
        </Item>
      ))}
    </ItemGroup>
  )
}
