CREATE TYPE "public"."credit_state" AS ENUM('none', 'requested', 'approved', 'declined');--> statement-breakpoint
CREATE TYPE "public"."delivery_mode" AS ENUM('own_van', 'bilti', 'pickup');--> statement-breakpoint
CREATE TYPE "public"."file_kind" AS ENUM('bilti_photo', 'payment_proof', 'qr_image');--> statement-breakpoint
CREATE TYPE "public"."gateway_env" AS ENUM('test', 'live');--> statement-breakpoint
CREATE TYPE "public"."member_role" AS ENUM('owner', 'manager', 'staff');--> statement-breakpoint
CREATE TYPE "public"."order_status" AS ENUM('draft', 'pending', 'accepted', 'packed', 'dispatched', 'delivered', 'cancelled', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."order_type" AS ENUM('reorder', 'scheduled', 'custom');--> statement-breakpoint
CREATE TYPE "public"."org_role" AS ENUM('retailer', 'supplier', 'both');--> statement-breakpoint
CREATE TYPE "public"."payment_method" AS ENUM('esewa', 'khalti', 'qr_bank', 'cash');--> statement-breakpoint
CREATE TYPE "public"."payment_record_status" AS ENUM('initiated', 'pending_verification', 'verified', 'failed', 'rejected');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('unpaid', 'pending', 'credit', 'partial', 'paid');--> statement-breakpoint
CREATE TYPE "public"."quote_status" AS ENUM('requested', 'quoted', 'accepted', 'declined', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."receipt_kind" AS ENUM('order', 'payment');--> statement-breakpoint
CREATE TYPE "public"."schedule_frequency" AS ENUM('weekly', 'monthly');--> statement-breakpoint
CREATE TYPE "public"."schedule_mode" AS ENUM('draft', 'auto');--> statement-breakpoint
CREATE TYPE "public"."stock_reason" AS ENUM('initial', 'manual', 'correction', 'delivery');--> statement-breakpoint
CREATE SEQUENCE "public"."order_no_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START WITH 1001 CACHE 1;--> statement-breakpoint
CREATE SEQUENCE "public"."quote_no_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START WITH 1001 CACHE 1;--> statement-breakpoint
CREATE SEQUENCE "public"."receipt_no_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START WITH 1001 CACHE 1;--> statement-breakpoint
CREATE TABLE "account" (
	"id" text PRIMARY KEY NOT NULL,
	"account_id" text NOT NULL,
	"provider_id" text NOT NULL,
	"user_id" text NOT NULL,
	"access_token" text,
	"refresh_token" text,
	"id_token" text,
	"access_token_expires_at" timestamp with time zone,
	"refresh_token_expires_at" timestamp with time zone,
	"scope" text,
	"password" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rate_limit" (
	"id" text PRIMARY KEY NOT NULL,
	"key" text NOT NULL,
	"count" integer NOT NULL,
	"last_request" bigint NOT NULL,
	CONSTRAINT "rate_limit_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "session" (
	"id" text PRIMARY KEY NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"token" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"ip_address" text,
	"user_agent" text,
	"user_id" text NOT NULL,
	CONSTRAINT "session_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "user" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"email_verified" boolean DEFAULT false NOT NULL,
	"image" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "user_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "verification" (
	"id" text PRIMARY KEY NOT NULL,
	"identifier" text NOT NULL,
	"value" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "cart_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"product_id" uuid NOT NULL,
	"qty" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "cart_items_qty_positive" CHECK ("cart_items"."qty" >= 1)
);
--> statement-breakpoint
CREATE TABLE "files" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"kind" "file_kind" NOT NULL,
	"order_id" uuid,
	"content_type" text NOT NULL,
	"size_bytes" integer NOT NULL,
	"data" "bytea" NOT NULL,
	"created_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "invites" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"code" text NOT NULL,
	"role" "member_role" NOT NULL,
	"created_by" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"used_by" text,
	"used_at" timestamp with time zone,
	"revoked_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "memberships" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" uuid NOT NULL,
	"user_id" text NOT NULL,
	"role" "member_role" NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"order_id" uuid NOT NULL,
	"type" text NOT NULL,
	"message" text NOT NULL,
	"meta" jsonb,
	"actor_user_id" text,
	"actor_org_id" uuid,
	"actor_name" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"order_id" uuid NOT NULL,
	"product_id" uuid,
	"sku" text,
	"name" text NOT NULL,
	"unit" text NOT NULL,
	"requested_qty" integer NOT NULL,
	"qty" integer NOT NULL,
	"unit_price_paisa" bigint NOT NULL,
	"line_total_paisa" bigint NOT NULL,
	"received_qty" integer,
	"position" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "order_items_qty_nonneg" CHECK ("order_items"."qty" >= 0),
	CONSTRAINT "order_items_price_nonneg" CHECK ("order_items"."unit_price_paisa" >= 0)
);
--> statement-breakpoint
CREATE TABLE "orders" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"order_no" text DEFAULT 'PO-' || lpad(nextval('order_no_seq')::text, 6, '0') NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"supplier_org_id" uuid NOT NULL,
	"order_type" "order_type" NOT NULL,
	"status" "order_status" NOT NULL,
	"total_paisa" bigint NOT NULL,
	"paid_paisa" bigint DEFAULT 0 NOT NULL,
	"payment_status" "payment_status" DEFAULT 'unpaid' NOT NULL,
	"credit_state" "credit_state" DEFAULT 'none' NOT NULL,
	"due_date" date,
	"retailer_note" text,
	"supplier_note" text,
	"cancel_reason" text,
	"schedule_id" uuid,
	"quote_id" uuid,
	"placed_by" text,
	"placed_at" timestamp with time zone,
	"accepted_at" timestamp with time zone,
	"packed_at" timestamp with time zone,
	"dispatched_at" timestamp with time zone,
	"delivered_at" timestamp with time zone,
	"stock_synced_at" timestamp with time zone,
	"closed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "orders_total_nonneg" CHECK ("orders"."total_paisa" >= 0),
	CONSTRAINT "orders_paid_nonneg" CHECK ("orders"."paid_paisa" >= 0),
	CONSTRAINT "orders_distinct_parties" CHECK ("orders"."retailer_org_id" <> "orders"."supplier_org_id")
);
--> statement-breakpoint
CREATE TABLE "organizations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"role" "org_role" NOT NULL,
	"pan_vat_no" text NOT NULL,
	"city" text NOT NULL,
	"address" text NOT NULL,
	"phone" text NOT NULL,
	"email" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payment_records" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"order_id" uuid NOT NULL,
	"method" "payment_method" NOT NULL,
	"gateway_txn_id" text,
	"gateway_env" "gateway_env",
	"transaction_ref" text,
	"amount_paisa" bigint NOT NULL,
	"status" "payment_record_status" NOT NULL,
	"proof_file_id" uuid,
	"note" text,
	"reject_reason" text,
	"raw_response" jsonb,
	"receipt_url" text,
	"created_by" text,
	"verified_by" text,
	"paid_at" timestamp with time zone,
	"verified_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payment_records_amount_positive" CHECK ("payment_records"."amount_paisa" > 0)
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"supplier_org_id" uuid NOT NULL,
	"sku" text NOT NULL,
	"name" text NOT NULL,
	"unit" text NOT NULL,
	"category" text,
	"price_paisa" bigint NOT NULL,
	"bulk_tiers_json" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"scheme_note" text,
	"moq" integer DEFAULT 1 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "products_price_nonneg" CHECK ("products"."price_paisa" >= 0),
	CONSTRAINT "products_moq_positive" CHECK ("products"."moq" >= 1)
);
--> statement-breakpoint
CREATE TABLE "quote_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"quote_id" uuid NOT NULL,
	"product_id" uuid,
	"name" text NOT NULL,
	"unit" text NOT NULL,
	"qty" integer NOT NULL,
	"target_price_paisa" bigint,
	"quoted_qty" integer,
	"quoted_price_paisa" bigint,
	"position" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "quote_items_qty_positive" CHECK ("quote_items"."qty" >= 1)
);
--> statement-breakpoint
CREATE TABLE "quote_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"quote_no" text DEFAULT 'QT-' || lpad(nextval('quote_no_seq')::text, 6, '0') NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"supplier_org_id" uuid NOT NULL,
	"status" "quote_status" DEFAULT 'requested' NOT NULL,
	"retailer_note" text,
	"supplier_note" text,
	"valid_until" date,
	"order_id" uuid,
	"requested_by" text,
	"responded_at" timestamp with time zone,
	"decided_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "quote_requests_distinct_parties" CHECK ("quote_requests"."retailer_org_id" <> "quote_requests"."supplier_org_id")
);
--> statement-breakpoint
CREATE TABLE "receipts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"receipt_no" text DEFAULT 'RC-' || lpad(nextval('receipt_no_seq')::text, 6, '0') NOT NULL,
	"order_id" uuid NOT NULL,
	"payment_record_id" uuid,
	"kind" "receipt_kind" NOT NULL,
	"snapshot" jsonb NOT NULL,
	"issued_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "recurring_schedule_items" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"schedule_id" uuid NOT NULL,
	"product_id" uuid NOT NULL,
	"qty" integer NOT NULL,
	CONSTRAINT "recurring_schedule_items_qty_positive" CHECK ("recurring_schedule_items"."qty" >= 1)
);
--> statement-breakpoint
CREATE TABLE "recurring_schedules" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"supplier_org_id" uuid NOT NULL,
	"name" text NOT NULL,
	"frequency" "schedule_frequency" NOT NULL,
	"day_of_week" integer,
	"day_of_month" integer,
	"time_of_day" text NOT NULL,
	"mode" "schedule_mode" DEFAULT 'draft' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"next_run_at" timestamp with time zone NOT NULL,
	"last_run_at" timestamp with time zone,
	"last_order_id" uuid,
	"created_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "recurring_schedules_dow_range" CHECK ("recurring_schedules"."day_of_week" is null or "recurring_schedules"."day_of_week" between 0 and 6),
	CONSTRAINT "recurring_schedules_dom_range" CHECK ("recurring_schedules"."day_of_month" is null or "recurring_schedules"."day_of_month" between 1 and 28)
);
--> statement-breakpoint
CREATE TABLE "retailer_inventory" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"product_id" uuid,
	"custom_name" text,
	"custom_unit" text,
	"current_qty" integer DEFAULT 0 NOT NULL,
	"reorder_threshold" integer DEFAULT 0 NOT NULL,
	"reorder_qty" integer,
	"auto_reorder" boolean DEFAULT true NOT NULL,
	"alerts_enabled" boolean DEFAULT true NOT NULL,
	"preferred_supplier_id" uuid,
	"archived_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "retailer_inventory_qty_nonneg" CHECK ("retailer_inventory"."current_qty" >= 0),
	CONSTRAINT "retailer_inventory_threshold_nonneg" CHECK ("retailer_inventory"."reorder_threshold" >= 0),
	CONSTRAINT "retailer_inventory_identity" CHECK ("retailer_inventory"."product_id" is not null or "retailer_inventory"."custom_name" is not null)
);
--> statement-breakpoint
CREATE TABLE "shipments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"order_id" uuid NOT NULL,
	"delivery_mode" "delivery_mode" NOT NULL,
	"carrier_or_van" text,
	"driver_name" text,
	"driver_phone" text,
	"bilti_ref" text,
	"bilti_photo_file_id" uuid,
	"note" text,
	"dispatched_at" timestamp with time zone NOT NULL,
	"delivered_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stock_movements" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"inventory_id" uuid NOT NULL,
	"retailer_org_id" uuid NOT NULL,
	"delta" integer NOT NULL,
	"qty_after" integer NOT NULL,
	"reason" "stock_reason" NOT NULL,
	"order_id" uuid,
	"user_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "supplier_payment_configs" (
	"org_id" uuid PRIMARY KEY NOT NULL,
	"esewa_enabled" boolean DEFAULT false NOT NULL,
	"esewa_merchant_id" text,
	"esewa_secret_enc" text,
	"esewa_env" "gateway_env" DEFAULT 'test' NOT NULL,
	"khalti_enabled" boolean DEFAULT false NOT NULL,
	"khalti_secret_enc" text,
	"khalti_env" "gateway_env" DEFAULT 'test' NOT NULL,
	"qr_file_id" uuid,
	"bank_details_json" jsonb,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "supplier_settings" (
	"org_id" uuid PRIMARY KEY NOT NULL,
	"delivery_modes" jsonb DEFAULT '["own_van","bilti","pickup"]'::jsonb NOT NULL,
	"delivery_note" text DEFAULT '' NOT NULL,
	"credit_enabled" boolean DEFAULT false NOT NULL,
	"credit_days" integer DEFAULT 15 NOT NULL,
	"min_order_paisa" bigint DEFAULT 0 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "supplier_settings_credit_days_range" CHECK ("supplier_settings"."credit_days" between 1 and 180),
	CONSTRAINT "supplier_settings_min_order_nonneg" CHECK ("supplier_settings"."min_order_paisa" >= 0)
);
--> statement-breakpoint
ALTER TABLE "account" ADD CONSTRAINT "account_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "session" ADD CONSTRAINT "session_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "cart_items" ADD CONSTRAINT "cart_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "files" ADD CONSTRAINT "files_created_by_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invites" ADD CONSTRAINT "invites_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invites" ADD CONSTRAINT "invites_created_by_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invites" ADD CONSTRAINT "invites_used_by_user_id_fk" FOREIGN KEY ("used_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "memberships" ADD CONSTRAINT "memberships_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "memberships" ADD CONSTRAINT "memberships_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_events" ADD CONSTRAINT "order_events_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_events" ADD CONSTRAINT "order_events_actor_user_id_user_id_fk" FOREIGN KEY ("actor_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_events" ADD CONSTRAINT "order_events_actor_org_id_organizations_id_fk" FOREIGN KEY ("actor_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_items" ADD CONSTRAINT "order_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_supplier_org_id_organizations_id_fk" FOREIGN KEY ("supplier_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_placed_by_user_id_fk" FOREIGN KEY ("placed_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payment_records" ADD CONSTRAINT "payment_records_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payment_records" ADD CONSTRAINT "payment_records_created_by_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payment_records" ADD CONSTRAINT "payment_records_verified_by_user_id_fk" FOREIGN KEY ("verified_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "products" ADD CONSTRAINT "products_supplier_org_id_organizations_id_fk" FOREIGN KEY ("supplier_org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_quote_id_quote_requests_id_fk" FOREIGN KEY ("quote_id") REFERENCES "public"."quote_requests"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_items" ADD CONSTRAINT "quote_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_requests" ADD CONSTRAINT "quote_requests_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_requests" ADD CONSTRAINT "quote_requests_supplier_org_id_organizations_id_fk" FOREIGN KEY ("supplier_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "quote_requests" ADD CONSTRAINT "quote_requests_requested_by_user_id_fk" FOREIGN KEY ("requested_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipts" ADD CONSTRAINT "receipts_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipts" ADD CONSTRAINT "receipts_payment_record_id_payment_records_id_fk" FOREIGN KEY ("payment_record_id") REFERENCES "public"."payment_records"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recurring_schedule_items" ADD CONSTRAINT "recurring_schedule_items_schedule_id_recurring_schedules_id_fk" FOREIGN KEY ("schedule_id") REFERENCES "public"."recurring_schedules"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recurring_schedule_items" ADD CONSTRAINT "recurring_schedule_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recurring_schedules" ADD CONSTRAINT "recurring_schedules_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recurring_schedules" ADD CONSTRAINT "recurring_schedules_supplier_org_id_organizations_id_fk" FOREIGN KEY ("supplier_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "recurring_schedules" ADD CONSTRAINT "recurring_schedules_created_by_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "retailer_inventory" ADD CONSTRAINT "retailer_inventory_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "retailer_inventory" ADD CONSTRAINT "retailer_inventory_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "retailer_inventory" ADD CONSTRAINT "retailer_inventory_preferred_supplier_id_organizations_id_fk" FOREIGN KEY ("preferred_supplier_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shipments" ADD CONSTRAINT "shipments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_inventory_id_retailer_inventory_id_fk" FOREIGN KEY ("inventory_id") REFERENCES "public"."retailer_inventory"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_retailer_org_id_organizations_id_fk" FOREIGN KEY ("retailer_org_id") REFERENCES "public"."organizations"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "supplier_payment_configs" ADD CONSTRAINT "supplier_payment_configs_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "supplier_settings" ADD CONSTRAINT "supplier_settings_org_id_organizations_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "account_user_id_idx" ON "account" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "session_user_id_idx" ON "session" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "verification_identifier_idx" ON "verification" USING btree ("identifier");--> statement-breakpoint
CREATE UNIQUE INDEX "cart_items_org_product_key" ON "cart_items" USING btree ("retailer_org_id","product_id");--> statement-breakpoint
CREATE INDEX "files_org_idx" ON "files" USING btree ("org_id");--> statement-breakpoint
CREATE INDEX "files_order_idx" ON "files" USING btree ("order_id");--> statement-breakpoint
CREATE UNIQUE INDEX "invites_code_key" ON "invites" USING btree ("code");--> statement-breakpoint
CREATE INDEX "invites_org_id_idx" ON "invites" USING btree ("org_id");--> statement-breakpoint
CREATE UNIQUE INDEX "memberships_user_id_key" ON "memberships" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "memberships_org_id_idx" ON "memberships" USING btree ("org_id");--> statement-breakpoint
CREATE INDEX "order_events_order_idx" ON "order_events" USING btree ("order_id","created_at");--> statement-breakpoint
CREATE INDEX "order_items_order_idx" ON "order_items" USING btree ("order_id");--> statement-breakpoint
CREATE UNIQUE INDEX "orders_order_no_key" ON "orders" USING btree ("order_no");--> statement-breakpoint
CREATE INDEX "orders_retailer_idx" ON "orders" USING btree ("retailer_org_id","created_at");--> statement-breakpoint
CREATE INDEX "orders_supplier_idx" ON "orders" USING btree ("supplier_org_id","status");--> statement-breakpoint
CREATE INDEX "payment_records_order_idx" ON "payment_records" USING btree ("order_id");--> statement-breakpoint
CREATE UNIQUE INDEX "payment_records_gateway_txn_key" ON "payment_records" USING btree ("method","gateway_txn_id");--> statement-breakpoint
CREATE UNIQUE INDEX "products_supplier_sku_key" ON "products" USING btree ("supplier_org_id","sku");--> statement-breakpoint
CREATE INDEX "products_supplier_idx" ON "products" USING btree ("supplier_org_id");--> statement-breakpoint
CREATE INDEX "quote_items_quote_idx" ON "quote_items" USING btree ("quote_id");--> statement-breakpoint
CREATE UNIQUE INDEX "quote_requests_quote_no_key" ON "quote_requests" USING btree ("quote_no");--> statement-breakpoint
CREATE INDEX "quote_requests_retailer_idx" ON "quote_requests" USING btree ("retailer_org_id","created_at");--> statement-breakpoint
CREATE INDEX "quote_requests_supplier_idx" ON "quote_requests" USING btree ("supplier_org_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX "receipts_receipt_no_key" ON "receipts" USING btree ("receipt_no");--> statement-breakpoint
CREATE UNIQUE INDEX "receipts_payment_record_key" ON "receipts" USING btree ("payment_record_id");--> statement-breakpoint
CREATE UNIQUE INDEX "receipts_order_confirmation_key" ON "receipts" USING btree ("order_id") WHERE "receipts"."kind" = 'order';--> statement-breakpoint
CREATE INDEX "receipts_order_idx" ON "receipts" USING btree ("order_id");--> statement-breakpoint
CREATE UNIQUE INDEX "recurring_schedule_items_key" ON "recurring_schedule_items" USING btree ("schedule_id","product_id");--> statement-breakpoint
CREATE INDEX "recurring_schedules_org_idx" ON "recurring_schedules" USING btree ("retailer_org_id");--> statement-breakpoint
CREATE INDEX "recurring_schedules_due_idx" ON "recurring_schedules" USING btree ("next_run_at");--> statement-breakpoint
CREATE UNIQUE INDEX "retailer_inventory_org_product_key" ON "retailer_inventory" USING btree ("retailer_org_id","product_id");--> statement-breakpoint
CREATE INDEX "retailer_inventory_org_idx" ON "retailer_inventory" USING btree ("retailer_org_id");--> statement-breakpoint
CREATE UNIQUE INDEX "shipments_order_key" ON "shipments" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "stock_movements_inventory_idx" ON "stock_movements" USING btree ("inventory_id","created_at");