-- Auditability guarantees enforced by the database itself, so no application bug can
-- rewrite receipts, the order activity log, stock history or a verified payment.

CREATE OR REPLACE FUNCTION feristock_forbid_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '% is append-only: % is not allowed', TG_TABLE_NAME, TG_OP
    USING ERRCODE = 'integrity_constraint_violation';
END;
$$;
--> statement-breakpoint
CREATE TRIGGER receipts_append_only
  BEFORE UPDATE OR DELETE ON receipts
  FOR EACH ROW EXECUTE FUNCTION feristock_forbid_mutation();
--> statement-breakpoint
CREATE TRIGGER order_events_append_only
  BEFORE UPDATE OR DELETE ON order_events
  FOR EACH ROW EXECUTE FUNCTION feristock_forbid_mutation();
--> statement-breakpoint
CREATE TRIGGER stock_movements_append_only
  BEFORE UPDATE OR DELETE ON stock_movements
  FOR EACH ROW EXECUTE FUNCTION feristock_forbid_mutation();
--> statement-breakpoint
CREATE OR REPLACE FUNCTION feristock_freeze_verified_payment() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'payment records cannot be deleted'
      USING ERRCODE = 'integrity_constraint_violation';
  END IF;
  IF OLD.status = 'verified' THEN
    RAISE EXCEPTION 'a verified payment record is immutable'
      USING ERRCODE = 'integrity_constraint_violation';
  END IF;
  RETURN NEW;
END;
$$;
--> statement-breakpoint
CREATE TRIGGER payment_records_freeze_verified
  BEFORE UPDATE OR DELETE ON payment_records
  FOR EACH ROW EXECUTE FUNCTION feristock_freeze_verified_payment();
--> statement-breakpoint
CREATE OR REPLACE FUNCTION feristock_preserve_order_timestamps() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF (OLD.placed_at IS NOT NULL AND NEW.placed_at IS DISTINCT FROM OLD.placed_at)
    OR (OLD.accepted_at IS NOT NULL AND NEW.accepted_at IS DISTINCT FROM OLD.accepted_at)
    OR (OLD.packed_at IS NOT NULL AND NEW.packed_at IS DISTINCT FROM OLD.packed_at)
    OR (OLD.dispatched_at IS NOT NULL AND NEW.dispatched_at IS DISTINCT FROM OLD.dispatched_at)
    OR (OLD.delivered_at IS NOT NULL AND NEW.delivered_at IS DISTINCT FROM OLD.delivered_at)
    OR (OLD.stock_synced_at IS NOT NULL AND NEW.stock_synced_at IS DISTINCT FROM OLD.stock_synced_at)
    OR (OLD.closed_at IS NOT NULL AND NEW.closed_at IS DISTINCT FROM OLD.closed_at)
  THEN
    RAISE EXCEPTION 'order status timestamps cannot be changed once recorded'
      USING ERRCODE = 'integrity_constraint_violation';
  END IF;
  RETURN NEW;
END;
$$;
--> statement-breakpoint
CREATE TRIGGER orders_preserve_timestamps
  BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION feristock_preserve_order_timestamps();
--> statement-breakpoint
CREATE TRIGGER orders_no_delete
  BEFORE DELETE ON orders
  FOR EACH ROW EXECUTE FUNCTION feristock_forbid_mutation();
