import { randomUUID } from 'node:crypto'
import type { MemberRole, OrgRole } from '@/lib/constants'
import { buildContext, type AppContext } from '@/lib/context'
import { db } from '@/lib/db'
import { memberships, user } from '@/lib/db/schema'
import { createProduct } from '@/lib/domain/catalog'
import { createOrganization } from '@/lib/domain/orgs'
import type { BulkTier } from '@/lib/money'

let sequence = 0

async function createUser(name: string) {
  const id = randomUUID()
  const email = `${id}@example.com`
  await db.insert(user).values({ id, name, email })
  return { id, name, email }
}

/** Creates an organization with an owner and returns the owner's context. */
export async function makeOrg(role: OrgRole, name?: string): Promise<AppContext> {
  sequence += 1
  const owner = await createUser(`Owner ${sequence}`)
  const org = await createOrganization(owner, {
    name: name ?? `Organization ${sequence}`,
    role,
    panVatNo: String(100000000 + sequence),
    city: 'Kathmandu',
    address: 'New Road',
    phone: '9800000000',
    email: '',
  })
  return buildContext(owner, org, 'owner')
}

/** Adds another member to an existing organization and returns that member's context. */
export async function addMember(owner: AppContext, role: MemberRole): Promise<AppContext> {
  sequence += 1
  const member = await createUser(`Member ${sequence}`)
  await db.insert(memberships).values({ orgId: owner.org.id, userId: member.id, role })
  return buildContext(member, owner.org, role)
}

export async function makeProduct(
  supplier: AppContext,
  overrides: Partial<{ sku: string; name: string; unit: string; pricePaisa: number; moq: number; bulkTiers: BulkTier[] }> = {},
): Promise<string> {
  sequence += 1
  return createProduct(supplier, {
    sku: overrides.sku ?? `SKU-${sequence}`,
    name: overrides.name ?? `Product ${sequence}`,
    unit: overrides.unit ?? 'carton',
    category: '',
    pricePaisa: overrides.pricePaisa ?? 100_00,
    moq: overrides.moq ?? 1,
    schemeNote: '',
    bulkTiers: overrides.bulkTiers ?? [],
    isActive: true,
  })
}

/** Asserts a promise rejects with an AppError carrying the given code. */
export async function expectAppError(promise: Promise<unknown>, code: string): Promise<void> {
  try {
    await promise
  } catch (error) {
    const actual = (error as { name?: string; code?: string }) ?? {}
    if (actual.name === 'AppError' && actual.code === code) return
    throw new Error(`Expected AppError "${code}" but got ${actual.name ?? 'error'} "${actual.code ?? String(error)}"`)
  }
  throw new Error(`Expected AppError "${code}" but the call succeeded`)
}
