import { eq } from 'drizzle-orm'
import { beforeAll, describe, expect, it } from 'vitest'
import type { AppContext } from '@/lib/context'
import { addDays, nptToInstant, todayNpt } from '@/lib/dates'
import { databaseReady, db } from '@/lib/db'
import {
  orderEvents,
  orders,
  paymentRecords,
  receipts,
  recurringSchedules,
  stockMovements,
  supplierPaymentConfigs,
} from '@/lib/db/schema'
import { getCart, setCartQty, addInventoryToCart } from '@/lib/domain/cart'
import { getSupplierProfile, listSuppliers, setProductActive } from '@/lib/domain/catalog'
import { getLedger, getNavBadges } from '@/lib/domain/dashboard'
import { getFileForViewer, storeFile } from '@/lib/domain/files'
import { addInventoryItem, adjustStock, getStockHistory, listInventory } from '@/lib/domain/inventory'
import {
  acceptOrder,
  cancelOrder,
  confirmDelivery,
  dispatchOrder,
  getOrderDetail,
  listOrders,
  markDelivered,
  markPacked,
  placeOrderFromCart,
  rejectOrder,
  type OrderDetail,
} from '@/lib/domain/orders'
import {
  createInvite,
  getPaymentConfigView,
  joinOrganization,
  updatePaymentConfig,
  updateSupplierSettings,
} from '@/lib/domain/orgs'
import {
  confirmPaymentProof,
  decideCredit,
  recordReceivedPayment,
  rejectPaymentProof,
  requestCredit,
  startGatewayPayment,
  submitPaymentProof,
} from '@/lib/domain/payments'
import { acceptQuote, createQuoteRequest, getQuoteDetail, respondToQuote } from '@/lib/domain/quotes'
import { getReceiptForViewer } from '@/lib/domain/receipts'
import { listSchedules, runDueSchedules, saveSchedule } from '@/lib/domain/schedules'
import { addMember, expectAppError, makeOrg, makeProduct } from './helpers'

// A smallest valid PNG, for exercising private uploads.
const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==',
  'base64',
)

let shop: AppContext
let wholesaler: AppContext
let outsider: AppContext
let noodles: string
let tea: string

async function detail(context: AppContext, orderId: string): Promise<OrderDetail> {
  const order = await getOrderDetail(context, orderId)
  if (!order) throw new Error('order not visible')
  return order
}

/** Places an order from the shop for the given quantities and returns its id. */
async function placeOrder(lines: Array<[productId: string, qty: number]>, requestCredit = false): Promise<string> {
  for (const [productId, qty] of lines) await setCartQty(shop, productId, qty)
  const { orderId } = await placeOrderFromCart(shop, { supplierOrgId: wholesaler.org.id, note: '', requestCredit })
  return orderId
}

async function acceptAsIs(orderId: string, credit: { approve: boolean; dueDate: string | null } | null = null) {
  const order = await detail(wholesaler, orderId)
  await acceptOrder(wholesaler, {
    orderId,
    items: order.items.map((item) => ({ itemId: item.id, qty: item.qty, unitPricePaisa: item.unitPricePaisa })),
    supplierNote: '',
    credit,
  })
}

const pickup = (orderId: string) => ({
  orderId,
  deliveryMode: 'pickup' as const,
  carrierOrVan: '',
  driverName: '',
  driverPhone: '',
  biltiRef: '',
  biltiPhotoFileId: null,
  note: '',
})

beforeAll(async () => {
  await databaseReady()
  shop = await makeOrg('retailer', 'Himal Kirana')
  wholesaler = await makeOrg('supplier', 'Annapurna Traders')
  outsider = await makeOrg('both', 'Third Party Mart')
  noodles = await makeProduct(wholesaler, {
    name: 'Instant Noodles',
    pricePaisa: 600_00,
    moq: 2,
    bulkTiers: [
      { minQty: 10, pricePaisa: 580_00 },
      { minQty: 25, pricePaisa: 560_00 },
    ],
  })
  tea = await makeProduct(wholesaler, { name: 'CTC Tea', pricePaisa: 2_400_00 })
  await updateSupplierSettings(wholesaler, {
    deliveryModes: ['own_van', 'bilti', 'pickup'],
    deliveryNote: '',
    creditEnabled: true,
    creditDays: 15,
    minOrderPaisa: 1_000_00,
  })
})

describe('supplier directory', () => {
  it('lists other suppliers but never the viewer itself', async () => {
    const forShop = await listSuppliers(shop)
    expect(forShop.map((supplier) => supplier.name).sort()).toEqual(['Annapurna Traders', 'Third Party Mart'])
    const forOutsider = await listSuppliers(outsider)
    expect(forOutsider.map((supplier) => supplier.name)).toEqual(['Annapurna Traders'])
  })

  it('shows only active products in a supplier catalog', async () => {
    const hidden = await makeProduct(wholesaler, { name: 'Discontinued Soap' })
    await setProductActive(wholesaler, hidden, false)
    const profile = await getSupplierProfile(shop, wholesaler.org.id)
    expect(profile?.products.map((product) => product.name)).toEqual(['CTC Tea', 'Instant Noodles'])
    expect(profile?.supplier.creditEnabled).toBe(true)
  })
})

describe('cart and purchase orders', () => {
  it('prices the cart on the server with bulk tiers and flags lines under the MOQ', async () => {
    await setCartQty(shop, noodles, 1)
    let cart = await getCart(shop)
    expect(cart.groups[0].lines[0].issue).toMatch(/Minimum order is 2/)
    expect(cart.groups[0].canPlace).toBe(false)

    await setCartQty(shop, noodles, 12)
    cart = await getCart(shop)
    expect(cart.groups[0].lines[0].unitPricePaisa).toBe(580_00)
    expect(cart.groups[0].subtotalPaisa).toBe(12 * 580_00)
    expect(cart.groups[0].lines[0].nextTier).toEqual({ minQty: 25, pricePaisa: 560_00 })
    expect(cart.groups[0].canPlace).toBe(true)
    await setCartQty(shop, noodles, 0)
    expect((await getCart(shop)).lineCount).toBe(0)
  })

  it('refuses an order below the supplier minimum order value', async () => {
    await setCartQty(shop, noodles, 1)
    await expectAppError(placeOrderFromCart(shop, { supplierOrgId: wholesaler.org.id, note: '', requestCredit: false }), 'invalid')
    await setCartQty(shop, noodles, 0)
  })

  it('creates a pending order, snapshots prices and empties that supplier’s cart lines', async () => {
    const orderId = await placeOrder([
      [noodles, 25],
      [tea, 1],
    ])
    const order = await detail(shop, orderId)
    expect(order.status).toBe('pending')
    expect(order.orderNo).toMatch(/^PO-\d{6}$/)
    expect(order.totalPaisa).toBe(25 * 560_00 + 2_400_00)
    expect(order.items.map((item) => item.unitPricePaisa).sort((a, b) => a - b)).toEqual([560_00, 2_400_00])
    expect(order.timestamps.placedAt).not.toBeNull()
    expect((await getCart(shop)).lineCount).toBe(0)
    await cancelOrder(shop, orderId, 'Placed by mistake')
    expect((await detail(shop, orderId)).status).toBe('cancelled')
  })

  it('stops a staff member from placing orders', async () => {
    const staff = await addMember(shop, 'staff')
    await expectAppError(setCartQty(staff, noodles, 5), 'forbidden')
  })

  it('never lets an organization order from itself', async () => {
    const own = await makeProduct(outsider, { name: 'Own Label Rice' })
    await expectAppError(setCartQty(outsider, own, 3), 'invalid')
  })
})

describe('tenant isolation', () => {
  it('hides an order from organizations that are not a party to it', async () => {
    const orderId = await placeOrder([[tea, 1]])
    expect(await getOrderDetail(outsider, orderId)).toBeNull()
    expect((await listOrders(outsider, 'supplier')).some((order) => order.id === orderId)).toBe(false)
    await expectAppError(
      acceptOrder(outsider, { orderId, items: [{ itemId: orderId, qty: 1, unitPricePaisa: 1 }], supplierNote: '', credit: null }),
      'not_found',
    )
    await expectAppError(cancelOrder(outsider, orderId, 'not mine'), 'not_found')
    await rejectOrder(wholesaler, orderId, 'Out of stock this week')
    expect((await detail(shop, orderId)).status).toBe('rejected')
  })

  it('keeps payment credentials out of every read model', async () => {
    await updatePaymentConfig(wholesaler, {
      esewaEnabled: true,
      esewaMerchantId: 'EPAYTEST',
      esewaSecret: '8gBm/:&EnhH.1/q',
      esewaEnv: 'test',
      khaltiEnabled: false,
      khaltiSecret: '',
      khaltiEnv: 'test',
      bankName: 'Nabil Bank',
      accountName: 'Annapurna Traders',
      accountNumber: '0101017500123',
      branch: 'Kalimati',
    })
    const view = await getPaymentConfigView(wholesaler.org.id)
    expect(view.esewa).toEqual({ enabled: true, merchantId: 'EPAYTEST', env: 'test', hasSecret: true })
    expect(JSON.stringify(view)).not.toContain('8gBm')

    const [stored] = await db.select().from(supplierPaymentConfigs).where(eq(supplierPaymentConfigs.orgId, wholesaler.org.id))
    expect(stored.esewaSecretEnc).toMatch(/^v1:/)
    expect(stored.esewaSecretEnc).not.toContain('8gBm')

    const manager = await addMember(wholesaler, 'manager')
    await expectAppError(updatePaymentConfig(manager, {} as Parameters<typeof updatePaymentConfig>[1]), 'forbidden')
  })
})

describe('fulfilment', () => {
  it('lets the supplier supply less or cheaper, but never more or dearer', async () => {
    const orderId = await placeOrder([
      [noodles, 10],
      [tea, 2],
    ])
    const order = await detail(wholesaler, orderId)
    const noodleLine = order.items.find((item) => item.name === 'Instant Noodles')!
    const teaLine = order.items.find((item) => item.name === 'CTC Tea')!
    const items = (noodleQty: number, noodlePrice: number) => [
      { itemId: noodleLine.id, qty: noodleQty, unitPricePaisa: noodlePrice },
      { itemId: teaLine.id, qty: 2, unitPricePaisa: teaLine.unitPricePaisa },
    ]

    await expectAppError(acceptOrder(wholesaler, { orderId, items: items(11, 580_00), supplierNote: '', credit: null }), 'invalid')
    await expectAppError(acceptOrder(wholesaler, { orderId, items: items(10, 590_00), supplierNote: '', credit: null }), 'invalid')

    await acceptOrder(wholesaler, { orderId, items: items(8, 570_00), supplierNote: 'Two cartons short', credit: null })
    const accepted = await detail(shop, orderId)
    expect(accepted.status).toBe('accepted')
    expect(accepted.totalPaisa).toBe(8 * 570_00 + 2 * 2_400_00)
    expect(accepted.items.find((item) => item.name === 'Instant Noodles')).toMatchObject({ requestedQty: 10, qty: 8 })
    expect(accepted.receipts.map((receipt) => receipt.kind)).toEqual(['order'])
    expect(accepted.events.some((event) => event.type === 'adjustment')).toBe(true)
  })

  it('walks pending → accepted → packed → dispatched → delivered and rejects skipped stages', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await expectAppError(markPacked(wholesaler, orderId), 'conflict')
    await acceptAsIs(orderId)
    await expectAppError(dispatchOrder(wholesaler, pickup(orderId)), 'conflict')
    await expectAppError(cancelOrder(shop, orderId, 'changed my mind'), 'conflict')
    await markPacked(wholesaler, orderId)
    await dispatchOrder(wholesaler, {
      ...pickup(orderId),
      deliveryMode: 'bilti',
      carrierOrVan: 'Koshi Yatayat',
      biltiRef: 'BLT-48213',
    })

    const dispatched = await detail(shop, orderId)
    expect(dispatched.status).toBe('dispatched')
    expect(dispatched.shipment).toMatchObject({ deliveryMode: 'bilti', carrierOrVan: 'Koshi Yatayat', biltiRef: 'BLT-48213' })
    expect(dispatched.actions).toContain('confirm_delivery')
    await expectAppError(cancelOrder(wholesaler, orderId, 'too late'), 'conflict')

    await confirmDelivery(shop, { orderId, items: dispatched.items.map((item) => ({ itemId: item.id, receivedQty: item.qty })) })
    const delivered = await detail(shop, orderId)
    expect(delivered.status).toBe('delivered')
    expect(delivered.timestamps.stockSyncedAt).not.toBeNull()
    for (const stamp of ['placedAt', 'acceptedAt', 'packedAt', 'dispatchedAt', 'deliveredAt'] as const) {
      expect(delivered.timestamps[stamp]).not.toBeNull()
    }
  })

  it('shares a bilti photo with the buyer only once it is attached to their order', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await acceptAsIs(orderId)
    await markPacked(wholesaler, orderId)
    const photoId = await storeFile(wholesaler, 'bilti_photo', PNG)

    expect(await getFileForViewer(shop, photoId)).toBeNull()
    await dispatchOrder(wholesaler, { ...pickup(orderId), deliveryMode: 'bilti', carrierOrVan: 'Koshi Yatayat', biltiRef: 'B-1', biltiPhotoFileId: photoId })
    const forBuyer = await getFileForViewer(shop, photoId)
    expect(forBuyer?.contentType).toBe('image/png')
    expect(forBuyer?.data.equals(PNG)).toBe(true)
    expect(await getFileForViewer(outsider, photoId)).toBeNull()
    await expectAppError(storeFile(wholesaler, 'bilti_photo', Buffer.from('<script>alert(1)</script>')), 'invalid')
  })
})

describe('delivery and stock sync', () => {
  it('adds received quantities to shop stock exactly once, with a ledger entry', async () => {
    const inventoryId = await addInventoryItem(shop, {
      productId: noodles,
      customName: '',
      customUnit: '',
      currentQty: 3,
      reorderThreshold: 10,
      reorderQty: null,
    })
    const orderId = await placeOrder([[noodles, 10]])
    await acceptAsIs(orderId)
    await markPacked(wholesaler, orderId)
    await dispatchOrder(wholesaler, pickup(orderId))
    const order = await detail(shop, orderId)

    // One carton arrived damaged: 9 received of 10 ordered.
    await confirmDelivery(shop, { orderId, items: [{ itemId: order.items[0].id, receivedQty: 9 }] })
    const item = (await listInventory(shop)).find((row) => row.id === inventoryId)!
    expect(item.currentQty).toBe(12)
    expect(item.status).toBe('ok')

    await expectAppError(confirmDelivery(shop, { orderId, items: [{ itemId: order.items[0].id, receivedQty: 9 }] }), 'conflict')
    expect((await listInventory(shop)).find((row) => row.id === inventoryId)!.currentQty).toBe(12)

    const history = await getStockHistory(shop, inventoryId)
    expect(history[0]).toMatchObject({ delta: 9, qtyAfter: 12, reason: 'delivery', orderId })
    expect((await detail(shop, orderId)).items[0].receivedQty).toBe(9)
  })

  it('starts tracking a product automatically the first time it is received', async () => {
    const oil = await makeProduct(wholesaler, { name: 'Mustard Oil', pricePaisa: 3_000_00 })
    expect((await listInventory(shop)).some((row) => row.name === 'Mustard Oil')).toBe(false)

    const orderId = await placeOrder([[oil, 2]])
    await acceptAsIs(orderId)
    await markPacked(wholesaler, orderId)
    await dispatchOrder(wholesaler, pickup(orderId))
    // The supplier closes the delivery first; the shop still counts the goods in afterwards.
    await markDelivered(wholesaler, orderId)
    const closed = await detail(shop, orderId)
    expect(closed.status).toBe('delivered')
    expect(closed.actions).toContain('confirm_delivery')

    await confirmDelivery(shop, { orderId, items: closed.items.map((line) => ({ itemId: line.id, receivedQty: line.qty })) })
    const oilRow = (await listInventory(shop)).find((row) => row.name === 'Mustard Oil')
    expect(oilRow).toMatchObject({ currentQty: 2, isCustom: false })
    expect(oilRow?.supplier?.name).toBe('Annapurna Traders')
  })

  it('never lets manual counting push stock below zero', async () => {
    const [item] = (await listInventory(shop)).filter((row) => row.name === 'CTC Tea')
    expect(await adjustStock(shop, item.id, -50)).toBe(0)
    expect(await adjustStock(shop, item.id, 4)).toBe(4)
    await expectAppError(adjustStock(outsider, item.id, 1), 'not_found')
  })

  it('reorders every low item in one step at its suggested quantity', async () => {
    const [noodleRow] = (await listInventory(shop)).filter((row) => row.name === 'Instant Noodles')
    await adjustStock(shop, noodleRow.id, -noodleRow.currentQty + 2)
    const result = await addInventoryToCart(shop, 'low-stock')
    expect(result.added).toBe(1)
    const cart = await getCart(shop)
    // Threshold 10 → restock to 20; 2 on hand → order 18.
    expect(cart.groups[0].lines.find((line) => line.name === 'Instant Noodles')?.qty).toBe(18)
    expect((await getNavBadges(shop)).cart).toBe(1)
    await setCartQty(shop, noodles, 0)
  })
})

describe('payments and receipts', () => {
  it('marks an order paid only after the supplier confirms the proof, then issues a receipt', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await expectAppError(
      submitPaymentProof(shop, { orderId, amountPaisa: 2_400_00, transactionRef: 'FT123', proofFileId: null, note: '' }),
      'conflict',
    )
    await acceptAsIs(orderId)

    await expectAppError(
      submitPaymentProof(shop, { orderId, amountPaisa: 2_400_01, transactionRef: 'FT123', proofFileId: null, note: '' }),
      'invalid',
    )
    await submitPaymentProof(shop, { orderId, amountPaisa: 2_400_00, transactionRef: 'FT123', proofFileId: null, note: '' })
    let order = await detail(wholesaler, orderId)
    expect(order.paymentStatus).toBe('pending')
    expect(order.paidPaisa).toBe(0)

    const proof = order.payments[0]
    await expectAppError(confirmPaymentProof(shop, proof.id), 'forbidden')
    await expectAppError(confirmPaymentProof(outsider, proof.id), 'not_found')
    await confirmPaymentProof(wholesaler, proof.id)

    order = await detail(shop, orderId)
    expect(order.paymentStatus).toBe('paid')
    expect(order.balancePaisa).toBe(0)
    expect(order.payments[0]).toMatchObject({ status: 'verified', transactionRef: 'FT123' })
    await expectAppError(confirmPaymentProof(wholesaler, proof.id), 'conflict')

    const receiptId = order.payments[0].receipt!.id
    const receipt = await getReceiptForViewer(shop, receiptId)
    expect(receipt?.receiptNo).toMatch(/^RC-\d{6}$/)
    expect(receipt?.snapshot.payment).toMatchObject({ method: 'qr_bank', transactionRef: 'FT123', amountPaisa: 2_400_00 })
    expect(receipt?.snapshot.supplier.name).toBe('Annapurna Traders')
    expect(receipt?.snapshot.buyer.name).toBe('Himal Kirana')
    expect(receipt?.snapshot.totals).toEqual({ totalPaisa: 2_400_00, paidToDatePaisa: 2_400_00, balancePaisa: 0 })
    expect(await getReceiptForViewer(outsider, receiptId)).toBeNull()
  })

  it('returns to unpaid when the supplier rejects a proof', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await acceptAsIs(orderId)
    await submitPaymentProof(shop, { orderId, amountPaisa: 2_400_00, transactionRef: 'WRONG', proofFileId: null, note: '' })
    const pending = await detail(wholesaler, orderId)
    await rejectPaymentProof(wholesaler, pending.payments[0].id, 'No such transfer in our statement')
    const order = await detail(shop, orderId)
    expect(order.paymentStatus).toBe('unpaid')
    expect(order.payments[0]).toMatchObject({ status: 'rejected', rejectReason: 'No such transfer in our statement' })
    expect(order.receipts.filter((receipt) => receipt.kind === 'payment')).toHaveLength(0)
  })

  it('tracks udharo: approval, part payment, settlement and the ledger on both sides', async () => {
    const orderId = await placeOrder([[tea, 2]], true)
    const dueDate = addDays(todayNpt(), 15)
    const pendingOrder = await detail(wholesaler, orderId)
    await expectAppError(
      acceptOrder(wholesaler, {
        orderId,
        items: pendingOrder.items.map((item) => ({ itemId: item.id, qty: item.qty, unitPricePaisa: item.unitPricePaisa })),
        supplierNote: '',
        credit: null,
      }),
      'invalid',
    )
    await acceptAsIs(orderId, { approve: true, dueDate })

    let order = await detail(shop, orderId)
    expect(order).toMatchObject({ paymentStatus: 'credit', creditState: 'approved', dueDate, overdue: false })

    await recordReceivedPayment(wholesaler, { orderId, amountPaisa: 1_800_00, transactionRef: 'CHQ 004512', note: '' })
    order = await detail(shop, orderId)
    expect(order).toMatchObject({ paymentStatus: 'partial', paidPaisa: 1_800_00, balancePaisa: 3_000_00 })

    const payable = (await getLedger(shop, 'retailer')).rows.find((row) => row.orderId === orderId)
    const receivable = (await getLedger(wholesaler, 'supplier')).rows.find((row) => row.orderId === orderId)
    expect(payable).toMatchObject({ balancePaisa: 3_000_00, dueDate, daysUntilDue: 15, overdue: false })
    expect(receivable?.counterparty.name).toBe('Himal Kirana')

    await expectAppError(
      recordReceivedPayment(wholesaler, { orderId, amountPaisa: 3_000_01, transactionRef: '', note: '' }),
      'invalid',
    )
    await recordReceivedPayment(wholesaler, { orderId, amountPaisa: 3_000_00, transactionRef: '', note: 'Cash' })
    order = await detail(shop, orderId)
    expect(order.paymentStatus).toBe('paid')
    expect(order.receipts.filter((receipt) => receipt.kind === 'payment')).toHaveLength(2)
    expect((await getLedger(shop, 'retailer')).rows.some((row) => row.orderId === orderId)).toBe(false)
    await expectAppError(cancelOrder(wholesaler, orderId, 'cannot after payment'), 'conflict')
  })

  it('lets a buyer ask for credit after acceptance and the supplier decline it', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await acceptAsIs(orderId)
    await requestCredit(shop, orderId)
    expect((await detail(wholesaler, orderId)).actions).toContain('decide_credit')
    await expectAppError(decideCredit(wholesaler, { orderId, approve: true, dueDate: addDays(todayNpt(), -1) }), 'invalid')
    await decideCredit(wholesaler, { orderId, approve: false, dueDate: null })
    expect((await detail(shop, orderId)).creditState).toBe('declined')
  })

  it('starts an eSewa checkout signed for the supplier’s own merchant account', async () => {
    const orderId = await placeOrder([[tea, 1]])
    await acceptAsIs(orderId)
    const start = await startGatewayPayment(shop, { orderId, method: 'esewa', amountPaisa: 2_400_00 }, 'https://app.example.com')
    if (start.kind !== 'form') throw new Error('expected an eSewa form')
    expect(start.form.fields.product_code).toBe('EPAYTEST')
    expect(start.form.fields.total_amount).toBe('2400')
    expect(start.form.fields.success_url).toBe(`https://app.example.com/api/payments/esewa/return/${start.paymentId}`)
    expect(start.form.fields.transaction_uuid).toMatch(/^PO-\d{6}-[0-9a-f]{12}$/)

    // Starting a checkout records an attempt but must not move any money figures.
    const order = await detail(shop, orderId)
    expect(order).toMatchObject({ paymentStatus: 'unpaid', paidPaisa: 0 })
    expect(order.payments[0]).toMatchObject({ method: 'esewa', status: 'initiated', gatewayEnv: 'test' })

    await expectAppError(
      startGatewayPayment(shop, { orderId, method: 'khalti', amountPaisa: 2_400_00 }, 'https://app.example.com'),
      'invalid',
    )
    await expectAppError(
      startGatewayPayment(outsider, { orderId, method: 'esewa', amountPaisa: 2_400_00 }, 'https://app.example.com'),
      'not_found',
    )
  })
})

describe('audit trail', () => {
  let orderId: string

  beforeAll(async () => {
    orderId = await placeOrder([[tea, 1]])
    await acceptAsIs(orderId)
    await recordReceivedPayment(wholesaler, { orderId, amountPaisa: 2_400_00, transactionRef: 'CASH-1', note: '' })
  })

  it('refuses to alter or delete an issued receipt', async () => {
    await expect(db.update(receipts).set({ receiptNo: 'RC-HACKED' }).where(eq(receipts.orderId, orderId))).rejects.toThrow()
    await expect(db.delete(receipts).where(eq(receipts.orderId, orderId))).rejects.toThrow()
  })

  it('refuses to rewrite a verified payment', async () => {
    await expect(
      db.update(paymentRecords).set({ amountPaisa: 1, transactionRef: 'forged' }).where(eq(paymentRecords.orderId, orderId)),
    ).rejects.toThrow()
    await expect(db.delete(paymentRecords).where(eq(paymentRecords.orderId, orderId))).rejects.toThrow()
  })

  it('refuses to edit the activity log, stock ledger or recorded status timestamps', async () => {
    await expect(db.update(orderEvents).set({ message: 'nothing happened' }).where(eq(orderEvents.orderId, orderId))).rejects.toThrow()
    await expect(db.delete(orderEvents).where(eq(orderEvents.orderId, orderId))).rejects.toThrow()
    await expect(db.update(stockMovements).set({ delta: 999 })).rejects.toThrow()
    await expect(db.update(orders).set({ acceptedAt: new Date('2020-01-01') }).where(eq(orders.id, orderId))).rejects.toThrow()
    await expect(db.delete(orders).where(eq(orders.id, orderId))).rejects.toThrow()
  })
})

describe('recurring schedules', () => {
  it('creates one draft per due schedule and moves it to the next slot', async () => {
    const scheduleId = await saveSchedule(shop, {
      id: null,
      supplierOrgId: wholesaler.org.id,
      name: 'Weekly noodles',
      frequency: 'weekly',
      dayOfWeek: 1,
      dayOfMonth: null,
      timeOfDay: '09:00',
      mode: 'draft',
      isActive: true,
      items: [{ productId: noodles, qty: 12 }],
    })
    expect((await runDueSchedules({ orgId: shop.org.id })).orders).toBe(0)

    // Pretend the slot came round three weeks ago and nobody opened the app since.
    await db
      .update(recurringSchedules)
      .set({ nextRunAt: nptToInstant(2026, 1, 5, 9, 0) })
      .where(eq(recurringSchedules.id, scheduleId))

    const [first, second] = await Promise.all([
      runDueSchedules({ orgId: shop.org.id }),
      runDueSchedules({ orgId: shop.org.id }),
    ])
    expect(first.orders + second.orders).toBe(1)

    const [schedule] = await listSchedules(shop)
    expect(new Date(schedule.nextRunAt).getTime()).toBeGreaterThan(Date.now())
    const draft = await detail(shop, schedule.lastOrder!.id)
    expect(draft).toMatchObject({ status: 'draft', orderType: 'scheduled', totalPaisa: 12 * 580_00 })
    // The supplier does not see a draft until the shop sends it.
    expect(await getOrderDetail(wholesaler, draft.id)).toBeNull()
    expect((await runDueSchedules({ orgId: shop.org.id })).orders).toBe(0)
  })

  it('rejects a schedule line below the product MOQ', async () => {
    await expectAppError(
      saveSchedule(shop, {
        id: null,
        supplierOrgId: wholesaler.org.id,
        name: 'Too small',
        frequency: 'monthly',
        dayOfWeek: null,
        dayOfMonth: 1,
        timeOfDay: '08:00',
        mode: 'auto',
        isActive: true,
        items: [{ productId: noodles, qty: 1 }],
      }),
      'invalid',
    )
  })
})

describe('custom quotes', () => {
  it('turns an accepted quote into an order at the quoted prices, including unlisted items', async () => {
    const quoteId = await createQuoteRequest(shop, {
      supplierOrgId: wholesaler.org.id,
      note: 'Festival stock for Dashain',
      items: [
        { productId: noodles, name: 'Instant Noodles', unit: 'carton', qty: 100, targetPricePaisa: 540_00 },
        { productId: null, name: 'Gift hamper box (unlisted)', unit: 'pcs', qty: 40, targetPricePaisa: null },
      ],
    })
    expect(await getQuoteDetail(outsider, quoteId)).toBeNull()
    await expectAppError(acceptQuote(shop, { quoteId, requestCredit: false }), 'conflict')

    const requested = await getQuoteDetail(wholesaler, quoteId)
    await respondToQuote(wholesaler, {
      quoteId,
      supplierNote: 'Can do 80 cartons at this price',
      validUntil: addDays(todayNpt(), 7),
      items: [
        { itemId: requested!.items[0].id, quotedQty: 80, quotedPricePaisa: 545_00 },
        { itemId: requested!.items[1].id, quotedQty: 40, quotedPricePaisa: 120_00 },
      ],
    })
    expect((await getQuoteDetail(shop, quoteId))?.quotedTotalPaisa).toBe(80 * 545_00 + 40 * 120_00)

    const { orderId } = await acceptQuote(shop, { quoteId, requestCredit: false })
    const order = await detail(wholesaler, orderId)
    expect(order).toMatchObject({ status: 'accepted', orderType: 'custom', totalPaisa: 80 * 545_00 + 40 * 120_00 })
    expect(order.receipts.map((receipt) => receipt.kind)).toEqual(['order'])
    expect((await getQuoteDetail(shop, quoteId))?.order?.id).toBe(orderId)
    await expectAppError(acceptQuote(shop, { quoteId, requestCredit: false }), 'conflict')
  })
})

describe('joining an organization', () => {
  it('accepts an invite code once and gives the invited role', async () => {
    const invite = await createInvite(shop, 'manager')
    const { randomUUID } = await import('node:crypto')
    const { user } = await import('@/lib/db/schema')
    const newcomer = { id: randomUUID(), name: 'New Manager', email: `${randomUUID()}@example.com` }
    const latecomer = { id: randomUUID(), name: 'Late Comer', email: `${randomUUID()}@example.com` }
    await db.insert(user).values([newcomer, latecomer])

    expect(await joinOrganization(newcomer, invite.code)).toBe(shop.org.id)
    await expectAppError(joinOrganization(latecomer, invite.code), 'invalid')
    await expectAppError(joinOrganization(latecomer, 'AAAAAAAAAAAA'), 'invalid')
    await expectAppError(createInvite(await addMember(shop, 'manager'), 'staff'), 'forbidden')
  })
})
