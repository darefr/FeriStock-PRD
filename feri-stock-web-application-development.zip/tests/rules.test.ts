import { describe, expect, it } from 'vitest'
import { decryptSecret, encryptSecret, generateInviteCode } from '@/lib/crypto'
import {
  addDays,
  daysBetween,
  formatDate,
  formatDateTime,
  isDateString,
  nptToInstant,
  todayNpt,
} from '@/lib/dates'
import { buildEsewaForm, esewaAmountToPaisa, esewaRequestSignature } from '@/lib/domain/gateways/esewa'
import { derivePaymentStatus, isOverdue, orderActions } from '@/lib/domain/order-rules'
import { stockStatus, suggestReorderQty } from '@/lib/domain/stock-rules'
import { formatInviteCode } from '@/lib/format'
import { formatNpr, nextTier, paisaToRupeeString, parseRupees, unitPriceForQty } from '@/lib/money'
import { can } from '@/lib/permissions'
import { computeNextRun } from '@/lib/schedule'
import { joinOrganizationSchema, productSchema } from '@/lib/validation'

describe('money', () => {
  it('formats rupees with Nepali digit grouping', () => {
    expect(formatNpr(0)).toBe('Rs. 0')
    expect(formatNpr(99_900)).toBe('Rs. 999')
    expect(formatNpr(125_000_00)).toBe('Rs. 1,25,000')
    expect(formatNpr(1_234_567_850)).toBe('Rs. 1,23,45,678.50')
    expect(formatNpr(5, { decimals: 'always' })).toBe('Rs. 0.05')
  })

  it('parses typed rupee amounts into paisa and rejects junk', () => {
    expect(parseRupees('1,250.50')).toBe(125_050)
    expect(parseRupees('75')).toBe(7_500)
    expect(parseRupees('0.5')).toBe(50)
    expect(parseRupees('12.345')).toBeNull()
    expect(parseRupees('-5')).toBeNull()
    expect(parseRupees('abc')).toBeNull()
  })

  it('round-trips paisa through the gateway string form', () => {
    expect(paisaToRupeeString(125_050)).toBe('1250.50')
    expect(paisaToRupeeString(125_000)).toBe('1250')
    expect(parseRupees(paisaToRupeeString(999_999_99))).toBe(999_999_99)
  })

  it('applies the highest bulk tier that the quantity reaches', () => {
    const tiers = [
      { minQty: 25, pricePaisa: 560_00 },
      { minQty: 10, pricePaisa: 580_00 },
    ]
    expect(unitPriceForQty(600_00, tiers, 9)).toBe(600_00)
    expect(unitPriceForQty(600_00, tiers, 10)).toBe(580_00)
    expect(unitPriceForQty(600_00, tiers, 24)).toBe(580_00)
    expect(unitPriceForQty(600_00, tiers, 25)).toBe(560_00)
    expect(nextTier(tiers, 9)).toEqual({ minQty: 10, pricePaisa: 580_00 })
    expect(nextTier(tiers, 25)).toBeNull()
  })
})

describe('Nepal time', () => {
  it('uses the Nepal calendar day, which starts at 18:15 UTC', () => {
    expect(todayNpt(new Date('2026-11-21T18:14:59Z'))).toBe('2026-11-21')
    expect(todayNpt(new Date('2026-11-21T18:15:00Z'))).toBe('2026-11-22')
  })

  it('formats instants in Nepal time regardless of the server time zone', () => {
    expect(formatDate('2026-11-21T20:00:00Z')).toBe('22 Nov 2026')
    expect(formatDateTime('2026-11-21T10:00:00Z')).toBe('21 Nov 2026, 3:45 PM')
  })

  it('does calendar arithmetic across month and year ends', () => {
    expect(addDays('2026-12-25', 15)).toBe('2027-01-09')
    expect(addDays('2028-03-01', -1)).toBe('2028-02-29')
    expect(daysBetween('2026-11-21', '2026-12-06')).toBe(15)
    expect(isDateString('2026-02-30')).toBe(false)
    expect(isDateString('2026-02-28')).toBe(true)
  })
})

describe('recurring schedule', () => {
  // Saturday 21 Nov 2026, 10:00 in Nepal.
  const now = nptToInstant(2026, 11, 21, 10, 0)

  it('runs later the same day when the weekly slot has not passed', () => {
    const next = computeNextRun({ frequency: 'weekly', dayOfWeek: 6, dayOfMonth: null, timeOfDay: '16:30' }, now)
    expect(next).toEqual(nptToInstant(2026, 11, 21, 16, 30))
  })

  it('waits a full week when the weekly slot has already passed today', () => {
    const next = computeNextRun({ frequency: 'weekly', dayOfWeek: 6, dayOfMonth: null, timeOfDay: '09:00' }, now)
    expect(next).toEqual(nptToInstant(2026, 11, 28, 9, 0))
  })

  it('finds the next weekday across a month boundary', () => {
    const next = computeNextRun({ frequency: 'weekly', dayOfWeek: 2, dayOfMonth: null, timeOfDay: '08:00' }, now)
    expect(next).toEqual(nptToInstant(2026, 11, 24, 8, 0))
  })

  it('rolls monthly schedules into the next month and year', () => {
    const rule = { frequency: 'monthly' as const, dayOfWeek: null, dayOfMonth: 5, timeOfDay: '07:00' }
    expect(computeNextRun(rule, now)).toEqual(nptToInstant(2026, 12, 5, 7, 0))
    expect(computeNextRun(rule, nptToInstant(2026, 12, 20, 0, 0))).toEqual(nptToInstant(2027, 1, 5, 7, 0))
  })

  it('is always strictly in the future', () => {
    const rule = { frequency: 'weekly' as const, dayOfWeek: 6, dayOfMonth: null, timeOfDay: '10:00' }
    expect(computeNextRun(rule, now).getTime()).toBeGreaterThan(now.getTime())
  })
})

describe('stock rules', () => {
  it('classifies stock against the reorder threshold', () => {
    expect(stockStatus(0, 5)).toBe('out')
    expect(stockStatus(5, 5)).toBe('low')
    expect(stockStatus(6, 5)).toBe('ok')
    expect(stockStatus(3, 0)).toBe('ok')
  })

  it('suggests a restock quantity that respects the MOQ', () => {
    expect(suggestReorderQty({ currentQty: 2, reorderThreshold: 10, reorderQty: null, moq: 1 })).toBe(18)
    expect(suggestReorderQty({ currentQty: 2, reorderThreshold: 10, reorderQty: 30, moq: 1 })).toBe(30)
    expect(suggestReorderQty({ currentQty: 9, reorderThreshold: 5, reorderQty: null, moq: 12 })).toBe(12)
    expect(suggestReorderQty({ currentQty: 0, reorderThreshold: 0, reorderQty: 3, moq: 6 })).toBe(6)
  })
})

describe('order rules', () => {
  const base = { totalPaisa: 1000, paidPaisa: 0, creditState: 'none' as const, stockSyncedAt: null }

  it('derives the payment status from verified money and credit', () => {
    const input = { totalPaisa: 1000, paidPaisa: 0, creditState: 'none' as const, hasPendingProof: false }
    expect(derivePaymentStatus(input)).toBe('unpaid')
    expect(derivePaymentStatus({ ...input, hasPendingProof: true })).toBe('pending')
    expect(derivePaymentStatus({ ...input, creditState: 'approved' })).toBe('credit')
    expect(derivePaymentStatus({ ...input, paidPaisa: 400, creditState: 'approved' })).toBe('partial')
    expect(derivePaymentStatus({ ...input, paidPaisa: 1000 })).toBe('paid')
  })

  it('only lets the supplier act on a pending order, and the buyer withdraw it', () => {
    expect([...orderActions({ ...base, status: 'pending' }, 'supplier')].sort()).toEqual(['accept', 'reject'])
    expect([...orderActions({ ...base, status: 'pending' }, 'retailer')]).toEqual(['cancel'])
  })

  it('offers payment only once the supplier has committed', () => {
    expect(orderActions({ ...base, status: 'pending' }, 'retailer').has('pay')).toBe(false)
    expect(orderActions({ ...base, status: 'accepted' }, 'retailer').has('pay')).toBe(true)
    expect(orderActions({ ...base, status: 'delivered', paidPaisa: 1000 }, 'retailer').has('pay')).toBe(false)
  })

  it('stops a supplier cancelling once money has been received', () => {
    expect(orderActions({ ...base, status: 'packed' }, 'supplier').has('cancel')).toBe(true)
    expect(orderActions({ ...base, status: 'packed', paidPaisa: 1 }, 'supplier').has('cancel')).toBe(false)
    expect(orderActions({ ...base, status: 'dispatched' }, 'supplier').has('cancel')).toBe(false)
  })

  it('keeps delivery confirmation open until stock has been counted in', () => {
    expect(orderActions({ ...base, status: 'delivered' }, 'retailer').has('confirm_delivery')).toBe(true)
    expect(
      orderActions({ ...base, status: 'delivered', stockSyncedAt: new Date() }, 'retailer').has('confirm_delivery'),
    ).toBe(false)
  })

  it('flags approved credit as overdue only after the due date with a balance left', () => {
    const order = { ...base, status: 'delivered' as const, creditState: 'approved' as const, dueDate: '2026-11-20' }
    expect(isOverdue(order, '2026-11-20')).toBe(false)
    expect(isOverdue(order, '2026-11-21')).toBe(true)
    expect(isOverdue({ ...order, paidPaisa: 1000 }, '2026-11-21')).toBe(false)
    expect(isOverdue({ ...order, creditState: 'none' }, '2026-11-21')).toBe(false)
  })
})

describe('permissions', () => {
  it('reserves credentials and team management for owners', () => {
    expect(can('owner', 'payments:configure')).toBe(true)
    expect(can('manager', 'payments:configure')).toBe(false)
    expect(can('manager', 'team:manage')).toBe(false)
  })

  it('limits staff to counting stock and moving goods', () => {
    expect(can('staff', 'stock:update')).toBe(true)
    expect(can('staff', 'fulfilment:update')).toBe(true)
    expect(can('staff', 'orders:place')).toBe(false)
    expect(can('staff', 'payments:manage')).toBe(false)
    expect(can('staff', 'catalog:manage')).toBe(false)
  })
})

describe('eSewa ePay v2', () => {
  // Base64 HMAC-SHA256 over "total_amount=…,transaction_uuid=…,product_code=…" with the merchant secret.
  // The scheme was confirmed against eSewa's UAT endpoint: it accepts signatures produced this way and
  // answers ES104 "Invalid payload signature" when one is altered. (The sample signature printed in
  // eSewa's own documentation does not correspond to the sample inputs beside it.)
  it('signs the request fields in the order eSewa expects', () => {
    expect(
      esewaRequestSignature('8gBm/:&EnhH.1/q', {
        totalAmount: '100',
        transactionUuid: '11-201-13',
        productCode: 'EPAYTEST',
      }),
    ).toBe('5DZywcrTKD0gia/rsSMcrRHmJl+4Tbol6S+lWgdJ94E=')
  })

  it('produces a different signature when any signed field changes', () => {
    const base = { totalAmount: '100', transactionUuid: '11-201-13', productCode: 'EPAYTEST' }
    const signature = esewaRequestSignature('8gBm/:&EnhH.1/q', base)
    expect(esewaRequestSignature('8gBm/:&EnhH.1/q', { ...base, totalAmount: '1000' })).not.toBe(signature)
    expect(esewaRequestSignature('8gBm/:&EnhH.1/q', { ...base, transactionUuid: '11-201-14' })).not.toBe(signature)
    expect(esewaRequestSignature('another-secret', base)).not.toBe(signature)
  })

  it('builds a form whose signed fields match what is posted', () => {
    const { action, fields } = buildEsewaForm({
      env: 'test',
      merchantCode: 'EPAYTEST',
      secret: '8gBm/:&EnhH.1/q',
      amountPaisa: 125_050,
      transactionUuid: 'PO-001001-abc123',
      successUrl: 'https://example.com/ok',
      failureUrl: 'https://example.com/fail',
    })
    expect(action).toBe('https://rc-epay.esewa.com.np/api/epay/main/v2/form')
    expect(fields.total_amount).toBe('1250.50')
    expect(fields.amount).toBe('1250.50')
    expect(fields.signed_field_names).toBe('total_amount,transaction_uuid,product_code')
    expect(fields.signature).toBe(
      esewaRequestSignature('8gBm/:&EnhH.1/q', {
        totalAmount: '1250.50',
        transactionUuid: 'PO-001001-abc123',
        productCode: 'EPAYTEST',
      }),
    )
  })

  it('reads the amounts eSewa reports, including its formatted strings', () => {
    expect(esewaAmountToPaisa(100)).toBe(10_000)
    expect(esewaAmountToPaisa(1250.5)).toBe(125_050)
    expect(esewaAmountToPaisa('1,000.0')).toBe(100_000)
    expect(esewaAmountToPaisa(undefined)).toBeNull()
    expect(esewaAmountToPaisa('n/a')).toBeNull()
  })
})

describe('credential encryption', () => {
  it('round-trips a secret and never stores it in the clear', () => {
    const encrypted = encryptSecret('8gBm/:&EnhH.1/q')
    expect(encrypted.startsWith('v1:')).toBe(true)
    expect(encrypted).not.toContain('8gBm')
    expect(decryptSecret(encrypted)).toBe('8gBm/:&EnhH.1/q')
  })

  it('uses a fresh nonce every time', () => {
    expect(encryptSecret('same')).not.toBe(encryptSecret('same'))
  })

  it('refuses tampered or malformed ciphertext', () => {
    const [version, iv, tag, body] = encryptSecret('secret-key').split(':')
    const flipped = Buffer.from(body, 'base64')
    flipped[0] ^= 0xff
    expect(decryptSecret([version, iv, tag, flipped.toString('base64')].join(':'))).toBeNull()
    expect(decryptSecret('not-encrypted')).toBeNull()
  })
})

describe('validation', () => {
  const product = {
    sku: 'NDL-CHK-75',
    name: 'Instant Noodles Chicken 75g x 30',
    unit: 'carton',
    category: 'Noodles',
    pricePaisa: 600_00,
    moq: 2,
    schemeNote: '',
    bulkTiers: [
      { minQty: 10, pricePaisa: 580_00 },
      { minQty: 25, pricePaisa: 560_00 },
    ],
    isActive: true,
  }

  it('accepts a well-formed product with descending tiers', () => {
    expect(productSchema.safeParse(product).success).toBe(true)
  })

  it('rejects tiers that do not get cheaper or start at or below the MOQ', () => {
    const dearer = { ...product, bulkTiers: [{ minQty: 10, pricePaisa: 610_00 }] }
    const tooLow = { ...product, bulkTiers: [{ minQty: 2, pricePaisa: 580_00 }] }
    expect(productSchema.safeParse(dearer).success).toBe(false)
    expect(productSchema.safeParse(tooLow).success).toBe(false)
  })

  it('normalises invite codes however they are typed', () => {
    const code = generateInviteCode()
    expect(code).toMatch(/^[A-HJ-NP-Z2-9]{12}$/)
    const typed = ` ${formatInviteCode(code).toLowerCase()} `
    expect(joinOrganizationSchema.parse({ code: typed }).code).toBe(code)
  })
})
