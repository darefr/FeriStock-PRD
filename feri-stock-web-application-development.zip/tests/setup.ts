import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll } from 'vitest'

// Every test file gets its own throwaway embedded PostgreSQL, so suites never share state.
const directory = mkdtempSync(join(tmpdir(), 'feristock-test-'))
process.env.FERISTOCK_DEV_DIR = directory
process.env.FERISTOCK_ENCRYPTION_KEY = 'test-only-key-material-not-used-anywhere-else'
delete process.env.DATABASE_URL
delete process.env.POSTGRES_URL

afterAll(() => {
  rmSync(directory, { recursive: true, force: true })
})
