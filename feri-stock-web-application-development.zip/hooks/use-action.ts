'use client'

import { useState } from 'react'
import { toast } from 'sonner'
import type { ActionResult } from '@/lib/actions/types'

type Options<Output> = {
  /** Shown as a toast when the action succeeds. */
  success?: string | ((data: Output) => string)
  onSuccess?: (data: Output) => void
}

/**
 * Runs a server action with a pending flag, field-level errors and consistent error toasts.
 * `run` resolves to the action's data on success and `null` on any failure.
 */
export function useAction<Input, Output>(
  action: (input: Input) => Promise<ActionResult<Output>>,
  options: Options<Output> = {},
) {
  const [pending, setPending] = useState(false)
  const [fields, setFields] = useState<Record<string, string>>({})

  async function run(input: Input): Promise<{ data: Output } | null> {
    setPending(true)
    setFields({})
    try {
      const result = await action(input)
      if (!result.ok) {
        setFields(result.fields ?? {})
        toast.error(result.error)
        return null
      }
      if (options.success) {
        toast.success(typeof options.success === 'function' ? options.success(result.data) : options.success)
      }
      options.onSuccess?.(result.data)
      return { data: result.data }
    } catch {
      toast.error('Could not reach FeriStock. Check your connection and try again.')
      return null
    } finally {
      setPending(false)
    }
  }

  return { run, pending, fields, clearFields: () => setFields({}) }
}
