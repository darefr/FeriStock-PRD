'use client'

import useSWR, { mutate } from 'swr'
import type { NavBadges } from '@/lib/domain/dashboard'
import { fetcher } from '@/lib/fetcher'

export const NAV_BADGES_KEY = '/api/nav'

const EMPTY: NavBadges = { cart: 0, stockAlerts: 0, purchases: 0, sales: 0, quotes: 0 }

/** Counts for the navigation. Seeded by the server layout, then kept fresh in the background. */
export function useNavBadges(): NavBadges {
  const { data } = useSWR<{ badges: NavBadges }>(NAV_BADGES_KEY, fetcher, {
    refreshInterval: 30_000,
    revalidateOnFocus: true,
  })
  return data?.badges ?? EMPTY
}

/** Call after an action that changes a count, such as adding to the cart. */
export function refreshNavBadges() {
  return mutate(NAV_BADGES_KEY)
}
