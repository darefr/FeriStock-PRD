'use client'

import { useRef, useState, useTransition } from 'react'
import { toast } from 'sonner'
import { setCartQtyAction } from '@/lib/actions/inventory'
import { refreshNavBadges } from './use-nav-badges'

const SAVE_DELAY_MS = 400

/**
 * Cart quantities for any number of products on a screen. A change shows immediately and is saved
 * once the tapping pauses; the local value is dropped in the same render that brings the refreshed
 * server data, so the number never flickers back.
 */
export function useCartQuantities() {
  const [overrides, setOverrides] = useState<Record<string, number>>({})
  const [, startTransition] = useTransition()
  const timers = useRef(new Map<string, ReturnType<typeof setTimeout>>())
  const tickets = useRef(new Map<string, number>())

  function release(productId: string) {
    setOverrides((current) => {
      const { [productId]: _released, ...rest } = current
      return rest
    })
  }

  function setQty(productId: string, qty: number) {
    setOverrides((current) => ({ ...current, [productId]: qty }))
    const ticket = (tickets.current.get(productId) ?? 0) + 1
    tickets.current.set(productId, ticket)

    const existing = timers.current.get(productId)
    if (existing) clearTimeout(existing)
    timers.current.set(
      productId,
      setTimeout(() => {
        timers.current.delete(productId)
        startTransition(async () => {
          const result = await setCartQtyAction({ productId, qty }).catch(() => null)
          if (!result?.ok) {
            toast.error(result?.error ?? 'Could not reach FeriStock. Check your connection and try again.')
          }
          void refreshNavBadges()
          if (tickets.current.get(productId) !== ticket) return
          startTransition(() => release(productId))
        })
      }, SAVE_DELAY_MS),
    )
  }

  return {
    /** The quantity to show: the unsaved local value if there is one, otherwise the server's. */
    qtyOf: (productId: string, serverQty: number) => overrides[productId] ?? serverQty,
    isSaving: (productId: string) => productId in overrides,
    saving: Object.keys(overrides).length > 0,
    setQty,
  }
}
